import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:isolate';

import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';

import 'backend_transport.dart';
import 'lan_share_preferences.dart';
import 'network_proxy_preferences.dart';

/// Manages the local backend core.
///
/// The backend is the Rust native core (`rust/`, packaged as
/// `libfqapi_core.so`). Flutter calls it over flutter_rust_bridge; the same
/// Rust core also serves `/api/v1/*` and `/src/*` resources over a loopback
/// HTTP adapter for external readers, which is why [baseUrl] still exists for
/// resource resolution in `ApiClient.absoluteUrl`.
///
/// There is no process to launch and no JNI bridge: `start` deploys the
/// runtime files and initializes the core in-process.
class BackendService {
  BackendService({
    AssetBundle? assets,
    Future<Directory> Function()? supportDirectory,
    BackendTransport? transport,
    this.fallbackBaseUrl =
        'http://127.0.0.1:${RustBackendTransport.defaultPort}',
    this.startupTimeout = const Duration(seconds: 15),
    this.shutdownTimeout = const Duration(seconds: 3),
  }) : _assets = assets ?? rootBundle,
       _supportDirectory = supportDirectory ?? getApplicationSupportDirectory,
       _transport = transport ?? RustBackendTransport();

  static final BackendService instance = BackendService();

  final AssetBundle _assets;
  final Future<Directory> Function() _supportDirectory;
  final BackendTransport _transport;

  /// Used for resource URLs only when the core has not reported a port yet.
  final String fallbackBaseUrl;

  final Duration startupTimeout;
  final Duration shutdownTimeout;

  Future<void>? _startFuture;
  Future<void>? _stopFuture;
  bool _running = false;
  bool _coreStarted = false;
  int? _coreGeneration;
  int _generation = 0;
  Timer? _startupTimer;
  static Future<void> _deploymentTail = Future<void>.value();
  final List<String> _logLines = [];
  File? _logFile;
  // Serializes async log-file writes so concurrent appends don't interleave.
  Future<void> _logWriteQueue = Future.value();

  /// The transport business calls go through.
  BackendTransport get transport => _transport;

  /// Base URL used to resolve backend-relative resources.
  String get baseUrl =>
      _transport.baseUrl.isNotEmpty ? _transport.baseUrl : fallbackBaseUrl;

  /// Whether the Rust FFI transport is in use (as opposed to the HTTP adapter).
  bool get usesRustTransport => _transport is RustBackendTransport;

  /// Whether the backend core is currently running.
  bool get isRunning => _running;

  /// Recent backend log lines (for diagnostics).
  List<String> get logLines => List.unmodifiable(_logLines);

  /// Path of the directory where backend files live.
  Future<Directory> _backendDir() async {
    final dir = await _supportDirectory();
    final backend = Directory('${dir.path}/backend');
    if (!await backend.exists()) {
      await backend.create(recursive: true);
    }
    return backend;
  }

  /// Rust 核心日志文件（`core_log` 的落盘副本）。与传给核心的 `runtimeDir` 是
  /// 同一个目录；文件名对应 `rust/src/core_log.rs` 的 `LOG_FILE_NAME`。
  Future<File> rustLogFile() async =>
      File('${(await _backendDir()).path}/rust.log');

  /// Rust 核心日志全文；文件不存在或读不到时返回 null（日志页据此给空态）。
  Future<String?> readRustLog() async {
    try {
      final file = await rustLogFile();
      if (!await file.exists()) return null;
      return await file.readAsString();
    } catch (_) {
      return null;
    }
  }

  /// Copies an asset bundle entry to [dest] if missing or stale.
  Future<void> _copyAsset(String assetPath, File dest) async {
    final data = await _assets.load(assetPath);
    final bytes = data.buffer.asUint8List(
      data.offsetInBytes,
      data.lengthInBytes,
    );
    if (await _hasSameBytes(dest, bytes)) return;

    await dest.parent.create(recursive: true);
    final temporary = File('${dest.path}.asset-tmp');
    if (await temporary.exists()) await temporary.delete();
    await temporary.writeAsBytes(bytes, flush: true);
    try {
      await temporary.rename(dest.path);
    } on FileSystemException {
      if (await dest.exists()) await dest.delete();
      await temporary.rename(dest.path);
    }
  }

  Future<bool> _hasSameBytes(File file, Uint8List bundled) async {
    if (!await file.exists() || await file.length() != bundled.length) {
      return false;
    }
    final existing = await file.readAsBytes();
    if (bundled.length < 256 * 1024) return _bytesEqual(existing, bundled);
    return Isolate.run(() => _bytesEqual(existing, bundled));
  }

  /// Deploys the runtime files the Rust core reads (config + filters).
  Future<void> _deploy() async {
    final dir = await _backendDir();

    final configDir = Directory('${dir.path}/config');
    await configDir.create(recursive: true);

    // Rebuild from bundled defaults and persisted user routing on every start;
    // copying the asset alone would silently discard the user's proxy choice.
    final config =
        jsonDecode(
              await _assets.loadString(
                'assets/config/config.json',
                cache: false,
              ),
            )
            as Map<String, dynamic>;
    config['network_proxy'] =
        (Platform.isWindows || Platform.isLinux
                ? await NetworkProxyPreferences.instance.load()
                : const NetworkProxyConfig())
            .toJson();
    await File(
      '${dir.path}/config/config.json',
    ).writeAsString(jsonEncode(config), flush: true);
    await _copyAsset(
      'assets/config/device_pool.example.json',
      File('${dir.path}/config/device_pool.example.json'),
    );
    await _copyAsset(
      'assets/config/filter.json',
      File('${dir.path}/config/filter.json'),
    );
    // Seed the device pool from the example on first launch (the core
    // registers a real device on demand and persists it here).
    final poolFile = File('${dir.path}/config/device_pool.json');
    if (!await poolFile.exists()) {
      await _copyAsset('assets/config/device_pool.example.json', poolFile);
    }

    // Enumerate the manifest so filters in nested directories deploy as well.
    final manifest = await AssetManifest.loadFromAssetBundle(_assets);
    for (final asset in manifest.listAssets()) {
      if (asset.startsWith('assets/filters/')) {
        final relative = asset.substring('assets/'.length);
        await _copyAsset(asset, File('${dir.path}/$relative'));
      }
    }
  }

  void _log(String line) {
    _logLines.add(line);
    if (_logLines.length > 500) _logLines.removeAt(0);
    final file = _logFile;
    if (file == null) return;
    _logWriteQueue = _logWriteQueue.then((_) async {
      try {
        await file.writeAsString('$line\n', mode: FileMode.append);
      } catch (_) {}
    });
  }

  /// Starts the backend if not already running.
  ///
  /// Concurrent callers share the same startup future, so every caller waits
  /// for a definitive healthy/error result. Initialization is idempotent: a
  /// second call while running returns immediately.
  Future<void> start() {
    final stopping = _stopFuture;
    if (stopping != null) return stopping.then((_) => start());
    final active = _startFuture;
    if (active != null) return active;
    if (_running) return Future<void>.value();
    final generation = ++_generation;
    final clock = Stopwatch()..start();
    _startupTimer?.cancel();
    final timeout = Completer<void>();
    late final Timer timer;
    timer = Timer(startupTimeout, () {
      if (_generation == generation) {
        ++_generation;
        _running = false;
        _log('startup deadline expired; physical cleanup may still be pending');
        unawaited(_stopRunningBackend());
      }
      if (!timeout.isCompleted) {
        timeout.completeError(
          StateError('backend failed to start (startup timeout)'),
          StackTrace.current,
        );
      }
    });
    _startupTimer = timer;
    late final Future<void> tracked;
    final operation = _startInternal(generation, clock, stopping);
    tracked = Future.any<void>([operation, timeout.future]).whenComplete(() {
      if (identical(_startupTimer, timer)) {
        timer.cancel();
        _startupTimer = null;
      }
      if (identical(_startFuture, tracked)) _startFuture = null;
    });
    _startFuture = tracked;
    return tracked;
  }

  /// Cancels only the startup deadline timer.
  ///
  /// The app widget can be disposed while a test or a hot-reload is still
  /// waiting for startup. The native operation may continue, but leaving the
  /// deadline timer behind makes Flutter's test binding report a leaked timer.
  void cancelStartupTimeout() {
    _startupTimer?.cancel();
    _startupTimer = null;
  }

  void _checkGeneration(int generation, Stopwatch _) {
    if (_generation != generation) throw StateError('backend start retired');
  }

  Future<void> _startInternal(
    int generation,
    Stopwatch clock,
    Future<void>? stopping,
  ) async {
    try {
      await stopping;
      _checkGeneration(generation, clock);
      final deployment = _deploymentTail.then((_) async {
        _checkGeneration(generation, clock);
        await _deploy();
      });
      _deploymentTail = deployment.then<void>(
        (_) {},
        onError: (Object _, StackTrace _) {},
      );
      await deployment;
      _checkGeneration(generation, clock);
      final dir = await _backendDir();
      _checkGeneration(generation, clock);
      final listenPort = await _configPort(dir);
      _checkGeneration(generation, clock);

      // Reset the log file each start.
      final logPath = '${dir.path}/backend.log';
      await _logWriteQueue;
      _checkGeneration(generation, clock);
      try {
        File(logPath).deleteSync();
      } catch (_) {}
      _logFile = File(logPath);

      final rustTransport = _transport;
      if (rustTransport is RustBackendTransport) {
        _log('initializing Rust core...');
        final result = await rustTransport.start(
          configPath: '${dir.path}/config/config.json',
          poolPath: '${dir.path}/config/device_pool.json',
          filterPath: '${dir.path}/config/filter.json',
          runtimeDir: dir.path,
          listenPort: listenPort,
          lanShare: LanSharePreferences.instance.enabled.value,
        );
        if (result == 'running') {
          _coreStarted = true;
          _coreGeneration = generation;
        }
        _checkGeneration(generation, clock);
        _log('Rust core init returned: $result');
        if (result != 'running') {
          throw StateError('Rust core failed: $result');
        }
      }

      final ok = await _waitHealthy(
        _startupRemaining(clock),
        generation,
        clock,
      );
      _checkGeneration(generation, clock);
      if (clock.elapsed >= startupTimeout) {
        throw StateError('backend startup deadline expired');
      }
      if (!ok) {
        throw StateError(
          'backend failed to start (health check timeout)\n'
          'logs: ${_logLines.join('\n')}',
        );
      }
      _running = true;
      _log('backend healthy');
    } catch (e) {
      final ownsGeneration = _generation == generation;
      if (ownsGeneration) {
        ++_generation;
        _running = false;
        _log('start error: $e');
      }
      if (_coreStarted && _coreGeneration == generation) {
        await _stopRunningBackend();
      }
      rethrow;
    }
  }

  /// Listener port declared by the deployed `config.json`.
  ///
  /// That file is the single source of truth for the port. A missing or
  /// unparsable file falls back to [RustBackendTransport.defaultPort] so a
  /// damaged config cannot leave the app unable to start.
  Future<int?> _configPort(Directory dir) async {
    try {
      final raw = await File('${dir.path}/config/config.json').readAsString();
      final decoded = jsonDecode(raw);
      if (decoded is Map) {
        final port = decoded['port'];
        if (port is int && port > 0) return port;
      }
    } catch (_) {
      // Fall through: the Rust core applies its own default.
    }
    return null;
  }

  /// Rebuilds the listener so a new listen mode takes effect.
  ///
  /// The core binds its socket at init, so the only way to change the bind
  /// address is to retire the core and start a fresh one. Requests in flight
  /// are cancelled by that shutdown - the UI asks for confirmation before
  /// calling this. The caller owns the persisted preference; this method only
  /// acts on whatever [LanSharePreferences] currently says.
  Future<void> restartForListenMode() => restartForConfiguration();

  /// Redeploys persisted settings and retires requests owned by the old core.
  Future<void> restartForConfiguration() async {
    await stop();
    await start();
  }

  /// Time left of [startupTimeout] for the remaining startup steps.
  Duration _startupRemaining(Stopwatch clock) {
    final remaining = startupTimeout - clock.elapsed;
    return remaining > Duration.zero ? remaining : Duration.zero;
  }

  /// Polls `/health` until the backend responds or [timeout] elapses.
  Future<bool> _waitHealthy(
    Duration timeout,
    int generation,
    Stopwatch clock,
  ) async {
    final elapsed = Stopwatch()..start();
    var attempted = false;
    while (!attempted || elapsed.elapsed < timeout) {
      attempted = true;
      _checkGeneration(generation, clock);
      final remaining = timeout - elapsed.elapsed;
      final attemptTimeout = remaining > Duration.zero
          ? (remaining < const Duration(seconds: 2)
                ? remaining
                : const Duration(seconds: 2))
          : const Duration(milliseconds: 50);
      try {
        final response = await _transport.send(
          'GET',
          Uri.parse('$baseUrl/health'),
          timeout: attemptTimeout,
        );
        _checkGeneration(generation, clock);
        if (response.statusCode == 200) return true;
        _log('health check: HTTP ${response.statusCode}');
      } catch (_) {
        // Not up yet. Bound the complete exchange, including body reading.
      }
      _checkGeneration(generation, clock);
      if (timeout <= Duration.zero) break;
      final pause = timeout - elapsed.elapsed;
      if (pause <= Duration.zero) break;
      await Future<void>.delayed(
        pause < const Duration(milliseconds: 300)
            ? pause
            : const Duration(milliseconds: 300),
      );
      _checkGeneration(generation, clock);
    }
    return false;
  }

  /// Stops the backend core. Safe to call repeatedly.
  Future<void> stop() {
    cancelStartupTimeout();
    _running = false;
    final active = _stopFuture;
    if (active != null) return active;
    late final Future<void> tracked;
    tracked = _stopInternal().whenComplete(() {
      if (identical(_stopFuture, tracked)) _stopFuture = null;
    });
    _stopFuture = tracked;
    return tracked;
  }

  Future<void> _stopInternal() async {
    // A stop during deployment must not return before that startup has had a
    // chance to create the core; otherwise the core can be initialized after
    // stop() has already reported completion.
    final starting = _startFuture;
    try {
      await starting;
    } catch (_) {
      // A failed start performs its own cleanup.
    }
    try {
      await _stopRunningBackend();
    } finally {
      await _logWriteQueue.timeout(
        shutdownTimeout,
        onTimeout: () {
          _logLines.add('log writes still pending after logical stop');
        },
      );
    }
  }

  Future<void> _stopRunningBackend() async {
    final transport = _transport;
    if (!_coreStarted || transport is! RustBackendTransport) return;
    _coreStarted = false;
    _coreGeneration = null;
    _running = false;
    try {
      await transport.stop().timeout(shutdownTimeout);
    } catch (e) {
      _log('shutdown failed or physical cleanup still pending: $e');
    }
  }
}

bool _bytesEqual(List<int> left, List<int> right) {
  if (left.length != right.length) return false;
  for (var index = 0; index < left.length; index++) {
    if (left[index] != right[index]) return false;
  }
  return true;
}
