import 'platform_channel.dart';
import 'dart:async';
import 'dart:convert';

import 'package:flutter/services.dart';

import 'app_log.dart';
import 'audio_preferences.dart';
import 'linux_platform.dart' show isLinuxDesktop;
import 'player_preferences.dart';

// Codec metadata only: never log the whole platform payload or exception text.
final _decoderToken = RegExp(r'^[A-Za-z0-9_.+/-]{1,160}$');

Map<String, Object> _safeDecoderDiagnostics(Object? value) {
  if (value is! Map) return const {};
  String? token(Object? raw) =>
      raw is String && _decoderToken.hasMatch(raw) ? raw : null;
  return {
    for (final key in ['name', 'mimeType', 'diagnosticInfo'])
      if (token(value[key]) case final String safe) key: safe,
    if (value['fallbackDecoders'] case final List fallbacks)
      'fallbackDecoders': [
        for (final name in fallbacks.take(8))
          if (token(name) case final String safe) safe,
      ],
  };
}

class NativePlaybackException implements Exception {
  final String message;
  final int? errorCode;
  final int? httpStatusCode;

  const NativePlaybackException(
    this.message, {
    this.errorCode,
    this.httpStatusCode,
  });

  factory NativePlaybackException.fromEvent(Object? value) {
    if (value is Map) {
      return NativePlaybackException(
        value['message'] is String
            ? value['message'] as String
            : 'Player error',
        errorCode: value['errorCode'] is int ? value['errorCode'] as int : null,
        httpStatusCode: value['httpStatusCode'] is int
            ? value['httpStatusCode'] as int
            : null,
      );
    }
    // Creation/probe errors and older hosts still send a plain string.
    return NativePlaybackException(value is String ? value : 'Player error');
  }

  @override
  String toString() => 'NativePlaybackException: $message';
}

/// Flutter-side wrapper of the native ExoPlayer host.
class NativePlayer {
  NativePlayer({this.audioOnly = false});

  static const _channel = AppMethodChannel('fqapp/native_player');
  static const _events = AppEventChannel('fqapp/native_player/events');
  static const _methodTimeout = Duration(seconds: 10);
  static const _createTimeout = Duration(seconds: 25);

  /// 换源（reopen）等待时长：mpv 解出媒体头通常 1–3 秒，后台给到 15 秒。
  static const _reopenTimeout = Duration(seconds: 15);

  Completer<void>? _reopenCompleter;

  /// The app's listening owner coordinates audio with video playback. The
  /// generation below cancels a pending play if another player pauses it.
  static Future<void> Function(NativePlayer)? beforePlay;

  static Future<void> pauseOthers([NativePlayer? active]) async {
    for (final player in _instances.values.toList(growable: false)) {
      if (!identical(player, active) && player._playWhenReady) {
        await player.pause();
      }
    }
  }

  static void Function(String action)? _onRemoteAction;
  static void Function(int positionMs)? _onRemoteSeek;
  static int _remoteGeneration = 0;
  static String allocateRemoteOwner() => 'media-${++_remoteGeneration}';
  static String? _remoteOwner;
  static String? _remoteEpisode;
  static int _foregroundGeneration = 0;
  static bool ownsRemoteOwner(String owner) => _remoteOwner == owner;
  static final _remoteHandlers =
      <
        String,
        ({
          void Function(String)? action,
          void Function(int)? seek,
          VoidCallback? noisy,
          Future<double> Function(String, double)? setting,
        })
      >{};
  static void claimRemoteOwner(String owner) {
    final handler = _remoteHandlers[owner];
    if (handler == null) return;
    _remoteOwner = owner;
    _onRemoteAction = handler.action;
    _onRemoteSeek = handler.seek;
    _onBecomingNoisy = handler.noisy;
  }

  static VoidCallback? _onBecomingNoisy;
  static int? _floatingHandlerOwner;
  static void Function(String action)? _onFloatingAction;
  static final Map<int, ({NativePlayer player, bool stopped})>
  _startingFloating = {};
  static ({int owner, NativePlayer player})? _floatingBinding;
  static int _floatingMove = 0;

  bool get isFloating =>
      identical(_floatingBinding?.player, this) ||
      _startingFloating.values.any(
        (start) => !start.stopped && identical(start.player, this),
      );

  static void _bindFloating(int owner, int playerId) {
    final current = _floatingBinding;
    if (current != null && current.owner > owner) return;
    final player = _instances[playerId];
    if (player != null) _floatingBinding = (owner: owner, player: player);
  }

  static void _clearFloatingBinding(int owner) {
    if (_floatingBinding?.owner != owner) return;
    ++_floatingMove;
    _floatingBinding = null;
  }

  static void setFloatingCommandHandler({
    required int owner,
    required void Function(String action) onAction,
  }) {
    if (_floatingHandlerOwner case final int current when current > owner) {
      return;
    }
    _floatingHandlerOwner = owner;
    _onFloatingAction = onAction;
    _channel.setMethodCallHandler(_handleMethodCall);
  }

  static void clearFloatingCommandHandler(int owner) {
    if (_floatingHandlerOwner != owner) return;
    _floatingHandlerOwner = null;
    _onFloatingAction = null;
  }

  static void setRemoteCommandHandler({
    void Function(String action)? onAction,
    VoidCallback? onBecomingNoisy,
    String? owner,
    void Function(int positionMs)? onSeek,
    Future<double> Function(String, double)? onSetting,
  }) {
    if (owner != null) {
      _remoteHandlers[owner] = (
        action: onAction,
        seek: onSeek,
        noisy: onBecomingNoisy,
        setting: onSetting,
      );
    }
    _remoteOwner = owner;
    _onRemoteSeek = onSeek;
    _onRemoteAction = onAction;
    _onBecomingNoisy = onBecomingNoisy;
    _channel.setMethodCallHandler(_handleMethodCall);
  }

  static void clearRemoteCommandHandler({String? owner}) {
    if (owner != null) _remoteHandlers.remove(owner);
    if (owner != null && owner != _remoteOwner) return;
    _remoteOwner = null;
    _onRemoteSeek = null;
    _onRemoteAction = null;
    _onBecomingNoisy = null;
  }

  static StreamSubscription<dynamic>? _globalEventSub;
  static final Map<int, NativePlayer> _instances = {};
  static final Map<int, List<dynamic>> _pendingEvents = {};
  static final Map<int, Timer> _pendingExpiry = {};
  static final Map<int, Timer> _retiredExpiry = {};

  static void _ensureGlobalListener() {
    _channel.setMethodCallHandler(_handleMethodCall);
    if (_globalEventSub != null) return;
    late final StreamSubscription<dynamic> subscription;
    subscription = _events.receiveBroadcastStream().listen(
      _dispatchEvent,
      onError: (Object error, StackTrace stackTrace) {
        if (identical(_globalEventSub, subscription)) {
          _globalEventSub = null;
        }
        for (final player in _instances.values.toList(growable: false)) {
          player._handleChannelError(error, stackTrace);
        }
        _clearPendingEvents();
      },
      onDone: () {
        if (identical(_globalEventSub, subscription)) {
          _globalEventSub = null;
        }
        final error = StateError('Native player event channel closed');
        for (final player in _instances.values.toList(growable: false)) {
          player._handleChannelError(error, StackTrace.current);
        }
        _clearPendingEvents();
      },
      cancelOnError: true,
    );
    _globalEventSub = subscription;
  }

  static Future<dynamic> _handleMethodCall(MethodCall call) async {
    switch (call.method) {
      case 'onMediaSetting':
        final raw = call.arguments as Map;
        final owner = raw['owner'] as String?;
        final handler = _remoteHandlers[owner]?.setting;
        if (!isLinuxDesktop || owner != _remoteOwner || handler == null) {
          throw PlatformException(code: 'stale_owner');
        }
        final result = await handler(
          raw['property'] as String,
          (raw['value'] as num).toDouble(),
        );
        if (owner != _remoteOwner) throw PlatformException(code: 'stale_owner');
        return result;

      case 'onNotificationAction':
        final raw = call.arguments;
        final action = raw is Map
            ? raw['action'] as String?
            : raw is String
            ? raw
            : null;
        if (isLinuxDesktop && (raw is! Map || raw['owner'] != _remoteOwner)) {
          return null;
        }
        if (action == 'seekTo' &&
            raw is Map &&
            raw['episode'] != null &&
            raw['episode'] != _remoteEpisode) {
          return null;
        }
        if (action == 'seekTo' && raw is Map && raw['positionMs'] is int) {
          _onRemoteSeek?.call(raw['positionMs'] as int);
        } else if (action != null) {
          _onRemoteAction?.call(action);
        }
      case 'onAudioBecomingNoisy':
        _onBecomingNoisy?.call();
      case 'onFloatingAction':
        final raw = call.arguments;
        if (raw is Map &&
            raw['owner'] == _floatingHandlerOwner &&
            raw['owner'] is int &&
            raw['action'] is String) {
          _onFloatingAction?.call(raw['action'] as String);
        }
      case 'onFloatingStopped':
        final raw = call.arguments;
        final owner = raw is Map ? raw['owner'] : null;
        if (owner is int) {
          _clearFloatingBinding(owner);
          if (_startingFloating[owner] case final start?) {
            _startingFloating[owner] = (player: start.player, stopped: true);
          }
          if (_floatingHandlerOwner == owner) _onFloatingAction?.call('stop');
        }
    }
    return null;
  }

  static void _dispatchEvent(dynamic event) {
    if (event is! Map) return;
    final rawPlayerId = event['playerId'];
    if (rawPlayerId is! num) return;
    final playerId = rawPlayerId.toInt();
    if (_retiredExpiry.containsKey(playerId)) return;
    final instance = _instances[playerId];
    if (instance != null) {
      instance._handleEvent(event);
      return;
    }

    final pending = _pendingEvents.putIfAbsent(playerId, () => []);
    if (pending.length < 16) pending.add(event);
    _pendingExpiry[playerId]?.cancel();
    _pendingExpiry[playerId] = Timer(const Duration(seconds: 15), () {
      _pendingEvents.remove(playerId);
      _pendingExpiry.remove(playerId);
    });
  }

  static void _clearPendingEvents() {
    _pendingEvents.clear();
    for (final timer in _pendingExpiry.values) {
      timer.cancel();
    }
    _pendingExpiry.clear();
  }

  static void _retire(int playerId) {
    _pendingEvents.remove(playerId);
    _pendingExpiry.remove(playerId)?.cancel();
    _retiredExpiry.remove(playerId)?.cancel();
    _retiredExpiry[playerId] = Timer(const Duration(seconds: 30), () {
      _retiredExpiry.remove(playerId);
    });
  }

  int? _playerId;
  int? _textureId;
  bool _disposed = false;
  bool _creationFailed = false;
  Future<int>? _createFuture;
  Future<void>? _disposeFuture;
  Future<void>? _nativeRelease;
  int _seekGeneration = 0;
  int _appliedSeekGeneration = 0;
  int _playWhenReadyGeneration = 0;

  /// 是否纯音频（听书）。原生侧据此决定倍速用哪种变速实现：视频/短剧
  /// 仍用 Media3 内建的 Sonic，否则视频倍速会跟着变（音频处理与视频渲染
  /// 必须同步走同一套计时）。见 issue #129。
  final bool audioOnly;

  int? get textureId => _textureId;
  int? get playerId => _playerId;
  bool get isCreated => _textureId != null && !_disposed;

  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;
  bool _playing = false;
  bool _playWhenReady = false;
  bool _completed = false;
  bool _buffering = false;
  bool _firstFrameRendered = false;
  int _videoWidth = 0;
  int _videoHeight = 0;
  int _videoRotationCorrection = 0;
  Object? _lastError;

  Duration get position => _position;
  Duration get duration => _duration;
  bool get playing => _playing;

  /// Playback intent stays true while ExoPlayer is buffering or suppressed.
  bool get playWhenReady => _playWhenReady;
  bool get completed => _completed;
  bool get buffering => _buffering;
  bool get firstFrameRendered => _firstFrameRendered;
  int get videoWidth => _videoWidth;
  int get videoHeight => _videoHeight;

  /// Clockwise rotation not applied by the native texture backend.
  int get videoRotationCorrection => _videoRotationCorrection;
  Object? get lastError => _lastError;

  final _positionCtrl = StreamController<Duration>.broadcast();
  final _durationCtrl = StreamController<Duration>.broadcast();
  final _playingCtrl = StreamController<bool>.broadcast();
  final _playWhenReadyCtrl = StreamController<bool>.broadcast();
  final _completedCtrl = StreamController<bool>.broadcast();
  final _bufferingCtrl = StreamController<bool>.broadcast();
  final _firstFrameCtrl = StreamController<bool>.broadcast();
  final _videoSizeCtrl = StreamController<Size>.broadcast();
  final _textureIdCtrl = StreamController<int>.broadcast();
  final _errorCtrl = StreamController<Object>.broadcast();

  Stream<Duration> get positionStream => _positionCtrl.stream;
  Stream<Duration> get durationStream => _durationCtrl.stream;
  Stream<bool> get playingStream => _playingCtrl.stream;
  Stream<bool> get playWhenReadyStream => _playWhenReadyCtrl.stream;
  Stream<bool> get completedStream => _completedCtrl.stream;
  Stream<bool> get bufferingStream => _bufferingCtrl.stream;
  Stream<bool> get firstFrameStream => _firstFrameCtrl.stream;
  Stream<Size> get videoSizeStream => _videoSizeCtrl.stream;
  Stream<Object> get errorStream => _errorCtrl.stream;

  /// Fires when native swaps the output surface (software-decoder fallback
  /// moves from SurfaceProducer to SurfaceTexture in #2) and the Texture
  /// widget must rebuild with the new id. The old id stops producing frames.
  Stream<int> get textureIdStream => _textureIdCtrl.stream;

  final _createdCompleter = Completer<int>();

  /// 起播位置（毫秒）：> 0 才下发；原生在 prepare() 前应用，不是装载后再 seek。
  Future<int> create(String cdnUrl, String keyHex, {int? startMs}) {
    if (_disposed) {
      return Future<int>.error(StateError('NativePlayer is disposed'));
    }
    return _createFuture ??= _create(cdnUrl, keyHex, startMs);
  }

  Future<int> _create(String cdnUrl, String keyHex, int? startMs) async {
    _ensureGlobalListener();
    // An early native error can finish this future before the reply supplies an
    // id; observe it now, the await below still rethrows to create's caller.
    _createdCompleter.future.ignore();
    try {
      final reply = _channel
          .invokeMapMethod<String, dynamic>('create', {
            'cdnUrl': cdnUrl,
            'keyHex': keyHex,
            // 起播位置：原生在 prepare() 前应用，省一次「先按 0 开流再 seek」。
            if (startMs != null && startMs > 0) 'startPositionMs': startMs,
            // 解码器偏好必须是**已解析的值**：create 在起播关键路径上，await 读盘会让没有
            // 初始化插件的测试与冷启动挂住；由 `DecoderPreferenceCache` 在启动/变更时维护。
            'videoDecoder': DecoderPreferenceCache.current.name,
            // 纯音频播放器才带上变速引擎：视频用内建 Sonic（音频与视频必须同步计时），
            // 只有听书能选系统混音器变速（issue #129）。值同样取内存里的偏好（启动时
            // load 过），理由与解码器偏好相同：起播路径上不能 await 读盘。
            if (audioOnly) ...{
              'audioOnly': true,
              'audioRateEngine': AudioRateEngineCache.current.name,
            },
          })
          .then((result) async {
            final rawPlayerId = result?['playerId'];
            if (rawPlayerId is! num) {
              throw StateError('Native player returned no playerId');
            }
            final playerId = _playerId = rawPlayerId.toInt();
            // Keep observing the original reply even after timeout. Otherwise
            // a late native allocation would never be released.
            if (_disposed || _creationFailed) {
              await _releaseNative();
              throw StateError('NativePlayer was disposed during creation');
            }
            return playerId;
          });
      final playerId = await reply.timeout(_methodTimeout);
      if (_disposed) {
        throw StateError('NativePlayer was disposed during creation');
      }

      _instances[playerId] = this;
      _pendingExpiry.remove(playerId)?.cancel();
      final pending = _pendingEvents.remove(playerId);
      if (pending != null) {
        for (final event in pending) {
          _handleEvent(event);
        }
      }

      await _createdCompleter.future.timeout(_createTimeout);
      if (_disposed) {
        throw StateError('NativePlayer was disposed during creation');
      }
      // _textureId comes from the event handler, not the completer: a replayed
      // textureChanged already superseded the created id, so assigning the stale
      // completer value here would resurrect the dead texture.
      if (_textureId == null) {
        throw StateError('Native player returned no texture id');
      }
      if (startMs != null && startMs > 0) {
        _position = Duration(milliseconds: startMs);
        _positionCtrl.add(_position);
      }
      return _textureId!;
    } catch (_) {
      _creationFailed = true;
      await _releaseNative();
      rethrow;
    }
  }

  /// 在现有播放器上换源（不重建）。后台换章只能这样走：新建 mpv 实例会在
  /// 音频输出初始化上永久阻塞。返回时等待时长就绪，调用方可以立刻 play。
  Future<void> reopen(String cdnUrl, String keyHex) async {
    final playerId = _playerId;
    if (_disposed || playerId == null) {
      throw StateError('NativePlayer is not created');
    }
    // 换源期间旧 URL 可能先报一次错（本地代理端口已关），别让它留在状态里。
    _lastError = null;
    final completer = _reopenCompleter = Completer<void>();
    await _channel.invokeMethod<void>('reopen', {
      'playerId': playerId,
      'cdnUrl': cdnUrl,
      'keyHex': keyHex,
    });
    // 必须等原生真的换完源：mpv 换了 URL 之后才会解出新媒体的头，
    // 此时 duration 才可信。直接看 duration 会读到上一章残留的值，
    // 于是「还没换完就开始播」，mpv 去连已经关闭的本地端口，报
    // `tcp: Connection refused` 然后卡住。
    await completer.future.timeout(_reopenTimeout);
    if (_disposed) throw StateError('NativePlayer was disposed');
  }

  Future<void> play() => _setPlayWhenReady(true);
  Future<void> pause() => _setPlayWhenReady(false);

  Future<void> _setPlayWhenReady(bool value) async {
    if (_disposed) return;
    final generation = ++_playWhenReadyGeneration;
    final previous = _playWhenReady;
    _updatePlayWhenReady(value);
    try {
      if (value) {
        await beforePlay?.call(this);
        if (_disposed || generation != _playWhenReadyGeneration) return;
      }
      await _invoke(value ? 'play' : 'pause');
    } catch (_) {
      if (!_disposed && generation == _playWhenReadyGeneration) {
        _updatePlayWhenReady(previous);
      }
      rethrow;
    }
  }

  void _updatePlayWhenReady(bool value) {
    if (_playWhenReady == value) return;
    _playWhenReady = value;
    _playWhenReadyCtrl.add(value);
  }

  Future<void> seek(Duration position) async {
    final generation = ++_seekGeneration;
    await _invoke('seek', {'positionMs': position.inMilliseconds});
    // Record every acknowledged seek: if a later overlapping seek fails, the
    // position ExoPlayer actually accepted must survive the stale pre-seek value.
    if (_disposed || generation <= _appliedSeekGeneration) return;
    _appliedSeekGeneration = generation;
    // ExoPlayer acknowledges seek before its next position tick. Preserve the
    // accepted position for immediate exit/reentry and during initial buffering.
    _position = position;
    _completed = false;
    _positionCtrl.add(position);
  }

  Future<void> setVolume(double volume) =>
      _invoke('setVolume', {'volume': volume});

  Future<void> setRate(double rate) => _invoke('setRate', {'rate': rate});

  Future<void> _invoke(
    String method, [
    Map<String, dynamic> arguments = const {},
  ]) async {
    if (_disposed) return;
    final playerId = _playerId;
    if (playerId == null) throw StateError('NativePlayer is not created');
    await _channel
        .invokeMethod<void>(method, {'id': playerId, ...arguments})
        .timeout(_methodTimeout);
  }

  static Future<void> setKeepScreenOn(bool on) async {
    await _channel
        .invokeMethod<void>('setKeepScreenOn', {'on': on})
        .timeout(_methodTimeout);
  }

  /// [positionMs] / [durationMs] / [speed] 喂给系统媒体卡片：位置 + 倍速由系统外推，
  /// 总时长决定卡片两侧的时间。缺省 0/0/1 时卡片显示 00:00，所以调用方要尽量给真实值。
  ///
  /// [coverUrl] 是当前在读/在听内容的封面地址。官方（`dn2/i.java`
  /// `PlayNotificationImpl`）把它下载成 Bitmap 后同时写进通知的
  /// `setLargeIcon` 与媒体会话的 `METADATA_KEY_ALBUM_ART`，系统媒体卡片、
  /// 锁屏与通知左上角显示的都是它；拿不到或下载失败时退回应用图标。
  static Future<void> startListenForeground({
    required String title,
    required String episode,
    // 安卓通知点击要能回到正在听的那一章，所以书 id 与章节 id 一起下发。
    String bookId = '',
    String chapterId = '',
    String coverUrl = '',
    bool playing = true,
    bool hasPrev = true,
    bool hasNext = true,
    int positionMs = 0,
    int durationMs = 0,
    double speed = 1,
    String? owner,
    bool seeked = false,
    int? linuxPlayerId,
    bool linuxTts = false,
    double minimumRate = 0.5,
    double maximumRate = 3,
  }) async {
    if (isLinuxDesktop && (owner == null || owner != _remoteOwner)) return;
    final generation = ++_foregroundGeneration;
    _remoteEpisode = episode;
    try {
      Map? settings;
      if (isLinuxDesktop && (linuxPlayerId != null || linuxTts)) {
        settings = await AppMethodChannel(
          linuxTts ? 'fqapp/system_tts' : 'fqapp/native_player',
        ).invokeMethod<Map>('getPlaybackSettings', {'id': linuxPlayerId});
        if (owner != _remoteOwner || generation != _foregroundGeneration) {
          return;
        }
      }
      // No .timeout() here on purpose: the call is best-effort and the
      // plugin replies synchronously, while Future.timeout() leaves a
      // pending 10s timer that breaks widget tests under FakeAsync when
      // the fire-and-forget call is still in flight at test end.
      await _channel.invokeMethod<void>('startListenForeground', {
        if (isLinuxDesktop) ...{
          'owner': owner,
          'transportV2': true,
          'seekSupported': _onRemoteSeek != null,
          'seeked': seeked,
          'volume': settings?['volume'] ?? 1.0,
          'minimumRate': minimumRate,
          'maximumRate': maximumRate,
        },
        'title': title,
        'episode': episode,
        'bookId': bookId,
        'chapterId': chapterId,
        'coverUrl': coverUrl,
        'playing': playing,
        'hasPrev': hasPrev,
        'hasNext': hasNext,
        'positionMs': positionMs,
        'durationMs': durationMs,
        'speed': settings?['rate'] ?? speed,
      });
    } on PlatformException catch (error) {
      if (isLinuxDesktop) AppLog.w('media', 'Linux 媒体会话不可用: ${error.code}');
    } catch (_) {
      // Optional platform integration.
    }
  }

  static Future<void> stopListenForeground({String? owner}) async {
    try {
      // Same as startListenForeground: no .timeout(), see above.
      await _channel.invokeMethod<void>(
        'stopListenForeground',
        isLinuxDesktop && owner != null ? {'owner': owner} : null,
      );
    } on PlatformException catch (error) {
      if (isLinuxDesktop) AppLog.w('media', 'Linux 媒体会话不可用: ${error.code}');
    } catch (_) {
      // Optional platform integration.
    }
  }

  /// 悬浮窗权限：Android 需要用户在系统设置里允许“显示在其他应用的上层”。
  static Future<bool> canDrawOverlays() async {
    try {
      final granted = await _channel
          .invokeMethod<bool>('canDrawOverlays')
          .timeout(_methodTimeout);
      return granted ?? false;
    } catch (_) {
      return false;
    }
  }

  /// 打开系统悬浮窗权限设置页。返回 false 表示当前平台不需要或无法打开。
  static Future<bool> requestOverlayPermission() async {
    try {
      final opened = await _channel.invokeMethod<bool>(
        'requestOverlayPermission',
      );
      return opened ?? false;
    } catch (_) {
      return false;
    }
  }

  // Allocation precedes permissions and acquires no focus/service/surface.
  static Future<int> allocateFloatingOwner() async {
    _channel.setMethodCallHandler(_handleMethodCall);
    var abandoned = false;
    final operation = _channel.invokeMethod<int>('allocateFloatingOwner');
    unawaited(
      operation.then<void>((owner) {
        if (abandoned && owner != null && owner > 0) {
          unawaited(stopFloating(owner));
        }
      }, onError: (Object _) {}),
    );
    try {
      final owner = await operation.timeout(_methodTimeout);
      if (owner == null || owner <= 0) {
        throw StateError('Invalid floating owner');
      }
      return owner;
    } catch (_) {
      abandoned = true;
      rethrow;
    }
  }

  static Future<void> startFloating({
    required int owner,
    required int playerId,
    required String title,
    required String episode,
    bool playing = true,
    bool hasPrev = true,
    bool hasNext = true,
    int positionMs = 0,
    int durationMs = 0,
    double speed = 1,
    int videoWidth = 0,
    int videoHeight = 0,
  }) async {
    final player = _instances[playerId];
    if (player == null) throw StateError('Floating player unavailable');
    // Keep the submitted player's lifecycle intent until the bounded native
    // reply settles. The page pauses it on failure if it is still backgrounded.
    _startingFloating[owner] = (player: player, stopped: false);
    try {
      await _channel
          .invokeMethod<void>('startFloating', {
            'owner': owner,
            'playerId': playerId,
            'title': title,
            'episode': episode,
            'playing': playing,
            'hasPrev': hasPrev,
            'hasNext': hasNext,
            'positionMs': positionMs,
            'durationMs': durationMs,
            'speed': speed,
            'videoWidth': videoWidth,
            'videoHeight': videoHeight,
          })
          .timeout(_methodTimeout);
      if (_startingFloating[owner]?.stopped != false) {
        throw StateError('Floating start retired');
      }
      if (_floatingBinding == null || _floatingBinding!.owner <= owner) {
        ++_floatingMove;
        _bindFloating(owner, playerId);
      }
    } catch (_) {
      await stopFloating(owner);
      rethrow;
    } finally {
      _startingFloating.remove(owner);
    }
  }

  static Future<void> showFloating(int owner) async {
    try {
      await _channel
          .invokeMethod<void>('showFloating', {'owner': owner})
          .timeout(_methodTimeout);
    } catch (_) {
      // Retirement fences any late command on native, even after a timeout.
    }
  }

  static Future<void> updateFloating({
    required int owner,
    String? title,
    String? episode,
    bool? playing,
    bool? hasPrev,
    bool? hasNext,
    int? positionMs,
    int? durationMs,
    double? speed,
  }) async {
    try {
      await _channel
          .invokeMethod<void>('updateFloating', {
            'owner': owner,
            'title': title,
            'episode': episode,
            'playing': playing,
            'hasPrev': hasPrev,
            'hasNext': hasNext,
            'positionMs': positionMs,
            'durationMs': durationMs,
            'speed': speed,
          })
          .timeout(_methodTimeout);
    } catch (_) {
      // State updates cannot cross native ownership retirement.
    }
  }

  static Future<void> stopFloating(int owner) async {
    if (_startingFloating[owner] case final start?) {
      _startingFloating[owner] = (player: start.player, stopped: true);
    }
    _clearFloatingBinding(owner);
    try {
      await _channel
          .invokeMethod<void>('stopFloating', {'owner': owner})
          .timeout(_methodTimeout);
    } catch (_) {
      // An old stop never clears another owner's binding or service.
    }
  }

  static Future<void> swapFloatingPlayer({
    required int owner,
    required int playerId,
  }) async {
    if (_floatingBinding?.owner != owner) {
      throw StateError('Floating owner retired');
    }
    final move = ++_floatingMove;
    await _channel
        .invokeMethod<void>('swapFloatingPlayer', {
          'owner': owner,
          'playerId': playerId,
        })
        .timeout(_methodTimeout);
    if (_floatingBinding?.owner == owner && _floatingMove == move) {
      _bindFloating(owner, playerId);
    }
  }

  Future<void> dispose() => _disposeFuture ??= _dispose();

  Future<void> _dispose() async {
    _disposed = true;
    if (_createFuture != null && !_createdCompleter.isCompleted) {
      _createdCompleter.completeError(StateError('NativePlayer disposed'));
    }
    await _releaseNative();
    await Future.wait<void>([
      _positionCtrl.close(),
      _durationCtrl.close(),
      _playingCtrl.close(),
      _playWhenReadyCtrl.close(),
      _completedCtrl.close(),
      _bufferingCtrl.close(),
      _firstFrameCtrl.close(),
      _videoSizeCtrl.close(),
      _textureIdCtrl.close(),
      _errorCtrl.close(),
    ]);
  }

  Future<void> _releaseNative() {
    final playerId = _playerId;
    if (playerId == null) return Future<void>.value();
    return _nativeRelease ??= _disposeNative(playerId);
  }

  Future<void> _disposeNative(int playerId) async {
    _instances.remove(playerId);
    _retire(playerId);
    try {
      await _channel
          .invokeMethod<void>('dispose', {'id': playerId})
          .timeout(_methodTimeout);
    } catch (error) {
      // 本地状态已摘除，原生 teardown 仍尽力而为：失败不吞掉诊断（日志里
      // 只留类型，异常文本可能带原生载荷），并清掉记忆化，让下一次释放
      // （dispose 重入、迟到的 create 回复）还能重试。
      AppLog.w(
        'player-native',
        'dispose failed playerId=$playerId (${error.runtimeType})',
      );
      _nativeRelease = null;
    }
  }

  void _handleChannelError(Object error, StackTrace stackTrace) {
    if (_disposed) return;
    _lastError = error;
    if (!_createdCompleter.isCompleted) {
      _createdCompleter.completeError(error, stackTrace);
    }
    if (!_errorCtrl.isClosed) _errorCtrl.add(error);
  }

  void _handleEvent(dynamic event) {
    if (_disposed || event is! Map) return;
    final type = event['type'] as String?;
    switch (type) {
      case 'created':
        final value = event['value'];
        if (value is num) {
          _textureId = value.toInt();
          if (!_createdCompleter.isCompleted) {
            _createdCompleter.complete(value.toInt());
          }
        }
      case 'reopened':
        // 换源完成：mpv 已经解出新媒体的头，duration 也回来了。
        final completer = _reopenCompleter;
        _reopenCompleter = null;
        if (completer != null && !completer.isCompleted) completer.complete();
      case 'textureChanged':
        final value = event['value'];
        if (value is num) {
          _textureId = value.toInt();
          // The swap moves decoder output to a legacy SurfaceTexture, which
          // applies the format rotation itself (#36). A videoSize event that
          // landed before the swap still carries the pre-swap correction
          // (e.g. 90 for a rotated source); keeping it would rotate the
          // already-rotated texture a second time, stretching a landscape
          // picture up to fullscreen. Reset it and re-emit the geometry so
          // size/rotation subscribers refresh (the feed reads rotation from
          // its own notifier, not from the player, on rebuild).
          _videoRotationCorrection = 0;
          if (!_videoSizeCtrl.isClosed) {
            _videoSizeCtrl.add(
              Size(_videoWidth.toDouble(), _videoHeight.toDouble()),
            );
          }
          if (!_textureIdCtrl.isClosed) _textureIdCtrl.add(_textureId!);
        }
      case 'error':
        final error = NativePlaybackException.fromEvent(event['value']);
        final value = event['value'];
        AppLog.d(
          'player-decoder',
          jsonEncode({
            'playerId': _playerId,
            'phase': 'failed',
            'errorCode': error.errorCode,
            'httpStatusCode': error.httpStatusCode,
            ..._safeDecoderDiagnostics(value is Map ? value['decoder'] : null),
          }),
        );
        _lastError = error;
        if (!_createdCompleter.isCompleted) {
          _createdCompleter.completeError(error);
        }
        if (!_errorCtrl.isClosed) _errorCtrl.add(error);
      case 'decoderInitialized':
        AppLog.d(
          'player-decoder',
          jsonEncode({
            'playerId': _playerId,
            'phase': 'initialized',
            ..._safeDecoderDiagnostics(event['value']),
          }),
        );
      case 'position':
        final value = event['value'];
        if (value is! num) return;
        _position = Duration(milliseconds: value.toInt());
        _positionCtrl.add(_position);
      case 'duration':
        final value = event['value'];
        if (value is! num) return;
        final ms = value.toInt();
        // ExoPlayer 未知时长回的是 C.TIME_UNSET（一个巨大负数），当「还不知道」处理，
        // 别把它当成真实时长往下传。
        if (ms <= 0) return;
        _duration = Duration(milliseconds: ms);
        _durationCtrl.add(_duration);
      case 'playing':
        final value = event['value'];
        if (value is! bool) return;
        _playing = value;
        _playingCtrl.add(_playing);
      case 'playWhenReady':
        final value = event['value'];
        if (value is! bool) return;
        ++_playWhenReadyGeneration;
        _updatePlayWhenReady(value);
      case 'completed':
        final value = event['value'];
        if (value is! bool) return;
        _completed = value;
        _completedCtrl.add(_completed);
      case 'buffering':
        final value = event['value'];
        if (value is! bool) return;
        _buffering = value;
        _bufferingCtrl.add(_buffering);
      case 'firstFrame':
        _firstFrameRendered = true;
        _firstFrameCtrl.add(true);
      case 'videoSize':
        final width = event['width'];
        final height = event['height'];
        if (width is num && height is num) {
          _videoWidth = width.toInt();
          _videoHeight = height.toInt();
          final rotation = event['rotationCorrection'];
          _videoRotationCorrection =
              rotation is num && const [90, 180, 270].contains(rotation)
              ? rotation.toInt()
              : 0;
          // 诊断：issue #11 竖版源在换档后被塞进横向盒子导致拉伸。这里把
          // 原生上报的原始字段全量抛出，用来区分「尺寸本身是编码尺寸」还是
          // 「布局/旋转约定不一致」。
          AppLog.d(
            'video-size',
            'w=$_videoWidth h=$_videoHeight rawRotation=$rotation '
                'applied=$_videoRotationCorrection '
                'formatRotation=${event['formatRotation']} '
                'producerHandles=${event['handlesCropAndRotation']}',
          );
          _videoSizeCtrl.add(Size(width.toDouble(), height.toDouble()));
        }
    }
  }
}
