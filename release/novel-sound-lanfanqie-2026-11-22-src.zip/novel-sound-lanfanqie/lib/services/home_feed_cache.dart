import 'dart:async';

import 'package:hive_ce_flutter/hive_flutter.dart';

import 'encrypted_hive.dart';

import '../models/home_cell.dart';
import '../models/media_item.dart';

/// The last rendered page set of one home tab, as previously stored.
class HomeFeedSnapshot {
  final List<MediaItem> items;

  /// The page's block structure (see [HomeCell]), when the rendered page had
  /// one. Without it a cold start seeds only [items], the home page can only
  /// draw that flat grid, and flips to the block layout a second later when
  /// the network answers. Empty for older records written before cells were
  /// cached.
  final List<HomeCell> cells;

  final bool hasMore;
  final DateTime savedAt;

  /// The card the user was last on, if the page reported it. Officially the
  /// short-drama landing cache stores a single video plus its position
  /// (`recordNextVideoData` → `dm3.f.a.i(video, position)`), consumed once on
  /// the first network response; restoring from this vid keeps that intent.
  final String? lastVid;

  const HomeFeedSnapshot({
    required this.items,
    this.cells = const [],
    required this.hasMore,
    required this.savedAt,
    this.lastVid,
  });
}

/// On-disk cache of the home tabs' last rendered feeds.
///
/// Cold start and first visits of a tab render the stored snapshot immediately
/// while the network refresh runs; a failed refresh keeps the snapshot visible
/// instead of an empty error page. This is display state only — pagination
/// cursors are never restored, so a restored tab always refreshes from page
/// one, exactly like the stale-while-revalidate catalogue cache it borrows
/// from.
class HomeFeedCache {
  HomeFeedCache({HiveInterface? hive}) : _hive = hive ?? Hive;

  static final HomeFeedCache instance = HomeFeedCache();
  static const _boxName = 'home_feed_cache_v1';

  /// Bumped when a stored card classification is no longer trustworthy.
  ///
  /// Older builds could rewrite a book recommendation card to `video`; keeping
  /// that snapshot would make the player stream a book id before the refreshed
  /// feed arrives.
  static const _recordVersion = 2;

  /// Snapshots older than this are not restored. The refresh always replaces
  /// them, so the bound only stops a long-absent user from being shown an
  /// ancient feed while the network spins.
  static const ttl = Duration(days: 3);

  /// Upper bound on stored cards per tab. The feed itself can page far beyond
  /// this; the cache only exists to make a restart feel instant.
  static const maxItems = 120;

  /// Set once Hive has a directory (app bootstrap). Widget tests that never
  /// call Hive.initFlutter() leave this false, so nothing touches a box that
  /// cannot be opened yet.
  static bool hiveReady = false;

  final HiveInterface _hive;
  Box<dynamic>? _box;
  Future<Box<dynamic>>? _opening;

  Future<Box<dynamic>> _ensureBox() async {
    final box = _box;
    if (box != null) return box;
    try {
      return _box = await (_opening ??= EncryptedHive.openBox(_hive, _boxName));
    } on Object {
      _opening = null;
      rethrow;
    }
  }

  /// Opens the box ahead of the first [load]. Called (and awaited) from app
  /// bootstrap; a failure leaves [load] returning null and the feed simply
  /// starts cold. Memoized state is reset first, so a caller that closed the
  /// underlying Hive directory (tests do) reopens cleanly.
  Future<void> warmUp() async {
    _box = null;
    _opening = null;
    if (!hiveReady) return;
    try {
      await _ensureBox();
    } catch (_) {
      _box = null;
    }
  }

  HomeFeedSnapshot? load(int tabIndex) {
    final box = _box;
    if (box == null || !box.isOpen) return null;
    final Object? raw;
    try {
      raw = box.get('$tabIndex');
    } catch (_) {
      return null;
    }
    if (raw is! Map) return null;
    if (raw['v'] != _recordVersion) return null;
    final savedAt = raw['savedAt'];
    if (savedAt is! int) return null;
    final age = DateTime.now().millisecondsSinceEpoch - savedAt;
    if (age < 0 || age > ttl.inMilliseconds) return null;
    final itemsRaw = raw['items'];
    if (itemsRaw is! List) return null;
    final items = <MediaItem>[];
    for (final entry in itemsRaw) {
      if (entry is Map) {
        try {
          final item = MediaItemJson.fromJson(Map<String, dynamic>.from(entry));
          if (item != null) items.add(item);
        } catch (_) {
          // One unreadable card is skipped; the rest still render.
        }
      }
    }
    if (items.isEmpty) return null;
    final lastVid = raw['lastVid'];
    // Records written before cells were cached have no `cells` key; they
    // restore with an empty list and the feed falls back to the flat items,
    // exactly as it did before cells were stored.
    final cells = <HomeCell>[];
    final cellsRaw = raw['cells'];
    if (cellsRaw is List) {
      for (final entry in cellsRaw) {
        if (entry is Map) {
          try {
            cells.add(HomeCell.fromMap(Map<String, dynamic>.from(entry)));
          } catch (_) {
            // One unreadable block is skipped; the rest still render.
          }
        }
      }
    }
    return HomeFeedSnapshot(
      items: items,
      cells: cells,
      hasMore: raw['hasMore'] != false,
      savedAt: DateTime.fromMillisecondsSinceEpoch(savedAt),
      lastVid: lastVid is String && lastVid.isNotEmpty ? lastVid : null,
    );
  }

  /// Best-effort write. A failed cache write must never surface to the feed.
  Future<void> save(
    int tabIndex,
    List<MediaItem> items, {
    required bool hasMore,
    String? lastVid,
    List<HomeCell> cells = const [],
  }) async {
    if (!hiveReady || items.isEmpty) return;
    try {
      final box = await _ensureBox();
      await box.put('$tabIndex', {
        'v': _recordVersion,
        'savedAt': DateTime.now().millisecondsSinceEpoch,
        'hasMore': hasMore,
        if (lastVid != null && lastVid.isNotEmpty) 'lastVid': lastVid,
        'items': items.take(maxItems).map((item) => item.toJson()).toList(),
        // The block structure rides along so a cold start renders the block
        // layout on the first frame instead of the legacy flat grid. Written
        // only when present: a record without blocks stays readable by the
        // previous format.
        if (cells.isNotEmpty) 'cells': _boundedCellMaps(cells),
      });
    } catch (_) {
      // The next successful load overwrites this entry anyway.
    }
  }

  /// Serializes [cells] under the same card budget the flat [items] list gets.
  ///
  /// Every appended page lands in the stream block, so without a budget the
  /// tree written on each snapshot grows for as long as the user keeps
  /// scrolling. Block payloads (style, extra, url, name) are kept even after
  /// the budget is spent so section headers still render; only cards are
  /// dropped, and at most [maxItems] top-level blocks are written.
  List<Map<String, dynamic>> _boundedCellMaps(List<HomeCell> cells) {
    var remaining = maxItems;
    List<HomeCell> trim(List<HomeCell> input) {
      final out = <HomeCell>[];
      for (final cell in input.take(maxItems)) {
        final items = <MediaItem>[];
        for (final item in cell.items) {
          if (remaining <= 0) break;
          remaining--;
          items.add(item);
        }
        out.add(
          HomeCell(
            showType: cell.showType,
            name: cell.name,
            id: cell.id,
            style: cell.style,
            items: items,
            children: trim(cell.children),
            url: cell.url,
            extra: cell.extra,
          ),
        );
      }
      return out;
    }

    return [for (final cell in trim(cells)) cell.toMap()];
  }

  /// Test seam: closes the memoized box so a later save reloads fresh storage.
  Future<void> close() async {
    final box = _box;
    _box = null;
    _opening = null;
    try {
      await box?.close();
    } catch (_) {}
  }
}
