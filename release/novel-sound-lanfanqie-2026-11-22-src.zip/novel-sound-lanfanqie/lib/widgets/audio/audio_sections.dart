import 'dart:async';
import 'dart:math' as math;

import 'package:cached_network_image/cached_network_image.dart';
import 'package:material_ui/material_ui.dart';
import 'package:flutter/rendering.dart' show ScrollDirection;
import 'package:flutter_lucide/flutter_lucide.dart';

import '../../models/audio_extra.dart';
import '../../services/audio_page_theme.dart';
import '../../services/playback_format.dart';
import '../../services/poster_cache.dart';
import '../home/home_design.dart';
import 'audio_tone_chip.dart';

/// Listening page header.
///
/// 官方 `layout/hy.xml` 把「智能朗读 │ 真人讲书」放在页头正中央（`a4y` 紧跟
/// `jz4` 这个 81dp 的头部占位），不是标题位置；左右两侧分别是收起箭头与更多
/// 菜单，右侧还有一个橙色星标圆钮。`center` 为空时才退回旧的「听书」标题。
///
/// 手机按样稿取 44dp（桌面窗口沿用 52dp）：返回键 24dp 距左 20dp、更多
/// 22dp 距右 16dp。两者都保留 48dp 宽的点击区，图标在区内居中，所以整块
/// 点击区要再往内收 (48 − 图标)/2，图标的实际外缘才落在规格位置上。
class AudioTopBar extends StatelessWidget {
  final VoidCallback onCollapse;
  final VoidCallback onMore;
  final Widget? center;
  final AudioPageTheme? theme;

  /// 手机顶栏高度（样稿）。
  static const double phoneHeight = 44;

  /// 桌面窗口顶栏高度（沿用旧值）。
  static const double desktopHeight = 52;

  const AudioTopBar({
    super.key,
    required this.onCollapse,
    required this.onMore,
    this.center,
    this.theme,
  });

  @override
  Widget build(BuildContext context) {
    final colors = theme ?? AudioPageThemeScope.of(context);
    final height = MediaQuery.sizeOf(context).width < 600
        ? phoneHeight
        : desktopHeight;
    return SizedBox(
      height: height,
      child: Stack(
        children: [
          Align(
            alignment: Alignment.center,
            child: Semantics(
              header: true,
              // 页签是「智能朗读…｜真人讲书」两颗 16sp 文字，系统字体放大后
              // 整行会比 44dp 的顶栏更宽/更高。保留字号给读屏，但整体按需
              // 等比缩小；两侧各留 56dp 给收起/更多按钮，避免叠在图标上。
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 56),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child:
                      center ??
                      Text(
                        '听书',
                        style: TextStyle(
                          color: colors.ink,
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                ),
              ),
            ),
          ),
          Align(
            alignment: Alignment.centerLeft,
            child: _HeaderIconButton(
              tooltip: '收起',
              icon: LucideIcons.chevron_down,
              iconSize: 24,
              height: height,
              color: colors.ink,
              onPressed: onCollapse,
              edgeInset: 20,
            ),
          ),
          Align(
            alignment: Alignment.centerRight,
            child: _HeaderIconButton(
              tooltip: '更多',
              icon: LucideIcons.ellipsis_vertical,
              iconSize: 22,
              height: height,
              color: colors.ink,
              onPressed: onMore,
              edgeInset: 16,
              fromRight: true,
            ),
          ),
        ],
      ),
    );
  }
}

/// 顶栏两端的图标钮：点击区固定 48dp，整块按 [edgeInset] 让出边距。
///
/// 官方顶部右二那颗橙色星标圆钮是**广告位**，不是功能入口；复刻广告没有
/// 意义，所以这里只保留收起与更多两个按钮。
class _HeaderIconButton extends StatelessWidget {
  final String tooltip;
  final IconData icon;
  final double iconSize;
  final double height;
  final Color color;
  final VoidCallback onPressed;

  /// 图标外缘到屏幕边的距离。
  final double edgeInset;
  final bool fromRight;

  const _HeaderIconButton({
    required this.tooltip,
    required this.icon,
    required this.iconSize,
    required this.height,
    required this.color,
    required this.onPressed,
    required this.edgeInset,
    this.fromRight = false,
  });

  static const double _tapWidth = 48;

  @override
  Widget build(BuildContext context) {
    final inset = edgeInset - (_tapWidth - iconSize) / 2;
    return Padding(
      padding: fromRight
          ? EdgeInsets.only(right: inset)
          : EdgeInsets.only(left: inset),
      child: IconButton(
        tooltip: tooltip,
        onPressed: onPressed,
        iconSize: iconSize,
        style: IconButton.styleFrom(
          foregroundColor: color,
          padding: EdgeInsets.zero,
          minimumSize: Size(_tapWidth, height),
          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
        ),
        icon: Icon(icon),
      ),
    );
  }
}

/// Large cover card mirroring the official listening page: the chapter title
/// and the book title sit on the cover, the whole card opens the catalog, and
/// the top-right button switches the voice.
///
/// 真人讲书 uses the official 7.0.9.32 header instead of that plain cover:
/// `layout/bio.xml` is 72% of the screen wide, its gradient footer carries the
/// episode title, the book title and a `真人讲书・{主播}` row, and the card
/// flips over to the book intro card (`layout/bhi.xml`). All of it is opt-in —
/// a caller that passes neither [realAudio] nor [intro] keeps the original
/// single-sided card.
class AudioBookCard extends StatefulWidget {
  final String cover;
  final String bookTitle;
  final String chapterTitle;
  final VoidCallback? onSwitch;
  final VoidCallback? onOpenBook;

  /// Official 真人讲书 proportions: 72% of the screen, 12dip corners and a
  /// three-line gradient footer.
  final bool realAudio;

  /// Third footer line, e.g. `真人讲书・第 3 集`. Tapping it flips the card.
  final String? modeLabel;

  /// Flip side. Supplying it makes the card two-sided.
  final Widget? intro;

  const AudioBookCard({
    super.key,
    this.cover = '',
    required this.bookTitle,
    required this.chapterTitle,
    this.onSwitch,
    this.onOpenBook,
    this.realAudio = false,
    this.modeLabel,
    this.intro,
  });

  @override
  State<AudioBookCard> createState() => _AudioBookCardState();
}

class _AudioBookCardState extends State<AudioBookCard> {
  bool _showIntro = false;

  void _flip() => setState(() => _showIntro = !_showIntro);

  @override
  Widget build(BuildContext context) {
    final palette = HomePalette.of(context);
    if (!widget.realAudio) {
      // Original single-sided card; the width stays capped so narrow screens
      // still shrink it instead of overflowing.
      return Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 293),
          child: _cover(palette),
        ),
      );
    }
    final width = (MediaQuery.sizeOf(context).width * 0.72).clamp(220.0, 420.0);
    final intro = widget.intro;
    if (intro == null) {
      return Center(
        child: SizedBox(width: width, child: _cover(palette)),
      );
    }
    // 翻转的两面必须同尺寸：背面是填充式卡片，没有固有高度，所以由外层
    // 给出封面的确定尺寸，避免 AnimatedSwitcher 在无界高度下排版失败。
    // 高度必须与 [_cover] 的画幅一致，否则翻面时两面尺寸不等会跳。
    final height = width * _coverAspect;
    return Center(
      child: SizedBox(
        width: width,
        height: height,
        child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 220),
          child: KeyedSubtree(
            key: ValueKey<bool>(_showIntro),
            child: _showIntro
                ? _IntroSide(onBack: _flip, child: intro)
                : _cover(palette),
          ),
        ),
      ),
    );
  }

  /// 封面画幅：书封本身就是竖版，框也用竖版，`BoxFit.cover` 才不裁图。
  ///
  /// 所有调用方传的都是同一张竖版 `MediaItem.cover`（仓库里没有单独的方形
  /// 听书图），而详情页封面 3:4、信息流 5:7 用的也是这张图。原先的
  /// 293/313 近正方形框把竖版图上下裁掉约两成，对应 issue #85
  /// 「书籍封面显示不完整」。
  static const double _coverAspect = 3 / 4;

  Widget _cover(HomePalette palette) {
    final real = widget.realAudio;
    return AspectRatio(
      aspectRatio: _coverAspect,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(real ? 12 : 10),
        child: LayoutBuilder(
          builder: (context, constraints) => Stack(
            fit: StackFit.expand,
            children: [
              _CoverImage(
                url: widget.cover,
                placeholder: palette.soft,
                iconColor: palette.muted,
              ),
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                height: real ? math.max(96, constraints.maxWidth * 0.37) : 150,
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.transparent,
                        Colors.black.withValues(alpha: 0.72),
                      ],
                    ),
                  ),
                ),
              ),
              if (real)
                Positioned(left: 0, right: 0, bottom: 0, child: _realFooter())
              else ...[
                Positioned(
                  left: 14,
                  right: 14,
                  bottom: 58,
                  child: Text(
                    widget.chapterTitle,
                    key: const Key('audio_chapter_title'),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      height: 1.3,
                    ),
                  ),
                ),
                // Keep the full-cover catalog target below the two buttons.
                // See .agents/notes/implemented/bug-fix/2026-09-16-cross-review-boundaries.md.
                Positioned.fill(
                  child: GestureDetector(
                    behavior: HitTestBehavior.translucent,
                    onTap: widget.onOpenBook,
                  ),
                ),
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 15,
                  height: 35,
                  child: HomePressable(
                    key: const Key('audio_book_bar'),
                    semanticLabel: '查看目录',
                    onTap: widget.onOpenBook ?? () {},
                    borderRadius: BorderRadius.zero,
                    child: Container(
                      color: Colors.black.withValues(alpha: 0.3),
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              widget.bookTitle,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 12.5,
                              ),
                            ),
                          ),
                          const SizedBox(width: 6),
                          const Icon(
                            LucideIcons.chevron_right,
                            size: 13,
                            color: Colors.white70,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
              Positioned(
                top: 8,
                right: 8,
                child: HomePressable(
                  key: const Key('audio_cover_switch'),
                  semanticLabel: '切换音色',
                  onTap: widget.onSwitch ?? () {},
                  borderRadius: BorderRadius.circular(12),
                  child: Container(
                    width: 24,
                    height: 24,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.28),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      LucideIcons.repeat,
                      size: 13,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// `bio.xml` footer: 集标题 (18sp) / 书名 (18sp bold) / 副行 (14sp + chevron).
  /// The rows sit above the catalog tap target so each keeps its own action.
  Widget _realFooter() {
    final label = widget.modeLabel;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            widget.chapterTitle,
            key: const Key('audio_chapter_title'),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.w600,
              height: 1.3,
            ),
          ),
          const SizedBox(height: 2),
          HomePressable(
            key: const Key('audio_book_bar'),
            semanticLabel: '查看目录',
            onTap: widget.onOpenBook ?? () {},
            borderRadius: BorderRadius.circular(6),
            child: SizedBox(
              width: double.infinity,
              child: Text(
                widget.bookTitle,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  height: 1.3,
                ),
              ),
            ),
          ),
          if (label != null && label.isNotEmpty) ...[
            const SizedBox(height: 8),
            HomePressable(
              key: const Key('audio_mode_row'),
              semanticLabel: label,
              onTap: widget.intro == null ? () {} : _flip,
              borderRadius: BorderRadius.circular(6),
              child: Row(
                children: [
                  Flexible(
                    child: Text(
                      label,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Color(0xB3FFFFFF),
                        fontSize: 14,
                        height: 1.3,
                      ),
                    ),
                  ),
                  const SizedBox(width: 4),
                  const Icon(
                    LucideIcons.chevron_right,
                    size: 13,
                    color: Color(0xB3FFFFFF),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

/// Back side of the cover card: the intro plus the way back.
class _IntroSide extends StatelessWidget {
  final VoidCallback onBack;
  final Widget child;

  const _IntroSide({required this.onBack, required this.child});

  @override
  Widget build(BuildContext context) {
    final palette = HomePalette.of(context);
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Stack(
        fit: StackFit.expand,
        children: [
          child,
          Positioned(
            top: 6,
            right: 6,
            child: HomePressable(
              key: const Key('audio_cover_back'),
              semanticLabel: '返回封面',
              onTap: onBack,
              borderRadius: BorderRadius.circular(12),
              child: Container(
                width: 24,
                height: 24,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: palette.soft,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  LucideIcons.chevron_down,
                  size: 13,
                  color: palette.muted,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _CoverImage extends StatelessWidget {
  final String url;

  /// 占位底色与图标色由调用方给：旧卡片用 HomePalette，简介卡用取色主题。
  final Color placeholder;
  final Color iconColor;

  const _CoverImage({
    required this.url,
    required this.placeholder,
    required this.iconColor,
  });

  @override
  Widget build(BuildContext context) {
    if (url.isEmpty) {
      return Container(
        color: placeholder,
        alignment: Alignment.center,
        child: Icon(LucideIcons.book_open, color: iconColor, size: 36),
      );
    }
    return CachedNetworkImage(
      cacheManager: PosterCache.instance,
      imageUrl: url,
      fit: BoxFit.cover,
      // The big cover renders at ~293 logical px; decode at 2× instead of the
      // original resolution (typically 600-1000px wide).
      memCacheWidth: 640,
      fadeInDuration: Duration.zero,
      fadeOutDuration: Duration.zero,
      placeholder: (context, _) => Container(color: placeholder),
      errorWidget: (context, _, _) => Container(
        color: placeholder,
        alignment: Alignment.center,
        child: Icon(LucideIcons.book_open, color: iconColor, size: 36),
      ),
    );
  }
}

/// Two-line opening excerpt of the current chapter.
class AudioExcerpt extends StatelessWidget {
  final String text;
  final VoidCallback? onTap;

  const AudioExcerpt({super.key, required this.text, this.onTap});

  @override
  Widget build(BuildContext context) {
    final theme = AudioPageThemeScope.of(context);
    return HomePressable(
      semanticLabel: '章节试读',
      onTap: onTap ?? () {},
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
        child: ExcludeSemantics(
          child: Text(
            text,
            key: const Key('audio_excerpt'),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: theme.ink.withValues(alpha: 0.82),
              fontSize: 15,
              height: 1.5,
            ),
          ),
        ),
      ),
    );
  }
}

/// Companion works: the original novel and any adaptation.
class AudioRelatedRow extends StatelessWidget {
  final List<RelatedWork> works;
  final void Function(RelatedWork work) onTap;

  const AudioRelatedRow({super.key, required this.works, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final theme = AudioPageThemeScope.of(context);
    if (works.isEmpty) return const SizedBox.shrink();
    final textScaler = MediaQuery.textScalerOf(context);
    // A horizontal list forces a tight height on its cards, so derive the row
    // height from the scaled title/label instead of a fixed 76px.
    final rowHeight = math.max(
      76.0,
      textScaler.scale(12.5) * 1.35 * 2 +
          textScaler.scale(11) * 1.4 +
          5 +
          16 +
          4,
    );
    return SizedBox(
      height: rowHeight,
      child: ListView.separated(
        key: const Key('audio_related_row'),
        scrollDirection: Axis.horizontal,
        itemCount: works.length,
        separatorBuilder: (context, _) => const SizedBox(width: 10),
        itemBuilder: (context, index) {
          final work = works[index];
          return HomePressable(
            key: ValueKey('audio_related_${work.kind}_${work.id}'),
            semanticLabel: '${work.label}：${work.title}',
            onTap: () => onTap(work),
            borderRadius: BorderRadius.circular(12),
            child: Container(
              width: 218,
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: theme.card,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: theme.line.withValues(alpha: 0.8)),
              ),
              child: Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: SizedBox(
                      width: 44,
                      height: 58,
                      child: work.cover.isEmpty
                          ? ColoredBox(
                              color: theme.card,
                              child: Icon(
                                work.kind == 'video'
                                    ? LucideIcons.clapperboard
                                    : LucideIcons.book,
                                size: 18,
                                color: theme.muted,
                              ),
                            )
                          : Image.network(
                              work.cover,
                              fit: BoxFit.cover,
                              // 44x58 logical thumbnail; decode at 2×.
                              cacheWidth: 96,
                              errorBuilder: (context, _, _) => ColoredBox(
                                color: theme.card,
                                child: Icon(
                                  LucideIcons.book,
                                  size: 18,
                                  color: theme.muted,
                                ),
                              ),
                            ),
                    ),
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          work.title,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: theme.ink,
                            fontSize: 12.5,
                            fontWeight: FontWeight.w600,
                            height: 1.35,
                          ),
                        ),
                        const SizedBox(height: 5),
                        Text(
                          work.label,
                          style: TextStyle(color: theme.muted, fontSize: 11),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

/// 边听边读: the line being spoken plus the next one.
class AudioSubtitleView extends StatelessWidget {
  final SubtitleTrack track;
  final Duration position;

  const AudioSubtitleView({
    super.key,
    required this.track,
    required this.position,
  });

  @override
  Widget build(BuildContext context) {
    final palette = HomePalette.of(context);
    if (track.isEmpty) return const SizedBox.shrink();
    final (current, next) = track.windowAt(position);
    if (current == null && next == null) return const SizedBox.shrink();
    return Padding(
      key: const Key('audio_subtitles'),
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (current != null)
            Text(
              current.text,
              key: const Key('audio_subtitle_current'),
              style: TextStyle(
                color: palette.ink,
                fontSize: 15,
                fontWeight: FontWeight.w600,
                height: 1.6,
              ),
            ),
          if (next != null) ...[
            const SizedBox(height: 6),
            Text(
              next.text,
              key: const Key('audio_subtitle_next'),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: palette.muted.withValues(alpha: 0.75),
                fontSize: 14,
                height: 1.6,
              ),
            ),
          ],
        ],
      ),
    );
  }
}

/// 桌面端「同步字幕」列表：跟着朗读进度自动滚动，并把当前句高亮出来。
///
/// 以前这里是 `ListView.builder` + `selected:`：高亮确实会跟着进度走，但列表
/// 永远停在开头 —— 念到第 80 句时用户还看着第 1 句，只能自己一路往下滚，看起来
/// 就是「字幕不跟随朗读」。现在当前句一变就把它滚进可视区（略偏上，下一句也看
/// 得见），并加一条左侧强调色细线，滚动中也能一眼认出念到哪。
///
/// 只滚这一条列表，不用 `Scrollable.ensureVisible`：那个会把外面 `TabBarView`
/// 的横向 `PageView` 也算进来，切句时会顺手拨一下标签页。
class AudioSubtitleList extends StatefulWidget {
  const AudioSubtitleList({
    super.key,
    required this.track,
    required this.active,
    this.onSeek,
  });

  final SubtitleTrack track;

  /// 当前句下标，`-1` 表示还没念到第一句。
  final int active;

  /// 点某一句跳过去（参数是这一句的起始毫秒）；null 表示还没就绪。
  final ValueChanged<int>? onSeek;

  @override
  State<AudioSubtitleList> createState() => _AudioSubtitleListState();
}

class _AudioSubtitleListState extends State<AudioSubtitleList> {
  final _controller = ScrollController();

  /// 只为已经构建出来的行留 key：`ListView.builder` 会回收视图外的行，那些行
  /// 没有 context，也就无从 `ensureVisible`。
  final _rowKeys = <int, GlobalKey>{};

  /// 用户刚自己滚过之后开着的计时器。跟随是默认行为，但不该跟手动滚动抢
  /// 方向盘；用 `Timer` 而不是记一个 `DateTime.now()` 截止点，`tester.pump()`
  /// 才能把这段窗口推过去。
  Timer? _hold;

  /// 暂停跟随期间换到的句子：等暂停结束要补一次，否则这一句永远不出现。
  int? _pending;

  static const _holdWindow = Duration(seconds: 4);

  /// 看引用而不是 `Timer.isActive`：计时器在自己的回调里跑的时候 `isActive`
  /// 还是 true，用它会把自己认成「暂停中」。
  bool get _holding => _hold != null;

  @override
  void initState() {
    super.initState();
    // 打开面板时可能已经念到中段：先落一次位，不用等下一句才跳。
    if (widget.active >= 0) _reveal(widget.active);
  }

  @override
  void dispose() {
    _hold?.cancel();
    _controller.dispose();
    super.dispose();
  }

  @override
  void didUpdateWidget(AudioSubtitleList oldWidget) {
    super.didUpdateWidget(oldWidget);
    // 只在「换句」时动，不是每次位置回调（5Hz）都动。
    if (widget.active >= 0 && widget.active != oldWidget.active) {
      _reveal(widget.active);
    }
  }

  bool _onScroll(ScrollNotification notification) {
    // 桌面端的主要输入是滚轮/触控板，走 `pointerScroll`：它和拖拽一样会
    // `updateUserScrollDirection`，但它的 `ScrollStartNotification` 没有
    // `dragDetails`（那个只有 `DragScrollActivity` 才给）。所以看滚动方向 ——
    // 我们自己发起的 `jumpTo`/`animateTo` 不会更新方向，最多顺带发一个
    // `idle`，不会把暂停重新打开。
    if (notification is UserScrollNotification &&
        notification.direction != ScrollDirection.idle) {
      _hold?.cancel();
      _hold = Timer(_holdWindow, _onHoldExpired);
    }
    return false;
  }

  void _onHoldExpired() {
    _hold = null;
    final pending = _pending;
    _pending = null;
    if (pending != null) _reveal(pending);
  }

  void _reveal(int index) {
    if (_holding) {
      _pending = index;
      return;
    }
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || !_controller.hasClients) return;
      if (_holding) {
        _pending = index;
        return;
      }
      final row = _rowKeys[index]?.currentContext;
      if (row != null) {
        _scrollTo(row);
        return;
      }
      // 跳得很远时目标行还没构建：先按比例落到大概位置，再逐帧精确对位。
      _jumpByRatio(index);
      _revealWithin(index, 4);
    });
    // 暂停跟随靠计时器结束，那时未必还有帧在跑（比如播放已暂停），只把回调
    // 排上队没人来跑它 —— 把帧叫醒。
    WidgetsBinding.instance.ensureVisualUpdate();
  }

  /// 粗定位之后的逐帧纠正：目标行一出现就精确对位，最多试 [frames] 帧就放弃。
  ///
  /// 一次纠正不够：`maxScrollExtent` 是按已构建行外推的，字幕行高 48–100px
  /// 不等，比例落点可能偏出一屏以上，那一帧目标行的 key 还是 null，之后就再
  /// 没有机会了。每帧重算一次比例落点，因为落位后已构建的行更接近真值。
  void _revealWithin(int index, int frames) {
    if (frames <= 0) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || !_controller.hasClients) return;
      if (_holding) {
        _pending = index;
        return;
      }
      final row = _rowKeys[index]?.currentContext;
      if (row != null) {
        _scrollTo(row);
      } else {
        _jumpByRatio(index);
        _revealWithin(index, frames - 1);
      }
    });
    WidgetsBinding.instance.ensureVisualUpdate();
  }

  void _jumpByRatio(int index) {
    final cues = widget.track.cues.length;
    final ratio = cues <= 1 ? 0.0 : index / (cues - 1);
    final position = _controller.position;
    _controller.jumpTo(
      (position.maxScrollExtent * ratio).clamp(0.0, position.maxScrollExtent),
    );
  }

  void _scrollTo(BuildContext row) {
    final object = row.findRenderObject();
    if (object == null || !_controller.hasClients) return;
    unawaited(
      _controller.position.ensureVisible(
        object,
        // 0.32：当前句偏上留白，下一句、下下句都在视野里，读起来不跳。
        alignment: 0.32,
        duration: MediaQuery.disableAnimationsOf(row)
            ? Duration.zero
            : const Duration(milliseconds: 220),
        curve: Curves.easeOutCubic,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final palette = HomePalette.of(context);
    final cues = widget.track.cues;
    return NotificationListener<ScrollNotification>(
      onNotification: _onScroll,
      // `Ink` 把图案登记到最近的 Material 上，而 Material 只按自己的尺寸裁：
      // 页面级 Material 跟整页一样大，半滚出视口的那一行就会把底色和左侧细线
      // 画到列表上方（TabBar）去。这里垫一层列表自己的透明 Material，让高亮
      // 画进列表的盒子；保留 Material 祖先，ListTile 的涟漪断言也不会响。
      child: Material(
        type: MaterialType.transparency,
        child: ListView.builder(
          key: const Key('audio_subtitle_list'),
          controller: _controller,
          itemCount: cues.length,
          itemBuilder: (context, index) {
            final cue = cues[index];
            final active = index == widget.active;
            // 高亮底色与左侧细线用 `Ink` 而不是 `Container`：ListTile 的点按
            // 涟漪画在最近的 Material 上，中间夹一层带底色的 DecoratedBox 会把
            // 涟漪整个挡住，框架断言直接拦下（CI 实测过）。`Ink` 把装饰画进
            // Material 层，涟漪照常浮在上面。
            return Ink(
              key: _rowKeys.putIfAbsent(index, GlobalKey.new),
              decoration: BoxDecoration(
                color: active
                    ? HomePalette.accent.withValues(alpha: 0.10)
                    : Colors.transparent,
                border: Border(
                  left: BorderSide(
                    width: 3,
                    color: active ? HomePalette.accent : Colors.transparent,
                  ),
                ),
              ),
              child: ListTile(
                dense: true,
                selected: active,
                title: Text(
                  cue.text,
                  key: ValueKey('audio_subtitle_row_$index'),
                  style: TextStyle(
                    fontSize: 14,
                    height: 1.5,
                    fontWeight: active ? FontWeight.w600 : FontWeight.w400,
                    color: active ? palette.ink : palette.muted,
                  ),
                ),
                onTap: widget.onSeek == null
                    ? null
                    : () => widget.onSeek!(cue.startMs),
              ),
            );
          },
        ),
      ),
    );
  }
}

/// `layout/bjg.xml`: 24dp 后退/前进图标夹一条 2dip 细轨。
///
/// 官方默认不在这行放时间文字——带左右时间的那套（`fud`）在 7.0.9.32 里是
/// `visibility="gone"` 的备用变体，时长信息由页头与拖动标签承担。
class AudioProgressRow extends StatelessWidget {
  final Duration position;
  final Duration duration;
  final double? preview;
  final bool enabled;
  final ValueChanged<double>? onChanged;
  final ValueChanged<double>? onChangeEnd;
  final VoidCallback? onBack15;
  final VoidCallback? onForward15;

  const AudioProgressRow({
    super.key,
    required this.position,
    required this.duration,
    this.preview,
    this.enabled = true,
    this.onChanged,
    this.onChangeEnd,
    this.onBack15,
    this.onForward15,
  });

  static String time(Duration value) => formatPlaybackTime(value);

  @override
  Widget build(BuildContext context) {
    final palette = HomePalette.of(context);
    final maximum = duration.inMilliseconds.toDouble();
    final value = (preview ?? position.inMilliseconds.toDouble()).clamp(
      0.0,
      maximum > 0 ? maximum : 1.0,
    );
    final active = enabled && maximum > 0;
    return Row(
      children: [
        _SkipIcon(
          icon: LucideIcons.rotate_ccw,
          tooltip: '后退15秒',
          onTap: onBack15,
        ),
        Expanded(
          child: SliderTheme(
            data: SliderTheme.of(context).copyWith(
              trackHeight: 2,
              activeTrackColor: palette.accentText,
              inactiveTrackColor: palette.line,
              thumbColor: palette.accentText,
              overlayShape: const RoundSliderOverlayShape(overlayRadius: 12),
              thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 4.5),
            ),
            child: Slider(
              key: const ValueKey('audio-seek'),
              value: value,
              max: maximum > 0 ? maximum : 1,
              label: time(Duration(milliseconds: value.round())),
              onChanged: active ? onChanged : null,
              onChangeEnd: active ? onChangeEnd : null,
            ),
          ),
        ),
        _SkipIcon(
          icon: LucideIcons.rotate_cw,
          tooltip: '前进15秒',
          onTap: onForward15,
        ),
      ],
    );
  }
}

class _SkipIcon extends StatelessWidget {
  final IconData icon;
  final String tooltip;
  final VoidCallback? onTap;

  const _SkipIcon({
    required this.icon,
    required this.tooltip,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final palette = HomePalette.of(context);
    return IconButton(
      tooltip: tooltip,
      onPressed: onTap,
      visualDensity: VisualDensity.compact,
      iconSize: 24,
      style: IconButton.styleFrom(
        foregroundColor: palette.muted,
        disabledForegroundColor: palette.line,
      ),
      icon: Icon(icon),
    );
  }
}

/// Official two-card voice area: the left card lists the selectable voices
/// (智能朗读 / 真人讲书) and the right card is the 边听边读 entry.
class AudioToneSection extends StatelessWidget {
  final String title;
  final List<AudioTone> tones;
  final String selectedId;
  final String currentChapterTitle;
  final ValueChanged<AudioTone> onSelect;
  final VoidCallback onReadAlong;
  final VoidCallback? onShowVoices;

  const AudioToneSection({
    super.key,
    this.title = '智能朗读',
    required this.tones,
    required this.selectedId,
    required this.currentChapterTitle,
    required this.onSelect,
    required this.onReadAlong,
    this.onShowVoices,
  });

  @override
  Widget build(BuildContext context) {
    final textScaler = MediaQuery.textScalerOf(context);
    final headerHeight = textScaler.scale(15) * 1.5 + 8;
    // 官方片内是 15sp 标题 + 12.5sp 副标题，外加 10/8 内边距与 4dp 间距。
    final chipHeight = math.max(
      64.0,
      textScaler.scale(15) * 1.3 + textScaler.scale(12.5) * 1.3 + 30,
    );
    // 左卡是「标题 + 音色片」，右卡是「标题 + 两行章节名」，两者都要装得下。
    final cardHeight = math.max(
      116.0,
      math.max(
        16 + headerHeight + 4 + chipHeight,
        16 + headerHeight + 8 + textScaler.scale(13) * 1.5 * 2,
      ),
    );
    final ordered = [...tones];
    // 选中的音色排最前，当前生效的选择一眼可见。
    ordered.sort((a, b) {
      if (a.id == selectedId) return -1;
      if (b.id == selectedId) return 1;
      return 0;
    });
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          flex: 237,
          child: _AudioSectionCard(
            height: cardHeight,
            headerKey: const Key('audio-voice'),
            semanticLabel: '选择音色',
            title: title,
            onHeader: onShowVoices,
            body: ordered.isEmpty
                ? const _EmptyTones()
                : SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: Row(
                      children: [
                        for (var i = 0; i < ordered.length; i++) ...[
                          if (i > 0) const SizedBox(width: 6),
                          AudioToneChip(
                            tone: ordered[i],
                            height: chipHeight,
                            selected: ordered[i].id == selectedId,
                            onTap: () => onSelect(ordered[i]),
                          ),
                        ],
                      ],
                    ),
                  ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          flex: 133,
          child: _AudioSectionCard(
            height: cardHeight,
            headerKey: const Key('audio_read_along'),
            semanticLabel: '边听边读',
            title: '边听边读',
            onHeader: onReadAlong,
            body: _ReadAlongBody(title: currentChapterTitle),
          ),
        ),
      ],
    );
  }
}

/// 音色区里两张并排卡片的共同外壳：卡面 `theme.card`、12dp 圆角、
/// 一行「标题 + chevron」表头。
class _AudioSectionCard extends StatelessWidget {
  final double height;
  final Key headerKey;
  final String semanticLabel;
  final String title;
  final VoidCallback? onHeader;
  final Widget body;

  const _AudioSectionCard({
    required this.height,
    required this.headerKey,
    required this.semanticLabel,
    required this.title,
    required this.onHeader,
    required this.body,
  });

  @override
  Widget build(BuildContext context) {
    final theme = AudioPageThemeScope.of(context);
    return Container(
      height: height,
      padding: const EdgeInsets.fromLTRB(4, 8, 4, 8),
      decoration: BoxDecoration(
        color: theme.card,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          HomePressable(
            key: headerKey,
            semanticLabel: semanticLabel,
            onTap: onHeader ?? () {},
            borderRadius: BorderRadius.circular(6),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Row(
                children: [
                  Flexible(
                    child: Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: theme.ink,
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  const SizedBox(width: 4),
                  Icon(LucideIcons.chevron_right, size: 13, color: theme.muted),
                ],
              ),
            ),
          ),
          const SizedBox(height: 4),
          Expanded(child: body),
        ],
      ),
    );
  }
}

class _EmptyTones extends StatelessWidget {
  const _EmptyTones();

  @override
  Widget build(BuildContext context) {
    final theme = AudioPageThemeScope.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: Align(
        alignment: Alignment.centerLeft,
        child: Text(
          '暂无可选音色',
          style: TextStyle(color: theme.muted, fontSize: 12),
        ),
      ),
    );
  }
}

/// 「边听边读」卡里那两行章节名。
class _ReadAlongBody extends StatelessWidget {
  final String title;

  const _ReadAlongBody({required this.title});

  @override
  Widget build(BuildContext context) {
    final theme = AudioPageThemeScope.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 4, 8, 0),
      child: Text(
        title,
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          color: theme.ink,
          fontSize: 13,
          height: 1.35,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}

/// Stable mode header; unsupported or loading choices stay disabled.
class AudioModeSwitch extends StatelessWidget {
  final bool realSelected;
  final VoidCallback? onSelectTts;
  final VoidCallback? onSelectNarrator;

  const AudioModeSwitch({
    super.key,
    required this.realSelected,
    required this.onSelectTts,
    required this.onSelectNarrator,
  });

  @override
  Widget build(BuildContext context) {
    final theme = AudioPageThemeScope.of(context);
    return Center(
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _tab(
            key: const Key('audio_mode_tts'),
            label: '智能朗读',
            selected: !realSelected,
            theme: theme,
            onTap: onSelectTts,
          ),
          // 0.5 × 8dp 竖线；两侧各 9dp 由页签的内边距让出（样稿 `.tabs`）。
          Container(
            width: 0.5,
            height: 8,
            color: theme.muted.withValues(alpha: 0.8),
          ),
          _tab(
            key: const Key('audio_mode_narrator'),
            label: '真人讲书',
            selected: realSelected,
            theme: theme,
            onTap: onSelectNarrator,
          ),
        ],
      ),
    );
  }

  Widget _tab({
    required Key key,
    required String label,
    required bool selected,
    required AudioPageTheme theme,
    required VoidCallback? onTap,
  }) {
    return Semantics(
      label: label,
      selected: selected,
      enabled: onTap != null,
      button: true,
      excludeSemantics: true,
      onTap: onTap,
      child: IgnorePointer(
        ignoring: onTap == null,
        child: HomePressable(
          key: key,
          onTap: onTap ?? () {},
          borderRadius: BorderRadius.circular(8),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
            child: Text(
              label,
              style: TextStyle(
                color: selected
                    ? theme.ink
                    : onTap == null
                    ? theme.muted.withValues(alpha: 0.45)
                    : theme.muted,
                fontSize: 16,
                fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Both voice families share a compact entry into the voice settings sheet.
class AudioVoiceRow extends StatelessWidget {
  final String modeLabel;
  final String voiceLabel;
  final VoidCallback? onTap;

  const AudioVoiceRow({
    super.key,
    required this.modeLabel,
    required this.voiceLabel,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = AudioPageThemeScope.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 0),
      child: Semantics(
        label: '选择音色',
        enabled: onTap != null,
        button: true,
        excludeSemantics: true,
        onTap: onTap,
        child: HomePressable(
          key: const Key('audio-voice'),
          semanticLabel: '选择音色',
          onTap: onTap ?? () {},
          borderRadius: BorderRadius.circular(12),
          child: Container(
            constraints: const BoxConstraints(minHeight: 54),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: theme.card,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                Text(
                  modeLabel,
                  style: TextStyle(
                    color: theme.accent,
                    fontSize: 13.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    voiceLabel.isEmpty ? '暂无可选音色' : voiceLabel,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: voiceLabel.isEmpty ? theme.muted : theme.ink,
                      fontSize: 13.5,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                Text('声音', style: TextStyle(color: theme.muted, fontSize: 12)),
                const SizedBox(width: 2),
                Icon(LucideIcons.chevron_right, size: 14, color: theme.muted),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Book details sheet: thumbnail, title, author, summary and a related work.
class AudioIntroCard extends StatefulWidget {
  final String cover;
  final String title;
  final String author;
  final List<String> meta;
  final String summary;
  final RelatedWork? related;
  final void Function(RelatedWork work)? onOpenRelated;

  const AudioIntroCard({
    super.key,
    this.cover = '',
    required this.title,
    this.author = '',
    this.meta = const [],
    this.summary = '',
    this.related,
    this.onOpenRelated,
  });

  @override
  State<AudioIntroCard> createState() => _AudioIntroCardState();
}

class _AudioIntroCardState extends State<AudioIntroCard> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    final theme = AudioPageThemeScope.of(context);
    final related = widget.related;
    final summary = widget.summary.isEmpty ? '暂无简介' : widget.summary;
    return ColoredBox(
      color: theme.card,
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            _header(theme),
            const SizedBox(height: 10),
            Divider(height: 1, color: theme.line.withValues(alpha: 0.7)),
            const SizedBox(height: 10),
            Text(
              '简介',
              style: TextStyle(
                color: theme.muted,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              summary,
              key: const Key('audio_intro_summary'),
              maxLines: _expanded ? 40 : 3,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(color: theme.ink, fontSize: 13, height: 1.6),
            ),
            if (summary.length > 60)
              GestureDetector(
                key: const Key('audio_intro_more'),
                onTap: () => setState(() => _expanded = !_expanded),
                child: Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text(
                    _expanded ? '收起' : '展开',
                    style: TextStyle(
                      color: theme.accent,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            if (related != null) ...[
              const SizedBox(height: 10),
              HomePressable(
                key: const Key('audio_intro_related'),
                semanticLabel: '${related.label}：${related.title}',
                onTap: () => widget.onOpenRelated?.call(related),
                borderRadius: BorderRadius.circular(8),
                child: Row(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: SizedBox(
                        width: 28,
                        height: 40,
                        child: related.cover.isEmpty
                            ? ColoredBox(
                                color: theme.card,
                                child: Icon(
                                  related.kind == 'video'
                                      ? LucideIcons.clapperboard
                                      : LucideIcons.book,
                                  size: 14,
                                  color: theme.muted,
                                ),
                              )
                            : Image.network(
                                related.cover,
                                fit: BoxFit.cover,
                                cacheWidth: 64,
                                errorBuilder: (context, _, _) => ColoredBox(
                                  color: theme.card,
                                  child: Icon(
                                    LucideIcons.book,
                                    size: 14,
                                    color: theme.muted,
                                  ),
                                ),
                              ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            related.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: theme.ink,
                              fontSize: 12.5,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          Text(
                            related.label,
                            style: TextStyle(color: theme.muted, fontSize: 11),
                          ),
                        ],
                      ),
                    ),
                    Icon(
                      LucideIcons.chevron_right,
                      size: 14,
                      color: theme.muted,
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  /// 简介卡的头部：缩略图 + 书名 + 作者 + 元信息。
  Widget _header(AudioPageTheme theme) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: SizedBox(
            width: 36,
            height: 54,
            child: _CoverImage(
              url: widget.cover,
              placeholder: theme.card,
              iconColor: theme.muted,
            ),
          ),
        ),
        const SizedBox(width: 9),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                widget.title,
                key: const Key('audio_intro_title'),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: theme.ink,
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  height: 1.3,
                ),
              ),
              if (widget.author.isNotEmpty) ...[
                const SizedBox(height: 3),
                Text(
                  widget.author,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: theme.muted, fontSize: 12),
                ),
              ],
              if (widget.meta.isNotEmpty) ...[
                const SizedBox(height: 3),
                Text(
                  widget.meta.join(' · '),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: theme.muted, fontSize: 11),
                ),
              ],
            ],
          ),
        ),
      ],
    );
  }
}
