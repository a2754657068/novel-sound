part of '../../pages/audio_page.dart';

/// The last-listened book offered by the idle capsule after a cold start.
class RecentListen {
  const RecentListen({
    required this.bookId,
    required this.title,
    required this.cover,
    required this.progress,
    required this.request,
  });

  final String bookId;
  final String title;
  final String cover;

  /// Whole-book listened fraction, 0..1.
  final double progress;

  /// Builds the listening request; loading the directory may fail.
  final Future<AudioPage> Function() request;
}

typedef RecentListenLoader = Future<RecentListen?> Function();

/// Official cold start (`recentread/j0.java` `m0`): when the newest reading
/// record is a listen-type book, the home shell shows the idle capsule with
/// its saved progress. Returns null otherwise.
Future<RecentListen?> loadRecentListen() async {
  final history = await LibraryStore.instance.history();
  if (history.isEmpty) return null;
  final entry = history.first;
  if (entry['kind'] != 'audio') return null;
  final bookId = historyContentId(entry);
  if (bookId.isEmpty) return null;
  final chapter = (entry['progress'] as num?)?.toDouble() ?? 0;
  final episode = (entry['episode'] as num?)?.toDouble() ?? 0;
  final count = (entry['chapterCount'] as num?)?.toDouble() ?? 0;
  final progress = count > 0 ? (episode + chapter) / count : chapter;
  final title = entry['title']?.toString() ?? '';
  final cover = entry['cover']?.toString() ?? '';
  return RecentListen(
    bookId: bookId,
    title: title,
    cover: cover,
    progress: progress.isFinite ? progress.clamp(0.0, 1.0) : 0,
    request: () async {
      final volumes = await ApiClient.instance.directoryChapters(
        bookId,
        tab: '听书',
      );
      final chapters = [for (final volume in volumes) ...volume];
      if (chapters.isEmpty) throw const FormatException('暂无听书目录');
      return AudioPage(
        bookId: bookId,
        title: title,
        cover: cover,
        chapters: chapters,
        startIndex: resumeAudioChapterIndex(entry, chapters) ?? 0,
      );
    },
  );
}

/// The capsule half of [_AudioPlaybackScopeState]: it lives in the
/// Navigator's Overlay, while the state owns sessions and their queue.
extension _AudioCapsule on _AudioPlaybackScopeState {
  Future<void> _resumeRecent(RecentListen recent, {required bool open}) async {
    if (_resuming) return;
    _resuming = true;
    _changed();
    try {
      final request = await recent.request();
      if (!mounted || !identical(_recent, recent)) return;
      final navigator = widget.navigatorKey.currentState;
      if (open && navigator != null) {
        unawaited(
          navigator.push<void>(MaterialPageRoute(builder: (_) => request)),
        );
      } else {
        await acquire(request);
      }
    } catch (_) {
      _toast('暂时无法继续收听，请稍后重试');
    } finally {
      _resuming = false;
      _changed();
    }
  }

  /// A listening page left in the back stack can't restart a closed session.
  /// Officially closing the capsule exits AudioPlayActivity too, so drop
  /// those pages; the page the user is looking at stays put.
  void _retireViews(_AudioPlaybackController session) {
    final navigator = widget.navigatorKey.currentState;
    if (navigator == null) return;
    for (final view in _views.toList()) {
      if (!view.mounted || !identical(view._session, session)) continue;
      final route = ModalRoute.of(view.context);
      if (route == null ||
          route.isCurrent ||
          !route.isActive ||
          route.navigator != navigator) {
        continue;
      }
      navigator.removeRoute(route);
    }
  }

  void _openAudio(_AudioPlaybackController session) {
    if (!identical(_session, session) || session._closed) return;
    final navigator = widget.navigatorKey.currentState;
    if (navigator == null) return;
    for (final view in _views.toList().reversed) {
      if (!view.mounted || !identical(view._session, session)) continue;
      final route = ModalRoute.of(view.context);
      if (route == null || !route.isActive || route.navigator != navigator) {
        continue;
      }
      navigator.popUntil((candidate) => identical(candidate, route));
      return;
    }
    if (identical(_openingAudio, session)) return;
    _openingAudio = session;
    final request = session.request;
    unawaited(
      navigator
          .push<void>(
            MaterialPageRoute<void>(
              builder: (_) => AudioPage(
                bookId: session._bookId,
                title: session._title,
                cover: session._cover,
                chapters: session._chapters,
                startIndex: session._index,
                historyStore: request.historyStore,
                playerFactory: request.playerFactory,
                sourceLoader: request.sourceLoader,
                voicesLoader: request.voicesLoader,
                extrasLoader: request.extrasLoader,
                subtitleLoader: request.subtitleLoader,
                timePointLoader: request.timePointLoader,
                excerptLoader: request.excerptLoader,
                directoryLoader: request.directoryLoader,
                downloadStore: request.downloadStore,
              ),
            ),
          )
          .whenComplete(() {
            if (identical(_openingAudio, session)) _openingAudio = null;
          }),
    );
  }

  Object? get _playbackError {
    final session = _session;
    return session != null && !session._closed ? session._error : _tts?.error;
  }

  /// Officially a playback error is a toast; the capsule falls back to its
  /// play icon (`pn2/i.java` `b.i`). The listening page shows errors inline.
  void _toastNewError({String? readerBookId}) {
    final error = _playbackError;
    if (error == null) {
      _toastedError = null;
      return;
    }
    final readerMatches =
        readerBookId != null && _switchBookMatches(readerBookId);
    if (error == _toastedError ||
        (!readerMatches && !(_routes?.visible ?? false))) {
      return;
    }
    _toastedError = error;
    _toast(error.toString());
  }

  void _toast(String message) {
    final context = widget.navigatorKey.currentContext;
    if (context == null) return;
    ScaffoldMessenger.maybeOf(
      context,
    )?.showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _showReaderVoices(BuildContext context, String bookId) async {
    VoicePickerOutcome outcome;
    try {
      outcome = await ReaderAudioBridge.openVoiceSettings(context, bookId);
    } catch (_) {
      outcome = VoicePickerOutcome.failed;
    }
    if (!mounted || !context.mounted) return;
    switch (outcome) {
      case VoicePickerOutcome.changed:
        _toast('已切换声音');
      case VoicePickerOutcome.unavailable:
        _toast('暂时无法获取音色列表');
      case VoicePickerOutcome.failed:
        _toast('切换失败，请稍后重试');
      case VoicePickerOutcome.dismissed:
        break;
    }
  }

  /// 胶囊三点的分派：播放中换音色，没在播就选引擎。
  ///
  /// 「没在播」按用户口径含暂停——暂停时多半是要换一套来源重听，挑音色
  /// 反而是次要动作。
  Future<void> _showCapsuleMore(
    BuildContext context,
    _AudioPlaybackController session,
  ) async {
    final playing = (session._player?.playing ?? false) && session._wantPlay;
    if (playing) {
      await _showReaderVoices(context, session._bookId);
      return;
    }
    await _showListenEngineSheet(context);
  }

  /// 系统朗读的三点：和作品音频同一条规矩——暂停/没在播先选引擎。
  ///
  /// 系统朗读没有音色可选，以前三点无条件跳朗读设置页，把「换引擎」藏进
  /// 了设置里：暂停时用户多半是想换一套来源重听，结果点开只看到语速。
  /// 朗读中才给设置页（语速、引擎参数），暂停时给「选择播放引擎」。
  Future<void> _showTtsMore(BuildContext context, SystemTtsPlayback tts) async {
    if (tts.wantPlay && !tts.closed) {
      _openTtsSettings(context);
      return;
    }
    await _showListenEngineSheet(context);
  }

  /// 「选择播放引擎」：智能朗读（作品音频）或系统朗读（手机本地 TTS）。
  ///
  /// 选完写进 [AudioPreferences]，之后所有听书入口起播都按它走——阅读页
  /// 的听书按钮、胶囊的播放键都算。
  Future<void> _showListenEngineSheet(BuildContext context) async {
    final current = AudioPreferences.instance.listenEngine.value;
    final picked = await showHomeSheet<ListenEngine>(
      context: context,
      title: '选择播放引擎',
      children: [
        for (final engine in ListenEngine.values)
          Builder(
            builder: (tileContext) {
              final palette = HomePalette.of(tileContext);
              final smart = engine == ListenEngine.smart;
              return ListTile(
                key: ValueKey('listen-engine-${engine.name}'),
                leading: Icon(
                  smart ? LucideIcons.headphones : LucideIcons.mic,
                  color: palette.muted,
                ),
                title: Text(
                  smart ? '智能朗读' : '系统朗读',
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 15,
                    color: palette.ink,
                  ),
                ),
                subtitle: Text(
                  smart ? '作品自带朗读音频，音色可换，需要联网' : '手机已装的 TTS 引擎，离线可用，音色由系统决定',
                  style: TextStyle(fontSize: 12.5, color: palette.muted),
                ),
                trailing: engine == current
                    ? Icon(LucideIcons.check, color: palette.accentText)
                    : null,
                onTap: () => Navigator.pop(tileContext, engine),
              );
            },
          ),
      ],
    );
    if (picked == null || !mounted) return;
    await AudioPreferences.instance.setListenEngine(picked);
    if (!mounted || !context.mounted) return;
    // 暂停态换引擎要立刻接上：以前只记偏好，当前会话还挂着旧引擎，用户
    // 得关掉胶囊再重进才生效。接不上（音频切系统朗读时不在书页）就只记
    // 偏好，提示下一步怎么走。
    final resumed = await ReaderAudioBridge.resumeWithEngine(context, picked);
    if (!mounted) return;
    _toast(
      resumed
          ? (picked == ListenEngine.smart ? '播放引擎：智能朗读' : '播放引擎：系统朗读')
          : (picked == ListenEngine.smart
                ? '已切换到智能朗读，点「听书」继续'
                : '已切换到系统朗读，回书页点「听书」继续'),
    );
  }

  void _openTtsSettings(BuildContext context) {
    Navigator.of(context).push<void>(
      MaterialPageRoute(builder: (_) => const SystemTtsSettingsPage()),
    );
  }

  /// The overlay and reader menu borrow the same session and control path.
  Widget _buildCapsule(
    BuildContext context, {
    bool inReaderMenu = false,
    bool monochrome = false,
    VoidCallback? onOpenBook,
  }) {
    final routes = _routes;
    if (routes == null) return const SizedBox.shrink();
    return ListenableBuilder(
      listenable: Listenable.merge([routes, _tick]),
      builder: (context, _) {
        final session = _session;
        final tts = _tts;
        final recent = _recent;
        // The reader's menu/route owns visibility; popup sheets cover it.
        final visible = inReaderMenu || routes.visible;
        Widget? player;
        if (session != null && !session._closed) {
          final error = session._error != null;
          player = AudioFloatingPlayer(
            key: ObjectKey(session),
            inReaderMenu: inReaderMenu,
            monochrome: monochrome,
            keyPrefix: inReaderMenu ? 'reader-menu' : 'audio-floating',
            title: session._title,
            cover: session._cover,
            progress: session._position,
            readProgress: () {
              final duration = session._duration.inMilliseconds;
              return duration <= 0
                  ? 0
                  : session._position.value.inMilliseconds / duration;
            },
            playing:
                (session._player?.playing ?? false) &&
                session._wantPlay &&
                !session._completed,
            loading: session._loading || (session._player?.buffering ?? false),
            // Buffering still pauses; an error retries like the page's button.
            canToggle: error || session._ready,
            visible: visible,
            bottomInset: routes.bottomInset,
            onOpen: () => _openAudio(session),
            onToggle: () => unawaited(
              error
                  ? session._openChapter(session._index, restoreHistory: true)
                  : session._togglePlayback(),
            ),
            onMore: inReaderMenu
                ? () => unawaited(_showCapsuleMore(context, session))
                : null,
            canMore: !session._switchingVersion && !_readerVoicePickerOpen,
            onClose: () => unawaited(stop(session)),
          );
        } else if (tts != null && !tts.closed) {
          player = AudioFloatingPlayer(
            key: ObjectKey(tts),
            inReaderMenu: inReaderMenu,
            monochrome: monochrome,
            keyPrefix: inReaderMenu ? 'reader-menu' : 'audio-floating',
            title: tts.book.title,
            cover: tts.book.coverUrl,
            progress: tts,
            readProgress: () => tts.progress,
            playing: tts.wantPlay,
            loading: tts.loading,
            canToggle: true,
            visible: visible,
            bottomInset: routes.bottomInset,
            onOpen: () => _openTts(tts, onOpenBook: onOpenBook),
            onToggle: () => unawaited(tts.toggle()),
            // 播放中给朗读设置（语速等），暂停时给「选择播放引擎」。
            onMore: inReaderMenu
                ? () => unawaited(_showTtsMore(context, tts))
                : null,
            onClose: () => unawaited(stopTts(tts)),
          );
        } else if (recent != null) {
          player = AudioFloatingPlayer(
            key: ObjectKey(recent),
            inReaderMenu: inReaderMenu,
            monochrome: monochrome,
            keyPrefix: inReaderMenu ? 'reader-menu' : 'audio-floating',
            title: recent.title,
            cover: recent.cover,
            progress: _tick,
            readProgress: () => recent.progress,
            playing: false,
            loading: _resuming,
            canToggle: !_resuming,
            // The reader can borrow the home shell's recoverable idle player.
            visible: visible && (inReaderMenu || routes.atRoot),
            bottomInset: routes.bottomInset,
            onOpen: () => unawaited(_resumeRecent(recent, open: true)),
            onToggle: () => unawaited(_resumeRecent(recent, open: false)),
            // 没有会话＝没在播：三点给「选择播放引擎」，不摆音色。
            onMore: inReaderMenu
                ? () => unawaited(_showListenEngineSheet(context))
                : null,
            onClose: () {
              if (identical(_recent, recent)) {
                _recent = null;
                _changed();
              }
            },
          );
        }
        if (player == null) return const SizedBox.shrink();
        if (!inReaderMenu) return player;
        return Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Align(
            alignment: Alignment.centerLeft,
            child: Semantics(
              container: true,
              explicitChildNodes: true,
              label: '听书控制',
              child: player,
            ),
          ),
        );
      },
    );
  }
}
