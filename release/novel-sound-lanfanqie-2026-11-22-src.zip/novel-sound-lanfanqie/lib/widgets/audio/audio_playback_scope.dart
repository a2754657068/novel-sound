part of '../../pages/audio_page.dart';

/// Owns one listening session for the lifetime of the app's Navigator.
class AudioPlaybackScope extends StatefulWidget {
  const AudioPlaybackScope({
    super.key,
    required this.navigatorKey,
    required this.child,
    this.recentListen,
  });

  final GlobalKey<NavigatorState> navigatorKey;
  final Widget child;

  /// Supplies the cold-start idle capsule. Null disables it.
  final RecentListenLoader? recentListen;

  static Future<void> startSystemTts(BuildContext context, SystemTtsBook book) {
    final owner = context.findAncestorStateOfType<_AudioPlaybackScopeState>();
    if (owner == null) throw StateError('当前阅读入口不支持持续朗读');
    return owner.startSystemTts(book);
  }

  /// Stops a system-TTS session for [bookId], if one exists. Used before an AI
  /// display update when playback is paused so resuming cannot read stale text.
  static Future<void> stopSystemTtsForBook(
    BuildContext context,
    String bookId,
  ) {
    final owner = context.findAncestorStateOfType<_AudioPlaybackScopeState>();
    return owner?.stopSystemTtsForBook(bookId) ?? Future<void>.value();
  }

  /// 在后台起播，不打开听书页；实现见 [ReaderAudioBridge]（同库 part）。
  @visibleForTesting
  static BackgroundStartHandler? startListeningOverride;

  static Future<bool> startListeningInBackground(
    BuildContext context,
    AudioPage request,
  ) => ReaderAudioBridge.startListeningInBackground(context, request);

  /// 段落锚点跳转（双击跳读用）：与「从本页播放」同一套寻址。
  static bool jumpToParagraph(
    BuildContext context,
    String chapterId, {
    required int? paraIndex,
    required int ordinal,
  }) => ReaderAudioBridge.jumpToParagraph(
    context,
    chapterId,
    paraIndex: paraIndex,
    ordinal: ordinal,
  );

  @visibleForTesting
  static ParagraphJumpHandler? jumpToParagraphOverride;

  /// 把正在进行的朗读跳到 [position]（阅读页双击跳读用）。
  ///
  /// 只有智能朗读 / 真人讲书这类走播放器的会话能被跳转；系统朗读（本地 TTS）
  /// 没有可 seek 的音频流，返回 false 让调用方提示。
  static bool seekActive(BuildContext context, Duration position) {
    final owner = context.findAncestorStateOfType<_AudioPlaybackScopeState>();
    return owner?.seekActive(position) ?? false;
  }

  /// 阅读页那枚「暂停播放 / 继续播放」胶囊：切换这本书的播放状态。
  ///
  /// 对应官方 `ReaderPlayerButton`（`ajo.xml` 的 `TextView j53`）。没有正在
  /// 控制这本书的会话时返回 false；音频与系统 TTS 都路由到各自的控制器。
  static bool togglePlayback(BuildContext context, String bookId) {
    final owner = context.findAncestorStateOfType<_AudioPlaybackScopeState>();
    return owner?.togglePlayback(bookId) ?? false;
  }

  /// 阅读页手动翻页：把这本书的播放暂停。
  ///
  /// 官方 `handlePlayWhenPageChange`（`AudioSyncReaderController.java:1242-1295`）
  /// 在同章翻页时 `pausePlayer()` 并亮出「原进度 / 从本页听」。和
  /// [togglePlayback] 不同，这里只在正在播时暂停；已经是暂停态时调用不会反着
  /// 播起来。
  static void pauseIfPlaying(BuildContext context, String bookId) {
    context.findAncestorStateOfType<_AudioPlaybackScopeState>()?.pauseIfPlaying(
      bookId,
    );
  }

  /// 把朗读切到 [chapterId]，并从 [position] 起播（双击跳读，可跨章）。
  ///
  /// 同章就是 seek；换章走 [_openChapter]，它会释放旧播放器、按给定位置起播，
  /// 顺带把进度记下来。找不到这一章（书的章节列表对不上）返回 false。
  static bool jumpToChapter(
    BuildContext context,
    String chapterId,
    Duration position,
  ) => ReaderAudioBridge.jumpToChapter(context, chapterId, position);

  /// 测试缝：拦截句级/段首毫秒跳转（双击跳读用例）。
  @visibleForTesting
  static ChapterJumpHandler? jumpToChapterOverride;

  /// 取指定章节的逐句字幕（阅读页跨章双击跳读用）。
  ///
  /// 正在播的那章直接给会话里已有的轨，不重复请求；其它章按需取一次并缓存。
  /// 取不到（这本书没有生成语音文本）时返回空轨，不算错误。
  static Future<SubtitleTrack> timelineForChapter(
    BuildContext context,
    String chapterId,
  ) {
    final owner = context.findAncestorStateOfType<_AudioPlaybackScopeState>();
    if (owner == null) return Future.value(SubtitleTrack.empty);
    return owner.timelineForChapter(chapterId);
  }

  @override
  State<AudioPlaybackScope> createState() => _AudioPlaybackScopeState();
}

class _AudioPlaybackScopeState extends State<AudioPlaybackScope> {
  _AudioPlaybackController? _session;
  SystemTtsPlayback? _tts;
  SystemTtsPlayback? _ttsPage;
  Future<void> _queue = Future<void>.value();
  final _views = <_AudioPageState>{};
  bool _rebuildPending = false;
  _AudioPlaybackController? _openingAudio;
  late final Future<void> Function(NativePlayer) _playGate = _beforePlay;

  /// Rebuilds the capsule, which lives in the Navigator's Overlay instead of
  /// under this widget.
  final _tick = ValueNotifier<int>(0);
  AudioFloatingRoutes? _routes;
  RecentListen? _recent;
  bool _resuming = false;
  bool _readerVoicePickerOpen = false;
  Object? _toastedError;

  /// 跨章跳读要用的字幕轨缓存，键 = `音色|章节 id`。
  ///
  /// 会话只持有正在播那章的轨，阅读页停在别的章时拿不到字幕；这里按章补取
  /// 一次并缓存。键里带音色，换音色后旧条目自然不再命中。
  final _timelineCache = <String, SubtitleTrack>{};
  final _timelinePending = <String, Future<SubtitleTrack>>{};

  @override
  void initState() {
    super.initState();
    NativePlayer.beforePlay = _playGate;
    unawaited(_loadRecent());
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final routes = AudioFloatingRouteScope.read(context);
    if (identical(routes, _routes)) return;
    _routes?.unmount();
    _routes = routes;
    routes?.mount(_buildCapsule);
  }

  Future<void> _loadRecent() async {
    final loader = widget.recentListen;
    if (loader == null) return;
    RecentListen? recent;
    try {
      recent = await loader();
    } catch (_) {
      // The idle capsule is a convenience; history read failures hide it.
      return;
    }
    if (!mounted || recent == null || _session != null || _tts != null) return;
    _recent = recent;
    _changed();
  }

  Future<void> _beforePlay(NativePlayer player) async {
    await _tts?.pause();
    final session = _session;
    if (session == null || session._closed) return;
    if (identical(player, session._player)) {
      await NativePlayer.pauseOthers(player);
    } else {
      await session._pauseForOtherMedia();
    }
  }

  /// 见 [AudioPlaybackScope.seekActive]。会话没就绪（还在缓冲、已关闭）时
  /// 返回 false，不排队 —— 跳读是用户的即时动作，晚半拍就没意义了。
  bool seekActive(Duration position) {
    final session = _session;
    if (session == null || session._closed || !session._ready) return false;
    unawaited(session._seekTo(position));
    return true;
  }

  /// 阅读页的书 id 是否属于这个会话：音频书自己的 id，或时间轴别名到的
  /// 原著（真人讲书的「边听边读」打开原著后仍要能控制播放）。
  bool _sessionBookMatches(String bookId) {
    final session = _session;
    if (session == null || session._closed) return false;
    return session._bookId == bookId || session._linkedNovelBookId == bookId;
  }

  /// 把阅读页的章节 id 解析成播放器使用的音频章节 id。
  ///
  /// 智能朗读两边相同，直接命中；真人讲书的阅读页传的是原著章节 id，只有
  /// 时间轴映射到的当前集才能换回音频章节。其它原著章节没有反查表，返回
  /// null —— 宁可不跳，也不串到别的音频章。
  String? _audioChapterIdFor(String readerChapterId) {
    final session = _session;
    if (session == null || session._closed || readerChapterId.isEmpty) {
      return null;
    }
    if (session._chapters.any((c) => c.itemId == readerChapterId)) {
      return readerChapterId;
    }
    if (session._timeTrack.novelItemId != readerChapterId) return null;
    if (session._index < 0 || session._index >= session._chapters.length) {
      return null;
    }
    return session._chapters[session._index].itemId;
  }

  /// 见 [AudioPlaybackScope.togglePlayback]。
  bool togglePlayback(String bookId) {
    final tts = _tts;
    if (tts != null && !tts.closed && tts.book.bookId == bookId) {
      unawaited(tts.toggle());
      return true;
    }
    final session = _session;
    if (session == null || session._closed) return false;
    // 只控制「正在听的那本」：阅读页可能翻到别的书，那与本会话无关。
    if (!_sessionBookMatches(bookId) || !session._ready) return false;
    unawaited(session._togglePlayback());
    return true;
  }

  /// 见 [AudioPlaybackScope.pauseIfPlaying]。
  void pauseIfPlaying(String bookId) {
    final tts = _tts;
    if (tts != null && !tts.closed && tts.book.bookId == bookId) {
      if (tts.wantPlay || tts.loading) unawaited(tts.pause());
      return;
    }
    final session = _session;
    if (session == null || session._closed) return;
    if (!_sessionBookMatches(bookId) || !session._ready) return;
    if (session._wantPlay) unawaited(session._pauseForOtherMedia());
  }

  /// 见 [AudioPlaybackScope.jumpToChapter]。换章要重新加载音频源，所以不像
  /// [seekActive] 那样要求 _ready —— 正在缓冲中跳读也是合法操作。
  /// 见 [AudioPlaybackScope.timelineForChapter]。
  Future<SubtitleTrack> timelineForChapter(String chapterId) {
    final session = _session;
    if (session == null || session._closed) {
      return Future.value(SubtitleTrack.empty);
    }
    final audioChapterId = _audioChapterIdFor(chapterId);
    if (audioChapterId == null) return Future.value(SubtitleTrack.empty);
    final index = session._chapters.indexWhere(
      (c) => c.itemId == audioChapterId,
    );
    if (index < 0) return Future.value(SubtitleTrack.empty);
    // 正在播的就是这一章：会话里的轨最新，直接给。
    if (index == session._index && session._subtitles.isNotEmpty) {
      return Future.value(session._subtitles);
    }
    final key = '${session._toneId}|$audioChapterId';
    final cached = _timelineCache[key];
    if (cached != null) return Future.value(cached);
    final pending = _timelinePending[key];
    if (pending != null) return pending;
    final future = _loadTimeline(
      key,
      session._loadSubtitles(audioChapterId, session._toneId),
    );
    _timelinePending[key] = future;
    return future;
  }

  Future<SubtitleTrack> _loadTimeline(
    String key,
    Future<SubtitleTrack> load,
  ) async {
    try {
      final track = await load;
      // 命中不了的章不再重复请求；超过 8 条就丢最旧的一条。
      if (_timelineCache.length >= 8) {
        _timelineCache.remove(_timelineCache.keys.first);
      }
      _timelineCache[key] = track;
      return track;
    } finally {
      _timelinePending.remove(key);
    }
  }

  bool jumpToChapter(String chapterId, Duration position) {
    final session = _session;
    if (session == null || session._closed) return false;
    final audioChapterId = _audioChapterIdFor(chapterId);
    if (audioChapterId == null) return false;
    final index = session._chapters.indexWhere(
      (c) => c.itemId == audioChapterId,
    );
    if (index < 0) return false;
    if (index == session._index) {
      if (!session._ready) return false;
      unawaited(session._seekTo(position));
    } else {
      unawaited(session._openChapter(index, position: position));
    }
    return true;
  }

  Future<_AudioPlaybackController?> acquire(AudioPage request) {
    final next = _queue.then((_) async {
      if (!mounted) return null;
      await _closeTts();
      if (!mounted) return null;
      final current = _session;
      if (current != null &&
          !current._closed &&
          _sessionBookMatches(request.bookId)) {
        // 别名书（真人讲书的原著）：阅读页传的是原著 id，会话记的是音频
        // 专辑 id。命中别名时只复用，不关闭重开。
        final aliased = current._bookId != request.bookId;
        if ((!request.resumeSession || request.startPosition != null) &&
            request.chapters.isNotEmpty) {
          final chapter =
              request.chapters[request.startIndex.clamp(
                0,
                request.chapters.length - 1,
              )];
          final audioChapterId = _audioChapterIdFor(chapter.itemId);
          if (audioChapterId != null) {
            final index = current._chapters.indexWhere(
              (c) => c.itemId == audioChapterId,
            );
            if (index >= 0) {
              unawaited(
                current._openChapter(
                  index,
                  position: request.startPosition,
                  paragraph: request.startParagraph,
                  fraction: request.startFraction,
                  toneId: request.initialToneId,
                  restoreHistory: true,
                  autoplay: request.autoplay,
                ),
              );
              return current;
            }
          }
          // 别名章节映射不到当前音频集：保持当前播放，拿原著 id 新建会话
          // 只会得到一个不存在的音频书。
          if (aliased) return current;
          // A refreshed directory can remove an old chapter. Start the exact
          // requested directory instead of silently retaining another chapter.
        } else {
          return current;
        }
      }
      await _closeCurrent();
      if (!mounted) return null;
      final session = _AudioPlaybackController(request);
      _session = session;
      _recent = null;
      session.onStop = () => unawaited(stop(session));
      session.addListener(_changed);
      session.start();
      _changed();
      return session;
    });
    _queue = next.then<void>((_) {}, onError: (Object _, StackTrace _) {});
    return next;
  }

  Future<void> stop(_AudioPlaybackController session) {
    final next = _queue.then((_) async {
      if (identical(_session, session)) await _closeCurrent();
    });
    _queue = next.catchError((Object _) {});
    return next;
  }

  Future<void> _closeCurrent() async {
    final session = _session;
    _session = null;
    session?.removeListener(_changed);
    _changed();
    if (session != null) _retireViews(session);
    await session?.close();
  }

  Future<void> startSystemTts(SystemTtsBook book) {
    final next = _queue.then((_) async {
      if (!mounted || book.chapters.isEmpty) return;
      await _closeCurrent();
      await _closeTts();
      if (!mounted) return;
      late final SystemTtsPlayback session;
      session = SystemTtsPlayback(
        book,
        beforePlay: () async {
          if (mounted && identical(_tts, session)) {
            await NativePlayer.pauseOthers();
          }
        },
        onStop: () => unawaited(stopTts(session)),
      );
      _tts = session;
      _recent = null;
      session.addListener(_changed);
      session.start();
      _changed();
    });
    _queue = next.catchError((Object _) {});
    return next;
  }

  Future<void> stopTts(SystemTtsPlayback session) {
    final next = _queue.then((_) async {
      if (identical(_tts, session)) await _closeTts();
    });
    _queue = next.catchError((Object _) {});
    return next;
  }

  Future<void> stopSystemTtsForBook(String bookId) {
    final next = _queue.then((_) async {
      final tts = _tts;
      if (tts != null && tts.book.bookId == bookId) await _closeTts();
    });
    _queue = next.catchError((Object _) {});
    return next;
  }

  Future<void> _closeTts() async {
    final session = _tts;
    _tts = null;
    session?.removeListener(_changed);
    _changed();
    await session?.close();
  }

  /// 暂停态换引擎后的接续：按刚写进偏好的引擎把这本书接起来。
  ///
  /// 只做 scope 本地能做的部分——系统朗读在播时切智能朗读（关掉 TTS、
  /// 按同一本书起作品音频，后台接续不推页面），同引擎就是恢复播放。作品
  /// 音频切系统朗读需要正文，只有阅读页构造得出 [SystemTtsBook]，那一半
  /// 由 [ReaderAudioBridge.resumeWithEngine] 先问阅读页注册的接续通道，
  /// 问不到才落到这里返回 false，调用方拿它决定提示语。
  Future<bool> resumeWithEngine(ListenEngine engine) async {
    final tts = _tts;
    if (tts != null && !tts.closed) {
      if (engine == ListenEngine.system) {
        await tts.resume();
        return true;
      }
      final book = tts.book;
      final request = AudioPage(
        bookId: book.bookId,
        title: book.title,
        cover: book.coverUrl,
        chapters: book.chapters,
        startIndex: tts.index,
      );
      try {
        final override = AudioPlaybackScope.startListeningOverride;
        if (override != null) {
          final accepted = await override(context, request);
          if (accepted) await _closeTts();
          return accepted;
        }
        if (book.localOnly) return false;
        // 当前 context 属于 scope 自身，不能经祖先查找取回自己；切换由队列接管。
        return await acquire(request) != null;
      } catch (_) {
        return false;
      }
    }
    final session = _session;
    if (session != null && !session._closed && session._ready) {
      if (engine == ListenEngine.system) return false;
      // 选择当前引擎只恢复播放，不能把缓冲中或已恢复的会话反向暂停。
      if (!session._wantPlay) await session._togglePlayback();
      return true;
    }
    return false;
  }

  /// 这次换引擎是否必须经过阅读页：音频 → 系统朗读要正文，scope 给不出；
  /// 系统朗读切智能朗读也优先走阅读页，起点（当前页）与跟随都留在书页。
  bool _switchNeedsReader(ListenEngine engine) {
    final tts = _tts;
    if (tts != null && !tts.closed) return engine == ListenEngine.smart;
    final session = _session;
    return session != null && !session._closed && engine == ListenEngine.system;
  }

  /// Use the same audio/novel identity mapping as the reader's other controls.
  bool _switchBookMatches(String bookId) {
    final tts = _tts;
    if (tts != null && !tts.closed) return tts.book.bookId == bookId;
    return _sessionBookMatches(bookId);
  }

  /// 点封面：回到正在朗读的那本书的书页。
  ///
  /// 系统朗读没有自己的播放页——朗读进度本来就挂在正文上（高亮、跟随都在
  /// [ReaderPage] 里），所以封面把人送回书页，定位到正在读的章节，而不是
  /// 另开一个控制页把书页盖住。
  ///
  /// 阅读页菜单里的那颗胶囊已经站在书页上了（[onOpenBook] 传进来），此时
  /// 收起菜单就是「回到书页」，不再往上叠一层。
  void _openTts(SystemTtsPlayback session, {VoidCallback? onOpenBook}) {
    if (session.closed || !identical(_tts, session)) return;
    if (onOpenBook != null) {
      onOpenBook();
      return;
    }
    if (identical(_ttsPage, session)) return;
    final navigator = widget.navigatorKey.currentState;
    if (navigator == null) return;
    final book = session.book;
    _ttsPage = session;
    unawaited(
      navigator
          .push<void>(
            MaterialPageRoute<void>(
              builder: (_) => ReaderPage(
                bookId: book.bookId,
                title: book.title,
                cover: book.coverUrl,
                chapters: book.chapters,
                startIndex: session.index,
                localOnly: book.localOnly,
                chapterLoader: book.textLoader,
              ),
            ),
          )
          .whenComplete(() {
            if (identical(_ttsPage, session)) _ttsPage = null;
          }),
    );
  }

  void registerView(_AudioPageState view) {
    _views.add(view);
  }

  void unregisterView(_AudioPageState view) {
    _views.remove(view);
  }

  void _changed() {
    if (!mounted || _rebuildPending) return;
    _rebuildPending = true;
    // Session acquisition can notify while descendant pages attach.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _rebuildPending = false;
      if (!mounted) return;
      _tick.value++;
      _toastNewError();
    });
    WidgetsBinding.instance.ensureVisualUpdate();
  }

  @override
  void dispose() {
    if (identical(NativePlayer.beforePlay, _playGate)) {
      NativePlayer.beforePlay = null;
    }
    final session = _session;
    _session = null;
    session?.removeListener(_changed);
    // Descendant audio/reader views finish detaching before close broadcasts.
    if (session != null) unawaited(Future<void>.microtask(session.close));
    final tts = _tts;
    _tts = null;
    tts?.removeListener(_changed);
    if (tts != null) unawaited(Future<void>.microtask(tts.close));
    _routes?.unmount();
    _routes = null;
    _tick.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => widget.child;
}
