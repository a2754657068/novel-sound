import 'dart:async';

import 'package:cupertino_ui/cupertino_ui.dart';
import 'package:material_ui/material_ui.dart';

import '../models/shuqi_book.dart';
import '../services/api_client.dart';
import '../services/app_style_tokens.dart';
import '../services/app_theme_style.dart';
import '../services/library_store.dart';
import '../services/player_history.dart';
import '../services/reader_history.dart';
import '../services/shuqi_reader_source.dart';
import '../services/user_facing_error.dart';
import '../widgets/app_ui/app_ui_scope.dart';
import '../widgets/app_ui/content_anchor.dart';
import '../widgets/detail/detail_archive.dart';
import '../widgets/detail/detail_states.dart';
import '../widgets/detail/detail_style.dart';
import '../widgets/home/home_design.dart';
import '../widgets/wenku/wenku_ui.dart';
import 'reader_page.dart';

part 'detail/shuqi_detail_classic.dart';

/// 书旗书籍详情 + 目录。
///
/// 档案主题沿用上游 `DetailPage`（revision ebcd7f1）：磨砂头栏、档案分区、
/// 行内目录和底部玻璃操作坞；经典主题走 `detail/shuqi_detail_classic.dart`
/// 的旧版式（Material AppBar、封面头部、简介与目录行），两者共用同一个
/// `_ShuqiDetailPageState` 和同一批 loader。书旗只读取上游内容，支持加入本机
/// 书架与阅读进度，不提供手动下载入口。阅读器以 `localOnly: true`
/// 打开，使用书旗正文加载器，并以 `shuqi:` 作用域复用磁盘章节缓存；
/// 本机历史使用相同作用域，阅读时长仍不计入统计。
///
/// 书旗 bookId 与番茄同为纯数字，所以在阅读器里加 `shuqi:` 前缀，避免两套 id
/// 在同一条进度/缓存键上相撞。
class ShuqiDetailPage extends StatefulWidget {
  final String bookId;

  /// 搜索结果带过来的标题/封面，只用于首屏占位，加载完成后以详情为准。
  final String initialTitle;
  final String initialCover;

  /// 注入点：留空走后端，与 SearchPage 的 loader 约定一致。
  final Future<Map<String, dynamic>> Function(String bookId)? bookLoader;
  final Future<Map<String, dynamic>> Function(String bookId)? tocLoader;
  final ReaderStore? readerStore;
  final ChapterTextLoader? chapterLoader;

  const ShuqiDetailPage({
    super.key,
    required this.bookId,
    this.initialTitle = '',
    this.initialCover = '',
    this.bookLoader,
    this.tocLoader,
    this.readerStore,
    this.chapterLoader,
  });

  @override
  State<ShuqiDetailPage> createState() => _ShuqiDetailPageState();
}

class _ShuqiDetailPageState extends State<ShuqiDetailPage> {
  ShuqiBook? _book;
  ShuqiToc? _toc;
  bool _loading = true;
  String? _error;

  /// 目录的加载/错误状态独立于详情：目录失败时详情照常展示。
  bool _tocLoading = true;
  String? _tocError;
  Map<String, dynamic>? _savedHistory;

  ReaderStore get _readerStore => widget.readerStore ?? LibraryStore.instance;

  int? get _resumeIndex =>
      resumeEpisodeIndex(_savedHistory, _toc?.toReaderChapters() ?? const []);

  String get _readLabel => _resumeIndex == null ? '开始阅读' : '继续阅读';

  /// Both layouts read the same chapter list, so one controller serves the
  /// classic and the archive body.
  final _scroll = ScrollController();

  /// 经典 ⇄ 档案换的是两棵不同的树：ScrollPosition 会重建，必须按内容 ID
  /// 恢复位置，而不是靠同一个 controller 的初始偏移。深章节在切换后通常还
  /// 没被懒列表构建，靠 [_anchorIndexOf] 先定位到它附近，再按 ID 精确对齐。
  late final _anchors = ContentAnchorKeeper(
    _scroll,
    indexOf: _anchorIndexOf,
    visibleTopInset: _anchorTopInset,
  );

  /// 档案 的滚动区延伸到浮动玻璃头栏下方，经典是 AppBar 之后的正文；
  /// 锚点的“可见顶部”必须按当前布局算，否则内容会落在页头后面。
  double _anchorTopInset(BuildContext context, AppThemeStyle style) =>
      style == AppThemeStyle.classic ? 0 : archiveChromeInset(context);

  /// 目录行的数据下标；分区锚点（header/directory）没有下标。
  int? _anchorIndexOf(String anchorId) {
    const prefix = 'directory/chapter:';
    if (!anchorId.startsWith(prefix)) return null;
    final id = anchorId.substring(prefix.length);
    final chapters = _toc?.chapters ?? const <ShuqiChapter>[];
    final index = chapters.indexWhere((chapter) => chapter.chapterId == id);
    return index < 0 ? null : index;
  }

  @override
  void initState() {
    super.initState();
    unawaited(_load());
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _anchors.attach(AppUiScope.maybeOf(context)?.notifier, context);
  }

  @override
  void dispose() {
    _anchors.detach();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
      _tocLoading = true;
      _tocError = null;
    });
    // 详情与目录互不依赖，并行发出：目录首次可能是一次整本 H5 页。
    await Future.wait([_loadBook(), _loadToc(), _loadHistory()]);
  }

  Future<void> _loadHistory() async {
    Map<String, dynamic>? saved;
    try {
      saved = await ReaderHistory(
        _readerStore,
      ).load(shuqiReaderId(widget.bookId));
      if (saved?['kind'] != null && saved?['kind'] != 'book') saved = null;
    } catch (_) {
      // An unavailable history store must not prevent online reading.
    }
    if (mounted) setState(() => _savedHistory = saved);
  }

  Future<void> _openReading() async {
    // Wait for the previous reader's saves, including an exit immediately
    // followed by reopening. Explicit catalogue choices bypass this index.
    await _loadHistory();
    if (mounted) await _openChapter(_resumeIndex ?? 0);
  }

  Future<void> _loadBook() async {
    try {
      final loader = widget.bookLoader ?? ApiClient.instance.shuqiBook;
      final payload = await loader(widget.bookId);
      if (!mounted) return;
      final detail = payload['data'];
      setState(() {
        _book = detail is Map
            ? ShuqiBook.fromJson(Map<String, dynamic>.from(detail))
            : null;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = userFacingError(error);
        _loading = false;
      });
    }
  }

  Future<void> _loadToc() async {
    setState(() {
      _tocLoading = true;
      _tocError = null;
    });
    try {
      final loader = widget.tocLoader ?? ApiClient.instance.shuqiToc;
      final payload = await loader(widget.bookId);
      if (!mounted) return;
      final toc = payload['data'];
      setState(() {
        _toc = ShuqiToc.fromJson(
          toc is Map ? Map<String, dynamic>.from(toc) : null,
        );
        _tocLoading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _tocError = userFacingError(error);
        _tocLoading = false;
      });
    }
  }

  Future<void> _openChapter(int index) async {
    final book = _book;
    final toc = _toc;
    if (book == null || toc == null || toc.chapters.isEmpty) return;
    final start = index < 0 ? 0 : (index >= toc.chapters.length ? 0 : index);
    await Navigator.push(
      context,
      MaterialPageRoute<void>(
        builder: (_) => ReaderPage(
          bookId: shuqiReaderId(widget.bookId),
          title: book.name,
          cover: book.coverUrl,
          shelfItem: book.toMediaItem(),
          chapters: toc.toReaderChapters(),
          startIndex: start,
          localOnly: true,
          // `localOnly` 关闭番茄在线功能，不禁止书旗独立作用域的自动缓存。
          readerStore: _readerStore,
          chapterLoader:
              widget.chapterLoader ??
              (chapter) => loadShuqiChapter(widget.bookId, chapter),
        ),
      ),
    );
    if (mounted) await _loadHistory();
  }

  String get _title => _book?.name.isNotEmpty == true
      ? _book!.name
      : (widget.initialTitle.isEmpty ? '书旗' : widget.initialTitle);

  @override
  Widget build(BuildContext context) {
    final palette = HomePalette.of(context);
    final style = AppUiScope.of(context);
    _anchors.noteLayoutStyle(style);
    if (style == AppThemeStyle.classic) {
      return _buildClassicPage(context, palette);
    }
    return WenkuPage(
      header: ArchiveHeaderBar(
        leading: GlassIconButton(
          icon: CupertinoIcons.back,
          label: '返回',
          onPressed: () => Navigator.maybePop(context),
        ),
        title: FittedBox(
          fit: BoxFit.scaleDown,
          child: const AppText(
            '书籍详情',
            style: TextStyle(
              fontSize: 18,
              height: 1.2,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ),
      child: Builder(builder: _body),
    );
  }

  Widget _body(BuildContext context) {
    final safe = MediaQuery.paddingOf(context);
    final edge = MediaQuery.sizeOf(context).width >= 700 ? 40.0 : 24.0;
    final horizontal = edge + safe.left;
    if (_loading) {
      return SingleChildScrollView(
        padding: EdgeInsets.fromLTRB(
          horizontal,
          safe.top + FrostedHeader.toolbarHeight + 24,
          edge + safe.right,
          140,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(
              height: 240,
              width: double.infinity,
              child: LoadingSkeleton(
                layout: SkeletonLayout.detail,
                label: '正在加载书旗书籍',
              ),
            ),
            const SizedBox(height: 18),
            const AppText('正在加载书籍与目录'),
          ],
        ),
      );
    }
    final error = _error;
    if (error != null) {
      return SingleChildScrollView(
        padding: EdgeInsets.fromLTRB(
          horizontal,
          safe.top + FrostedHeader.toolbarHeight + 40,
          edge + safe.right,
          140,
        ),
        child: DetailInlineError(message: error, onRetry: _load),
      );
    }
    final book = _book;
    if (book == null) {
      return Center(child: AppText('没有取到书籍数据'));
    }
    final toc = _toc;
    final chapters = toc?.chapters ?? const <ShuqiChapter>[];
    final geometry = glassActionDockGeometry(
      context,
      primary: chapters.isEmpty ? '暂无章节' : _readLabel,
      secondary: '',
    );
    // 目录条目可能上万章，只有真正进入视口的行才构建（上游目录同样是
    // SliverList.builder）；头部/简介/目录标题放在一个 adapter sliver 里。
    final showingChapters = _tocError == null && !_tocLoading;
    return Stack(
      children: [
        Positioned.fill(
          child: CustomScrollView(
            key: const Key('shuqi-detail-scroll'),
            controller: _scroll,
            physics: const BouncingScrollPhysics(
              parent: AlwaysScrollableScrollPhysics(),
            ),
            slivers: [
              SliverPadding(
                padding: EdgeInsets.fromLTRB(
                  horizontal,
                  safe.top + FrostedHeader.toolbarHeight + 24,
                  edge + safe.right,
                  0,
                ),
                sliver: SliverToBoxAdapter(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      KeyedSubtree(
                        key: contentAnchorKey('header'),
                        child: _identity(context, book),
                      ),
                      if (book.intro.isNotEmpty) ...[
                        const SizedBox(height: 28),
                        DetailArchiveSynopsis(text: book.intro),
                      ],
                      const SizedBox(height: 30),
                      KeyedSubtree(
                        key: contentAnchorKey('directory'),
                        child: _contentsHeading(context, toc, chapters),
                      ),
                      if (_tocError != null)
                        DetailInlineError(
                          message: _tocError!,
                          onRetry: () => unawaited(_loadToc()),
                        )
                      else if (_tocLoading)
                        const SizedBox(
                          height: 40,
                          child: LoadingSkeleton(
                            layout: SkeletonLayout.inline,
                            label: '正在加载目录',
                          ),
                        ),
                    ],
                  ),
                ),
              ),
              if (showingChapters)
                SliverPadding(
                  padding: EdgeInsets.fromLTRB(
                    horizontal,
                    0,
                    edge + safe.right,
                    0,
                  ),
                  sliver: SliverList.builder(
                    itemCount: chapters.length,
                    itemBuilder: (context, index) =>
                        _chapterRow(context, chapters[index], index),
                  ),
                ),
              SliverToBoxAdapter(child: SizedBox(height: geometry.extent + 20)),
            ],
          ),
        ),
        Positioned(
          bottom: 0,
          left: 0,
          right: 0,
          child: DetailArchiveDockUnderlay(height: geometry.extent),
        ),
        Align(
          alignment: Alignment.bottomCenter,
          child: Padding(
            padding: EdgeInsets.fromLTRB(
              DockLayout.actionSideInset + safe.left,
              0,
              DockLayout.actionSideInset + safe.right,
              DockLayout.bottomPaddingOf(context, viewPadding: true),
            ),
            child: ConstrainedBox(
              constraints: const BoxConstraints(
                maxWidth: DockLayout.actionMaxWidth,
              ),
              child: DetailArchiveDock(
                primaryLabel: chapters.isEmpty ? '暂无章节' : _readLabel,
                primaryIcon: CupertinoIcons.play_fill,
                onPrimary: chapters.isEmpty ? null : _openReading,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _identity(BuildContext context, ShuqiBook book) {
    final scheme = Theme.of(context).colorScheme;
    final cover = book.coverUrl.trim();
    final meta = [
      book.status,
      book.wordCount,
      book.kind,
      '书旗小说',
    ].where((part) => part.isNotEmpty).join(' · ');
    return LayoutBuilder(
      builder: (context, constraints) {
        final wide = constraints.maxWidth >= 650;
        final coverWidth = wide ? 150.0 : 118.0;
        final art = ClipRRect(
          borderRadius: BorderRadius.circular(
            AppStyleTokens.of(context).coverRadius,
          ),
          child: SizedBox(
            width: coverWidth,
            height: coverWidth * 1.4,
            child: cover.isEmpty
                ? ColoredBox(color: scheme.surfaceContainerHighest)
                : Image.network(
                    cover,
                    fit: BoxFit.cover,
                    errorBuilder: (_, _, _) =>
                        ColoredBox(color: scheme.surfaceContainerHighest),
                  ),
          ),
        );
        final info = Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AppText(
              book.name.isEmpty ? _title : book.name,
              key: const Key('shuqi-book-title'),
              style: TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: wide ? 28 : 24,
                height: 1.25,
                letterSpacing: -.5,
              ),
            ),
            const SizedBox(height: 8),
            if (book.author.isNotEmpty)
              AppText(
                book.author,
                style: const TextStyle(
                  fontSize: 15,
                  height: 1.4,
                  fontWeight: FontWeight.w600,
                ),
              ),
            if (meta.isNotEmpty) ...[
              const SizedBox(height: 9),
              AppText(
                meta,
                style: TextStyle(
                  color: scheme.onSurfaceVariant,
                  fontSize: 13,
                  height: 1.55,
                ),
              ),
            ],
            if (AppStyleTokens.of(context).showDecorativeCodes) ...[
              const SizedBox(height: 12),
              ArchiveCode(detailArchiveFileCode(book.bookId), inverse: true),
            ],
          ],
        );
        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            art,
            SizedBox(width: wide ? 28 : 20),
            Expanded(child: info),
          ],
        );
      },
    );
  }

  Widget _contentsHeading(
    BuildContext context,
    ShuqiToc? toc,
    List<ShuqiChapter> chapters,
  ) {
    return Row(
      children: [
        Expanded(
          child: ArchiveSection(
            title: '目录',
            code: '02 / CONTENTS',
            subtitle: toc == null ? '目录未加载' : '共 ${chapters.length} 章',
          ),
        ),
        if (toc != null && !toc.hasRealTitles)
          AppText(
            '（章名为占位）',
            style: TextStyle(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
              fontSize: 12,
            ),
          ),
      ],
    );
  }

  Widget _chapterRow(BuildContext context, ShuqiChapter chapter, int index) {
    final scheme = Theme.of(context).colorScheme;
    return KeyedSubtree(
      key: contentAnchorKey('directory/chapter:${chapter.chapterId}'),
      child: _archiveChapterRow(context, chapter, index, scheme),
    );
  }

  Widget _archiveChapterRow(
    BuildContext context,
    ShuqiChapter chapter,
    int index,
    ColorScheme scheme,
  ) {
    return JellyTapSurface(
      key: ValueKey('shuqi-chapter-$index'),
      onTap: () => unawaited(_openChapter(index)),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(
              color: Theme.of(context).dividerColor,
              width: .7,
            ),
          ),
        ),
        child: Row(
          children: [
            SizedBox(
              width: 36,
              child: AppText(
                (index + 1).toString().padLeft(2, '0'),
                style: TextStyle(fontSize: 12, color: scheme.onSurfaceVariant),
              ),
            ),
            Expanded(
              child: AppText(
                chapter.title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                  height: 1.5,
                ),
              ),
            ),
            if (chapter.isVip) ...[
              const SizedBox(width: 10),
              AppText(
                'VIP',
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  color: scheme.onSurfaceVariant,
                ),
              ),
            ],
            const SizedBox(width: 12),
            const ArchiveIcon(CupertinoIcons.chevron_right, size: 13),
          ],
        ),
      ),
    );
  }
}
