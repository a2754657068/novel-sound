import '../widgets/desktop_chapter_sidebar.dart';
import '../services/desktop_platform.dart';
import 'dart:async';

import 'package:cupertino_ui/cupertino_ui.dart';
import 'package:material_ui/material_ui.dart';
import 'package:flutter/services.dart';
import 'package:flutter_lucide/flutter_lucide.dart';

import '../models/book_comment.dart';
import '../models/book_detail.dart';
import '../models/media_item.dart';
import '../models/media_description.dart';
import '../models/series_detail.dart';
import '../models/shuqi_book.dart';
import '../services/api_client.dart';
import '../services/app_theme_style.dart';
import '../services/audio_history.dart';
import '../services/book_open_preferences.dart';
import '../services/catalogue_order_preferences.dart';
import '../services/chapter_cache_store.dart';
import '../services/chapter_download.dart';
import '../services/connectivity_status.dart';
import '../services/library_store.dart';
import '../services/media_history_store.dart';
import '../services/player_history.dart';
import '../services/platform_capabilities.dart';
import '../services/reader_history.dart';
import '../services/shelf_store.dart';
import '../services/user_facing_error.dart';
import '../services/video_catalogue.dart';
import '../widgets/app_ui/app_ui_scope.dart';
import '../widgets/app_ui/content_anchor.dart';
import '../widgets/detail/classic_detail_directory_section.dart';
import '../widgets/detail/classic_detail_read_bar.dart';
import '../widgets/detail/detail_archive.dart';
import '../widgets/detail/detail_description.dart';
import '../widgets/detail/detail_directory_sheet.dart';
import '../widgets/detail/detail_hero.dart';
import '../widgets/detail/detail_id_row.dart';
import '../widgets/detail/detail_reviews.dart';
import '../widgets/detail/detail_reviews_sheet.dart';
import '../widgets/detail/detail_sections.dart';
import '../widgets/detail/detail_states.dart';
import '../widgets/detail/detail_style.dart';
import '../widgets/home/home_design.dart';
import '../widgets/home/home_media_card.dart';
import '../widgets/home/home_shelf.dart';
import '../widgets/media_card.dart';
import '../widgets/wenku/wenku_ui.dart';
import 'audio_page.dart';
import 'author_page.dart';
import 'cached_book_reader.dart';
import 'comic_reader_page.dart';
import 'player_page.dart';
import 'reader_page.dart';
import 'shuqi_detail_page.dart';
import 'ai_reading/settings/ai_book_settings_page.dart';

part 'detail/detail_page_classic.dart';

/// How many chapter rows the classic 目录 preview lists (current ±1).
const _classicPreviewChapterCount = 3;

/// Optional decorations for the detail page (currently the review block).
/// Kept as one injected bundle so callers that already stub the detail and
/// directory loaders can stay fully offline.
///
/// Note: 详情页版式复刻、以及「注入过 loader 即视为离线」的规则 — 见
/// .agents/notes/implemented/feature/2026-09-10-detail-audio-replica.md
class DetailExtras {
  const DetailExtras({this.comments = const BookCommentPage()});

  final BookCommentPage comments;
}

typedef DetailExtrasLoader = Future<DetailExtras> Function(String bookId);

Future<DetailExtras> _defaultExtras(String bookId) async =>
    DetailExtras(comments: await ApiClient.instance.bookComments(bookId));

class _Captured<T> {
  final T? value;
  final Object? error;

  const _Captured.value(T this.value) : error = null;
  const _Captured.error(this.error) : value = null;
}

Future<_Captured<T>> _capture<T>(Future<T> future) async {
  try {
    return _Captured<T>.value(await future);
  } catch (error) {
    return _Captured<T>.error(error);
  }
}

class DetailPage extends StatefulWidget {
  final MediaItem item;
  final Future<Map<String, dynamic>> Function(String bookId, {String tab})?
  detailLoader;
  final Future<List<List<Chapter>>> Function(String bookId, {String tab})?
  directoryLoader;
  final DetailExtrasLoader? extrasLoader;

  /// Series detail (cast list) for short dramas and manju. Only consulted for
  /// video kinds; other content has no cast.
  final Future<SeriesDetail> Function(String seriesId)? seriesLoader;
  final ReaderStore? readerStore;

  /// Offline chapter cache behind the download action. Injectable so tests can
  /// download without a real Hive box.
  final ChapterCache? chapterCache;

  /// Chapter body loader behind the download; defaults to the live API and is
  /// injectable like the other loaders so tests stay offline.
  final Future<String> Function(Chapter chapter)? chapterLoader;

  /// 连通性探测。缺省走真实实现；注入后测试可完全离线。
  final Future<ConnectivityView> Function()? connectivity;

  const DetailPage({
    super.key,
    required this.item,
    this.detailLoader,
    this.directoryLoader,
    this.extrasLoader,
    this.seriesLoader,
    this.readerStore,
    this.chapterCache,
    this.chapterLoader,
    this.connectivity,
    this.autoOpenReader = false,
  });

  /// 「点击书籍直接进入阅读」（issue #19 第 3 条）：详情页加载出目录后，
  /// 直接按上次进度进阅读器，并用 pushReplacement 顶掉详情页。仅小说/漫画
  /// 走这条路；听书/短剧仍停留在详情页，加载失败时也停留在详情页。
  final bool autoOpenReader;

  @override
  State<DetailPage> createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  Map<String, dynamic>? _detail;
  BookDetail? _bookDetail;
  SeriesDetail _series = SeriesDetail.empty;
  BookCommentPage _comments = const BookCommentPage();
  bool _commentsLoadingMore = false;
  List<Chapter> _allChapters = [];
  final _scroll = ScrollController();
  bool _loading = true;
  String? _detailError;
  String? _directoryError;
  String? _reviewsError;
  late final String _tab;
  int _loadGeneration = 0;
  int _openGeneration = 0;
  int _historyGeneration = 0;
  int? _resumeIndex;

  /// When the saved place was recorded, for the resume row's muted `3 天前`.
  int? _resumeTime;
  bool _opening = false;
  bool _autoOpened = false;
  ChapterDownload? _download;

  /// 目录联网失败时查到的本地整本缓存；非空即给出「从缓存阅读」入口。
  CachedBook? _cachedBook;

  /// Inline catalogue state ported from upstream `DetailPage._directory`.
  /// fqapp shows the whole catalogue on the page (the searchable sheet stays
  /// one tap away) and persists the 正序/倒序 choice like upstream's
  /// `readerPreferences.catalogueReversed`.
  List<DetailVolumeGroup> _volumes = const [];
  final Set<String> _expandedVolumes = {};
  bool _catalogueReversed = false;
  bool _catalogueOrderSaving = false;
  Set<String> _cachedChapterIds = const {};

  /// 简介 expand/collapse, owned here so the classic `DetailDescription` and the
  /// archive `DetailArchiveSynopsis` share one value across a layout swap.
  /// Reset only when a different synopsis actually arrives.
  bool _synopsisExpanded = false;
  String _synopsisOwner = '';

  /// Keeps the visible content across 经典 ⇄ 档案: the two layouts are different
  /// widget trees, so the ScrollPosition is recreated and would otherwise
  /// restart at the top. The index resolver lets a row that the incoming
  /// layout has not built yet be located instead of collapsed to its section.
  late final _anchors = ContentAnchorKeeper(
    _scroll,
    indexOf: _anchorIndexOf,
    visibleTopInset: _anchorTopInset,
  );

  /// The archive phone shell scrolls under the floating glass header, so its
  /// content starts below [archiveChromeInset]; the classic shell has a real
  /// AppBar above the body. Desktop shares one widget tree for both styles and
  /// has no anchor keys.
  double _anchorTopInset(BuildContext context, AppThemeStyle style) =>
      style == AppThemeStyle.classic ? 0 : archiveChromeInset(context);

  /// Data index of an anchored catalogue row, or null for section anchors.
  int? _anchorIndexOf(String anchorId) {
    const chapterPrefix = 'directory/chapter:';
    if (anchorId.startsWith(chapterPrefix)) {
      final id = anchorId.substring(chapterPrefix.length);
      final index = _allChapters.indexWhere((chapter) => chapter.itemId == id);
      return index < 0 ? null : index;
    }
    const volumePrefix = 'directory/volume:';
    if (anchorId.startsWith(volumePrefix)) {
      final key = anchorId.substring(volumePrefix.length);
      final index = _volumes.indexWhere((volume) => volume.key == key);
      return index < 0 ? null : index;
    }
    return null;
  }

  bool get _supported => kindLabels.containsKey(widget.item.kind);
  bool get _isVideo => isVideoKind(widget.item.kind);
  bool get _isAudio => widget.item.kind == 'audio';
  bool get _isManga => widget.item.kind == 'manga';
  bool get _isBook => widget.item.kind == 'book';
  String get _contentId => widget.item.seriesId ?? widget.item.id;
  String get _chapterUnit => _isVideo
      ? '集'
      : _isManga
      ? '话'
      : '章';

  /// Archives header title per content kind; follows the kind labels (小说详情,
  /// 短剧详情, etc.).
  String get _pageTitle => '${kindLabels[widget.item.kind] ?? '小说'}详情';

  /// Source label on the identity block: the fqapp catalogue is 番茄's, and
  /// short dramas/manju/comics are not "小说".
  String get _sourceLabel => '番茄${kindLabels[widget.item.kind] ?? '小说'}';

  String get _readLabel => switch (widget.item.kind) {
    'video' || 'manju' => _resumeIndex == null ? '开始观看' : '继续观看',
    'audio' => _resumeIndex == null ? '开始收听' : '继续收听',
    _ => _resumeIndex == null ? '开始阅读' : '继续阅读',
  };

  /// The primary pill names what it will open, e.g. `继续阅读 · 第205章`;
  /// without progress it keeps the plain CTA.
  String get _readBarLabel {
    final index = _resumeIndex;
    if (index == null || _allChapters.isEmpty) return _readLabel;
    final chapter = _allChapters[index.clamp(0, _allChapters.length - 1)];
    if (_isVideo && !chapter.hasKnownIndex) return '$_readLabel · 当前视频';
    return '$_readLabel · ${_chapterNumber(chapter.title)}';
  }

  /// `第205章 风起` → `第205章`; the mockup CTA carries the number only.
  static String _chapterNumber(String title) {
    final match = RegExp(
      r'^第\s*[0-9０-９一二三四五六七八九十百千零两]+\s*[章节回集话]',
    ).firstMatch(title.trim());
    return match?.group(0)?.replaceAll(RegExp(r'\s+'), '') ?? title;
  }

  /// Opens the author's home; null when the payload carried no author id.
  VoidCallback? get _openAuthorAction {
    final author = _bookDetail?.author;
    if (author == null || author.id.isEmpty) return null;
    return () => _openAuthor(author.id, author.name);
  }

  /// 是否已在本地书架。以 [ShelfStore] 为准，写入后由它的 listenable 触发重绘；
  /// 短剧/漫剧官方用的是「追剧」，这里统一沿用「加入书架」，与听书页和书架页
  /// 的文案保持一致。
  bool get _inShelf => ShelfStore.instance.containsItem(widget.item);

  Future<void> _toggleShelf() async {
    if (!ShelfStore.instance.isReady) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('本地书架暂不可用，请重试')));
      return;
    }
    final detail = _bookDetail;
    // Persist the resolved metadata, without replacing the source or identity
    // carried by the entry (notably series/episode ids for video results).
    final item = detail == null
        ? widget.item
        : widget.item.copyWith(
            title: detail.title.isNotEmpty ? detail.title : null,
            author: detail.author.name.isNotEmpty ? detail.author.name : null,
            cover: detail.cover.isNotEmpty ? detail.cover : null,
            intro: detail.abstract.isNotEmpty ? detail.abstract : null,
            categories: detail.tags.isNotEmpty
                ? detail.tags
                : detail.category.isNotEmpty
                ? [detail.category]
                : null,
            creationStatus: detail.creationStatus >= 0
                ? detail.creationStatus
                : null,
            wordNumber: detail.wordNumber > 0 ? detail.wordNumber : null,
          );
    final added = await ShelfStore.instance.toggle(item);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(added ? '已加入书架' : '已移出书架'),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    _tab = _isVideo ? '短剧' : kindLabels[widget.item.kind] ?? '小说';
    // A whole-book download outlives this page: coming back re-attaches to the
    // same batch instead of starting a second one.
    final active = WholeBookDownload.active;
    if (active != null) {
      if (!active.value.running) {
        WholeBookDownload.release(active);
      } else if (active.book.id == _contentId) {
        _download = active;
        active.addListener(_onDownloadChanged);
      }
    }
    _load();
    unawaited(_loadCatalogueOrder());
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // The keeper measures the outgoing layout from the style store's listener:
    // build has not started at that point, so the old tree can still be walked.
    _anchors.attach(AppUiScope.maybeOf(context)?.notifier, context);
  }

  void _setSynopsisExpanded(bool value) {
    if (!mounted || _synopsisExpanded == value) return;
    setState(() => _synopsisExpanded = value);
  }

  /// One summary for every renderer: the payload abstract first, the
  /// description fallback otherwise.
  String get _synopsisText => _bookDetail?.abstract.isNotEmpty == true
      ? _bookDetail!.abstract
      : extractMediaDescription(_detail);

  /// Restores upstream's persisted 目录正序/倒序 choice.
  Future<void> _loadCatalogueOrder() async {
    final reversed = await CatalogueOrderPreferences.instance.load();
    if (!mounted || reversed == _catalogueReversed) return;
    setState(() => _catalogueReversed = reversed);
  }

  @override
  void dispose() {
    _anchors.detach();
    _scroll.dispose();
    final download = _download;
    if (download != null) {
      download.removeListener(_onDownloadChanged);
      // A running batch keeps going; a finished one can be collected.
      WholeBookDownload.release(download);
    }
    super.dispose();
  }

  Future<void> _load() async {
    final generation = ++_loadGeneration;
    ++_openGeneration;
    ++_historyGeneration;
    if (mounted) {
      setState(() {
        _loading = true;
        _detailError = null;
        _directoryError = null;
        _reviewsError = null;
        _detail = null;
        _bookDetail = null;
        _series = SeriesDetail.empty;
        _comments = const BookCommentPage();
        _commentsLoadingMore = false;
        _allChapters = const [];
        _opening = false;
        _resumeIndex = null;
        _resumeTime = null;
        _cachedBook = null;
        _volumes = const [];
        _expandedVolumes.clear();
        _cachedChapterIds = const {};
      });
    }

    if (!_supported) {
      if (!mounted || generation != _loadGeneration) return;
      setState(() => _loading = false);
      return;
    }

    // 离线时先摸清本地有没有整本缓存：详情页这条路离线必然失败，不该让用户
    // 对着骨架屏等到目录请求超时。联网时直接返回，在线路径一次缓存都不查。
    unawaited(_resolveCachedCatalogue(generation));

    final offlineVideo =
        _isVideo &&
        widget.detailLoader == null &&
        widget.directoryLoader == null &&
        await videoNetworkIsOffline(probe: widget.connectivity);
    if (!mounted || generation != _loadGeneration) return;

    // Detail and directory are independent. Short-drama IDs sometimes do
    // not have a legacy book-detail record, but their episode list is still
    // perfectly playable. Start both before awaiting either so the page waits
    // for the slower request, not the sum of both request times.
    final detailFuture = _capture(
      offlineVideo
          ? Future<Map<String, dynamic>>.error(
              const ApiException('当前离线，详情暂不可用'),
            )
          : (widget.detailLoader ?? ApiClient.instance.detail)(
              _contentId,
              tab: _tab,
            ),
    );
    final directoryFuture = _capture(
      _isVideo
          ? loadVideoCatalogue(
              seriesId: _contentId,
              tab: _tab,
              episodeId: widget.item.episodeId,
              title: widget.item.title,
              loader: widget.directoryLoader == null
                  ? null
                  : () => widget.directoryLoader!(_contentId, tab: _tab),
            ).then((episodes) => [episodes])
          : (widget.directoryLoader ?? ApiClient.instance.directoryChapters)(
              _contentId,
              tab: _tab,
            ),
    );
    // Reviews and cast are cosmetic: they load alongside and never gate the
    // page. Each keeps its own inline error so a failure is visible and
    // retryable in its own section.
    final extrasFuture = _capture(
      offlineVideo
          ? Future.value(const DetailExtras())
          : _loadExtras(_contentId),
    );
    final seriesFuture = _isVideo && !offlineVideo
        ? _capture((widget.seriesLoader ?? _defaultSeries)(_contentId))
        : null;
    final detailResult = await detailFuture;
    final directoryResult = await directoryFuture;
    if (!mounted || generation != _loadGeneration) return;

    final detail = detailResult.value;
    final volumes = directoryResult.value ?? <List<Chapter>>[];

    final directoryFailed =
        volumes.every((volume) => volume.isEmpty) &&
        directoryResult.error != null;
    CachedBook? cached;
    if (directoryFailed && _isBook) {
      // 联网取目录失败：先看本地有没有整本缓存。有就把「从缓存阅读」的入口
      // 摆出来，而不是只给一个离线时永远不会成功的重试按钮。
      cached = await _cachedCatalogue();
      if (!mounted || generation != _loadGeneration) return;
    }

    // The rich metadata rides on the same detail response the page already
    // fetches, so no extra request is needed for the masthead.
    final nextBook = detail == null ? null : BookDetail.fromPayload(detail);
    final nextSummary = nextBook?.abstract.isNotEmpty == true
        ? nextBook!.abstract
        : extractMediaDescription(detail);
    setState(() {
      _detail = detail;
      _bookDetail = nextBook;
      // A different synopsis is a different book/edition: the old expansion no
      // longer applies. Refreshing the same text keeps it open.
      if (nextSummary.isNotEmpty && nextSummary != _synopsisOwner) {
        _synopsisOwner = nextSummary;
        _synopsisExpanded = false;
      }
      _allChapters = directoryFailed
          ? const []
          : volumes.expand((volume) => volume).toList(growable: false);
      _volumes = detailArchiveVolumes(_allChapters);
      _expandResumeVolume();
      _cachedBook = cached;
      _detailError = detail == null && detailResult.error != null
          ? userFacingError(detailResult.error!)
          : null;
      _directoryError = directoryFailed
          ? userFacingError(directoryResult.error!)
          : null;
      _loading = false;
    });
    unawaited(_loadCachedChapterIds(generation));
    unawaited(_refreshResume());
    unawaited(_maybeAutoOpenReader());

    await _applyExtras(extrasFuture, generation);
    if (!mounted || generation != _loadGeneration) return;

    if (seriesFuture == null) return;
    final series = await seriesFuture;
    if (!mounted || generation != _loadGeneration) return;
    if (series.value case final SeriesDetail loaded) {
      setState(() => _series = loaded);
    }
  }

  /// Applies the review payload or records its own section error.
  Future<void> _applyExtras(
    Future<_Captured<DetailExtras>> future,
    int generation,
  ) async {
    final extras = await future;
    if (!mounted || generation != _loadGeneration) return;
    if (extras.value case final DetailExtras loaded) {
      setState(() {
        _comments = loaded.comments;
        _commentsLoadingMore = false;
        _reviewsError = null;
      });
    } else {
      setState(() {
        _reviewsError = userFacingError(extras.error ?? '书评加载失败');
      });
    }
  }

  /// Retries only the review section; the rest of the page keeps its data.
  Future<void> _retryReviews() async {
    final generation = _loadGeneration;
    setState(() => _reviewsError = null);
    await _applyExtras(_capture(_loadExtras(_contentId)), generation);
  }

  /// Resolves the optional review payload.
  ///
  /// A caller that already injects its own detail or directory loader is
  /// offline by construction (tests, previews), so the page must not reach for
  /// the network behind its back; such callers inject [DetailExtrasLoader] when
  /// they want the review block exercised.
  Future<DetailExtras> _loadExtras(String bookId) {
    final loader = widget.extrasLoader;
    if (loader != null) return loader(bookId);
    if (widget.detailLoader != null || widget.directoryLoader != null) {
      return Future.value(const DetailExtras());
    }
    return _defaultExtras(bookId);
  }

  /// Reply fetching is opt-in for the same reason as [_loadExtras]: a caller
  /// that injected its own loaders is offline, so the review list must not
  /// reach for the network when a row is tapped.
  ReviewReplyLoader? _replyLoader(String bookId) {
    if (widget.detailLoader != null || widget.directoryLoader != null) {
      return null;
    }
    if (bookId.isEmpty) return null;
    return (commentId) =>
        ApiClient.instance.commentReplies(bookId, commentId, groupId: bookId);
  }

  /// Offset-based review paging, under the same offline rule as
  /// [_replyLoader]: injected-loader callers drive their own data, and the
  /// 「全部书评」 affordance stays hidden for them.
  Future<BookCommentPage> Function(int offset)? _commentsLoader() {
    if (widget.detailLoader != null ||
        widget.directoryLoader != null ||
        widget.extrasLoader != null) {
      return null;
    }
    if (_contentId.isEmpty) return null;
    return (offset) =>
        ApiClient.instance.bookComments(_contentId, offset: offset);
  }

  /// Appends the next review page. A failure keeps the loaded list and just
  /// re-enables the affordance so it can be retried.
  Future<void> _loadMoreComments() async {
    final loader = _commentsLoader();
    if (loader == null || _commentsLoadingMore || !_comments.hasMore) return;
    final generation = _loadGeneration;
    final page = _comments;
    final offset = page.nextOffset;
    bool isCurrent() =>
        mounted &&
        generation == _loadGeneration &&
        identical(page, _comments) &&
        offset == _comments.nextOffset;
    setState(() => _commentsLoadingMore = true);
    try {
      final next = await loader(offset);
      if (!isCurrent()) return;
      setState(() {
        _comments = BookCommentPage(
          comments: [..._comments.comments, ...next.comments],
          totalCount: next.totalCount > 0
              ? next.totalCount
              : _comments.totalCount,
          scoreCount: _comments.scoreCount,
          scoreContext: _comments.scoreContext,
          hasMore: next.hasMore,
          nextOffset: next.nextOffset,
        );
        _commentsLoadingMore = false;
      });
    } on Exception {
      if (isCurrent()) setState(() => _commentsLoadingMore = false);
    }
  }

  /// Same offline rule as [_loadExtras]: an injected loader means the caller
  /// drives its own data.
  Future<SeriesDetail> _defaultSeries(String seriesId) {
    if (widget.detailLoader != null || widget.directoryLoader != null) {
      return Future.value(SeriesDetail.empty);
    }
    return ApiClient.instance.seriesDetail(seriesId);
  }

  @override
  Widget build(BuildContext context) {
    final palette = HomePalette.of(context);
    final style = AppUiScope.of(context);
    _anchors.noteLayoutStyle(style);
    final classic = style == AppThemeStyle.classic;
    final desktop = isWindowsDesktop && MediaQuery.sizeOf(context).width >= 700;
    final overlay =
        (palette.dark ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark)
            .copyWith(
              statusBarColor: Colors.transparent,
              systemNavigationBarColor: palette.canvas,
            );
    // Desktop keeps fqapp's two/three-column workspace for both styles; only
    // the phone layout has a 经典/档案 split (frosted header + archive sections +
    // dock vs the old AppBar + hero + 目录 preview + fixed read bar).
    if (desktop) {
      return AnnotatedRegion<SystemUiOverlayStyle>(
        value: overlay,
        child: Scaffold(
          backgroundColor: palette.canvas,
          body: _desktopBody(palette),
        ),
      );
    }
    if (classic) {
      return AnnotatedRegion<SystemUiOverlayStyle>(
        value: overlay,
        child: _buildClassicPage(context, palette),
      );
    }
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: overlay,
      child: WenkuPage(
        header: Builder(builder: _archiveHeader),
        child: Builder(builder: _phoneBody),
      ),
    );
  }

  /// Upstream `_header`: archive bar with the back action and the cache entry.
  /// fqapp also keeps the audio entry here (its detail page owns 听书).
  Widget _archiveHeader(BuildContext context) => LayoutBuilder(
    builder: (context, constraints) => ArchiveHeaderBar(
      leading: GlassIconButton(
        icon: CupertinoIcons.back,
        label: '返回',
        onPressed: () => Navigator.maybePop(context),
      ),
      title: FittedBox(
        fit: BoxFit.scaleDown,
        child: AppText(
          _pageTitle,
          key: const Key('detail_page_title'),
          style: const TextStyle(
            fontSize: 18,
            height: 1.2,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
      actions: [
        if (_isBook && _allChapters.isNotEmpty && constraints.maxWidth >= 360)
          GlassIconButton(
            key: const Key('detail_action_ai'),
            icon: CupertinoIcons.sparkles,
            label: '本书 AI 阅读优化',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => AiBookSettingsPage(
                  bookId: _contentId,
                  title: widget.item.title,
                  chapters: _allChapters,
                ),
              ),
            ),
          ),
        if (_isBook)
          GlassIconButton(
            key: const Key('detail_action_听书'),
            icon: CupertinoIcons.headphones,
            label: '听书',
            onPressed: _openListening,
          ),
        if (_isBook)
          GlassIconButton(
            key: const Key('detail_action_下载'),
            icon: _downloadProgress == null
                ? CupertinoIcons.cloud_download
                : CupertinoIcons.arrow_down_circle,
            label: '缓存图书',
            onPressed: _showDownloadSheet,
          ),
        if (_downloadProgress case final progress?)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: SizedBox.square(
              key: const Key('detail_download_progress'),
              dimension: 16,
              // Determinate: a running whole-book batch must not keep an endless
              // animation (and pumpAndSettle) alive.
              child: CircularProgressIndicator(
                strokeWidth: 2,
                value: progress.total == 0
                    ? 0
                    : progress.completed / progress.total,
                color: Theme.of(context).colorScheme.onSurface,
              ),
            ),
          ),
      ],
    ),
  );

  String get _shelfLabel => _inShelf ? '移出书架' : '加入书架';

  /// Phone body: upstream `DetailPage.build` — one scroll view with the
  /// identity block, sections and the inline catalogue, plus the bottom dock.
  Widget _phoneBody(BuildContext context) {
    final safe = MediaQuery.paddingOf(context);
    final edge = MediaQuery.sizeOf(context).width >= 700 ? 40.0 : 24.0;
    final geometry = glassActionDockGeometry(
      context,
      primary: _readBarLabel,
      secondary: _shelfLabel,
    );
    final entries = !_loading && _supported
        ? detailArchiveContents(
            chapters: _allChapters,
            volumes: _volumes,
            expandedVolumes: _expandedVolumes,
            reversed: _catalogueReversed,
          )
        : const <DetailContentsEntry>[];
    return Stack(
      children: [
        Positioned.fill(
          child: DefaultTextStyle.merge(
            style: const TextStyle(letterSpacing: 0),
            child: RefreshIndicator(
              onRefresh: _load,
              color: Theme.of(context).colorScheme.onSurface,
              backgroundColor: Theme.of(context).colorScheme.surface,
              child: CustomScrollView(
                key: const Key('detail_scroll'),
                controller: _scroll,
                physics: const BouncingScrollPhysics(
                  parent: AlwaysScrollableScrollPhysics(),
                ),
                slivers: [
                  SliverPadding(
                    padding: EdgeInsets.fromLTRB(
                      edge + safe.left,
                      safe.top + FrostedHeader.toolbarHeight + 24,
                      edge + safe.right,
                      0,
                    ),
                    sliver: SliverToBoxAdapter(child: _phoneIntro(context)),
                  ),
                  SliverPadding(
                    padding: EdgeInsets.fromLTRB(
                      edge + safe.left,
                      0,
                      edge + safe.right,
                      0,
                    ),
                    sliver: SliverList.builder(
                      itemCount: entries.length,
                      itemBuilder: (context, index) =>
                          _directoryEntry(entries[index]),
                    ),
                  ),
                  SliverToBoxAdapter(
                    child: SizedBox(height: geometry.extent + 20),
                  ),
                ],
              ),
            ),
          ),
        ),
        Positioned(
          bottom: 0,
          left: 0,
          right: 0,
          child: DetailArchiveDockUnderlay(height: geometry.extent),
        ),
        Align(
          alignment: Alignment.bottomCenter,
          child: Padding(
            padding: EdgeInsets.fromLTRB(
              DockLayout.actionSideInset + safe.left,
              0,
              DockLayout.actionSideInset + safe.right,
              DockLayout.bottomPaddingOf(context, viewPadding: true),
            ),
            child: ConstrainedBox(
              constraints: const BoxConstraints(
                maxWidth: DockLayout.actionMaxWidth,
              ),
              child: ValueListenableBuilder<int>(
                valueListenable: ShelfStore.instance.listenable,
                builder: (context, _, _) => DetailArchiveDock(
                  primaryLabel: _readBarLabel,
                  primaryIcon: CupertinoIcons.play_fill,
                  onPrimary: _supported && !_loading && _allChapters.isNotEmpty
                      ? _openLastPosition
                      : null,
                  primaryLoading: _opening,
                  secondaryLabel: _shelfLabel,
                  secondaryIcon: _inShelf
                      ? CupertinoIcons.bookmark_fill
                      : CupertinoIcons.bookmark,
                  onSecondary: _supported && !_loading ? _toggleShelf : null,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _phoneIntro(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final summary = _bookDetail?.abstract.isNotEmpty == true
        ? _bookDetail!.abstract
        : extractMediaDescription(_detail);
    final tags = _bookDetail?.tags ?? const <String>[];
    final hasReviews =
        _comments.comments.isNotEmpty || _comments.totalCount > 0;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        KeyedSubtree(
          key: contentAnchorKey('hero'),
          child: DetailArchiveIdentity(
            item: widget.item,
            detail: _bookDetail,
            onOpenAuthor: _openAuthorAction,
            lastChapterTitle: _latestChapterTitle,
            sourceLabel: _sourceLabel,
          ),
        ),
        if (!_supported) ...[
          const SizedBox(height: 28),
          _stateCard(
            icon: LucideIcons.file_question_mark,
            title: '暂不支持此内容类型',
            message: '可以返回继续发现其他故事。',
          ),
        ] else if (_loading) ...[
          const SizedBox(height: 28),
          const SizedBox(
            height: 310,
            width: double.infinity,
            child: LoadingSkeleton(
              layout: SkeletonLayout.detail,
              label: '正在加载书籍与目录',
            ),
          ),
          const SizedBox(height: 18),
          AppText(
            '正在加载书籍与目录',
            style: TextStyle(fontSize: 13, color: scheme.onSurfaceVariant),
          ),
        ] else ...[
          if (tags.isNotEmpty) ...[
            const SizedBox(height: 20),
            DetailArchiveTags(tags: tags),
          ],
          if (summary.trim().isNotEmpty) ...[
            const SizedBox(height: 28),
            KeyedSubtree(
              key: contentAnchorKey('synopsis'),
              child: DetailArchiveSynopsis(
                text: summary,
                expanded: _synopsisExpanded,
                onExpandedChanged: _setSynopsisExpanded,
              ),
            ),
          ],
          if (_detailError != null) ...[
            const SizedBox(height: 24),
            DetailInlineError(message: _detailError!, onRetry: _load),
          ],
          if (_series.cast.isNotEmpty) ...[
            const SizedBox(height: 18),
            DetailCastRow(cast: _series.cast),
          ],
          if (hasReviews || _reviewsError != null) ...[
            const SizedBox(height: 30),
            KeyedSubtree(
              key: contentAnchorKey('reviews'),
              child: _reviewsSection(
                HomePalette.of(context),
                hasReviews: hasReviews,
                showEmpty: false,
                flush: true,
              ),
            ),
          ],
          // Baseline order: 简介 → 目录预览 → 书评 → ID. The inline catalogue
          // replaces the preview, so the ID row stays above the catalogue
          // heading (and after the reviews) to remain reachable on long books.
          const SizedBox(height: 30),
          KeyedSubtree(
            key: contentAnchorKey('id'),
            child: DetailIdRow(id: _contentId),
          ),
          const SizedBox(height: 30),
          KeyedSubtree(
            key: contentAnchorKey('directory'),
            child: DetailArchiveContentsHeading(
              countLabel: _directoryCountLabel,
              reversed: _catalogueReversed,
              onToggleOrder: _allChapters.length < 2
                  ? null
                  : _toggleCatalogueOrder,
              onOpenSheet: _allChapters.isEmpty ? null : _openDirectory,
              progress: _archiveProgress,
            ),
          ),
          if (_directoryError != null)
            DetailInlineError(message: _directoryError!, onRetry: _load)
          else if (_allChapters.isEmpty)
            AppText('暂无章节', style: TextStyle(color: scheme.onSurfaceVariant)),
        ],
      ],
    );
  }

  /// `5 卷 · 146 章` — the one place the catalogue count appears.
  String get _directoryCountLabel {
    if (_isVideo && !hasCompleteEpisodeCatalogue(_allChapters)) {
      return _allChapters.isEmpty ? '暂无目录' : '完整目录暂不可用';
    }
    final volumes = _volumes.where((volume) => volume.title.isNotEmpty).length;
    return '${volumes > 0 ? '$volumes 卷 · ' : ''}${_allChapters.length} $_chapterUnit';
  }

  /// fqapp keeps its readout (`23 / 146` + `已读 16% · 3 天前`) beside the
  /// ported heading; upstream's separate resume box would duplicate it.
  Widget? get _archiveProgress {
    final index = _resumeIndex;
    if (index == null ||
        _allChapters.isEmpty ||
        (_isVideo && !hasCompleteEpisodeCatalogue(_allChapters))) {
      return null;
    }
    final number = (index + 1).clamp(1, _allChapters.length);
    final percent = (number / _allChapters.length * 100).round();
    final time = _resumeTimeLabel();
    return DetailArchiveProgress(
      number: number,
      total: _allChapters.length,
      percent: percent,
      label: time == null || time.isEmpty
          ? '已读 $percent%'
          : '已读 $percent% · $time',
    );
  }

  Widget _directoryEntry(DetailContentsEntry entry) {
    final volume = entry.volume;
    if (volume != null) {
      final expanded = _expandedVolumes.contains(volume.key);
      return KeyedSubtree(
        key: contentAnchorKey('directory/volume:${volume.key}'),
        child: DetailArchiveVolumeRow(
          volume: volume,
          expanded: expanded,
          chapterCount: volume.length,
          cacheLabel: _cacheLabel(volume.indexes),
          onTap: () => setState(() {
            if (!_expandedVolumes.add(volume.key)) {
              _expandedVolumes.remove(volume.key);
            }
          }),
        ),
      );
    }
    final index = entry.chapterIndex!;
    final chapter = _allChapters[index];
    return KeyedSubtree(
      key: contentAnchorKey('directory/chapter:${chapter.itemId}'),
      child: DetailArchiveChapterRow(
        key: ValueKey('detail-directory-entry-$index'),
        index: chapter.hasKnownIndex ? index : null,
        title: chapter.title,
        current: _resumeIndex == index,
        cached: _cachedChapterIds.contains(chapter.itemId),
        onTap: () => _openChapter(chapter),
      ),
    );
  }

  /// 桌面两栏布局的左栏卡片（PR #104 评审原型）：封面、书名、元信息、书架/刷新
  /// 和主操作全部收进一张白卡，主按钮不再横跨整个窗口底部。
  Widget _desktopSideCard(HomePalette palette, {bool compact = false}) {
    return Material(
      color: palette.surface,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: palette.line),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                ValueListenableBuilder<int>(
                  valueListenable: ShelfStore.instance.listenable,
                  builder: (context, _, _) => DetailShelfPill(
                    inShelf: _inShelf,
                    enabled: !_loading && _supported,
                    onTap: _toggleShelf,
                    keyName: 'detail_shelf_button_desktop',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            DetailHero(
              item: widget.item,
              detail: _bookDetail,
              onOpenAuthor: _openAuthorAction,
              lastChapterTitle: _latestChapterTitle,
              desktop: true,
              compactDesktop: compact,
            ),
            const SizedBox(height: 20),
            FilledButton.icon(
              key: const Key('detail_read_button_desktop'),
              onPressed: _opening || _loading || _allChapters.isEmpty
                  ? null
                  : () => unawaited(_openLastPosition()),
              style: detailPrimaryButtonStyle(
                palette,
                minimumSize: const Size.fromHeight(44),
              ),
              icon: Icon(homeKindIcon(widget.item.kind), size: 18),
              label: Text(
                _opening ? '正在打开…' : _readBarLabel,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            if (_isBook) ...[
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      key: const Key('detail_listen_button_desktop'),
                      onPressed: _loading || _allChapters.isEmpty
                          ? null
                          : _openListening,
                      style: detailOutlineButtonStyle(
                        palette,
                        minimumSize: const Size.fromHeight(44),
                      ),
                      icon: const Icon(LucideIcons.headphones, size: 16),
                      label: const Text('听书'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton.icon(
                      key: const Key('detail_download_button_desktop'),
                      onPressed: _loading || _allChapters.isEmpty
                          ? null
                          : _toggleDownload,
                      style: detailOutlineButtonStyle(
                        palette,
                        minimumSize: const Size.fromHeight(44),
                      ),
                      icon: const Icon(LucideIcons.download, size: 16),
                      label: Text(_downloadProgress == null ? '下载' : '下载中'),
                    ),
                  ),
                ],
              ),
            ],
            const SizedBox(height: 12),
            DetailIdRow(id: _contentId, compact: true),
          ],
        ),
      ),
    );
  }

  /// Masthead metadata, author, stats, summary, tags, catalog and reviews —
  /// the section order of the official detail page.
  /// 右栏分节（PR #104 评审原型）：桌面宽屏下把「简介 / 目录 / 评论」拆成可切换
  /// 的三节，避免两百多章的目录把详情页拉成一条长滚动；移动端仍按官方顺序整列
  /// 铺开，行为不变。
  int _desktopSection = 0;

  Widget _desktopPanel(HomePalette palette, Widget child) => Material(
    color: palette.surface,
    clipBehavior: Clip.antiAlias,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(12),
      side: BorderSide(color: palette.line),
    ),
    child: Padding(padding: const EdgeInsets.all(16), child: child),
  );

  Widget _desktopBody(HomePalette palette) {
    final width = MediaQuery.sizeOf(context).width;
    final threeColumns = width >= 1400;
    final sideWidth = width >= 1200 ? 340.0 : 320.0;
    Widget content() => !_supported
        ? _stateCard(
            icon: LucideIcons.file_question_mark,
            title: '暂不支持此内容类型',
            message: '可以返回继续发现其他故事。',
          )
        : _loading
        ? _loadingView(palette)
        : _content(palette);
    Widget mainScroll() => RefreshIndicator(
      onRefresh: _load,
      color: palette.eink ? palette.ink : HomePalette.accent,
      backgroundColor: palette.surface,
      child: SingleChildScrollView(
        controller: _scroll,
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.only(bottom: 32),
        child: content(),
      ),
    );
    if (width < 1000) {
      return RefreshIndicator(
        onRefresh: _load,
        color: palette.eink ? palette.ink : HomePalette.accent,
        backgroundColor: palette.surface,
        child: SingleChildScrollView(
          key: const Key('desktop-detail-compact'),
          controller: _scroll,
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _desktopSideCard(palette, compact: true),
              const SizedBox(height: 24),
              content(),
            ],
          ),
        ),
      );
    }
    return Align(
      alignment: Alignment.topCenter,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 1520),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 24, 16, 0),
          child: Row(
            key: Key(
              threeColumns ? 'desktop-detail-three' : 'desktop-detail-two',
            ),
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                width: sideWidth,
                child: SingleChildScrollView(
                  padding: const EdgeInsets.only(bottom: 32),
                  child: _desktopSideCard(palette),
                ),
              ),
              const SizedBox(width: 24),
              Expanded(
                child: Align(
                  alignment: Alignment.topCenter,
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 760),
                    child: mainScroll(),
                  ),
                ),
              ),
              if (threeColumns) ...[
                const SizedBox(width: 24),
                SizedBox(
                  width: 260,
                  child: SingleChildScrollView(
                    key: const Key('desktop-detail-information'),
                    padding: const EdgeInsets.only(bottom: 32),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: _desktopInfoRail(palette),
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _content(HomePalette palette) {
    final hasReviews =
        _comments.comments.isNotEmpty || _comments.totalCount > 0;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _desktopSectionTabs(palette),
        const SizedBox(height: 20),
        _desktopPanel(
          palette,
          Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: switch (_desktopSection) {
              1 => _desktopDirectoryTab(palette),
              2 => <Widget>[
                _reviewsSection(
                  palette,
                  hasReviews: hasReviews,
                  showEmpty: true,
                ),
              ],
              _ => <Widget>[_introSection(palette, desktop: true)],
            },
          ),
        ),
      ],
    );
  }

  /// `3 天前` — when the saved place was written, muted in 目录 progress.
  String? _resumeTimeLabel() {
    final time = _resumeTime;
    if (time == null) return null;
    final date = DateTime.fromMillisecondsSinceEpoch(time);
    final diff = DateTime.now().difference(date);
    if (diff.isNegative || diff.inMinutes < 1) return '刚刚';
    if (diff.inHours < 1) return '${diff.inMinutes} 分钟前';
    if (diff.inDays < 1) return '${diff.inHours} 小时前';
    if (diff.inDays < 7) return '${diff.inDays} 天前';
    return '${date.month}月${date.day}日';
  }

  Widget _introSection(HomePalette palette, {bool desktop = false}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (_detailError != null) ...[
          const DetailSectionHeader(title: '简介'),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: homeGutter),
            child: DetailInlineError(message: _detailError!, onRetry: _load),
          ),
        ] else ...[
          DetailDescription(
            text: _synopsisText,
            desktop: desktop,
            expanded: _synopsisExpanded,
            onExpandedChanged: _setSynopsisExpanded,
          ),
        ],
        if (_series.cast.isNotEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(homeGutter, 18, homeGutter, 0),
            child: DetailCastRow(cast: _series.cast),
          ),
      ],
    );
  }

  /// `完结 共820章 · 全部 ›` — the one place the chapter count appears.
  String get _directoryTrailing {
    final status = _bookDetail?.statusLabel ?? '';
    final count = '共${_allChapters.length}$_chapterUnit';
    return '${status.isEmpty ? '' : '$status '}$count · 全部';
  }

  /// The newest chapter for the hero's `更新至 …` line: the payload's own
  /// title first, then the last catalogue entry.
  String? get _latestChapterTitle {
    final payload = _bookDetail?.lastChapterTitle.trim() ?? '';
    if (payload.isNotEmpty) return payload;
    if (_allChapters.isEmpty) return null;
    final title = _allChapters.last.title.trim();
    return title.isEmpty ? null : title;
  }

  Widget _reviewsSection(
    HomePalette palette, {
    required bool hasReviews,
    required bool showEmpty,
    bool flush = false,
  }) {
    if (_reviewsError != null) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (!flush)
            const DetailSectionHeader(title: '书评')
          else
            ArchiveSection(title: '书评', code: '03 / REVIEWS', subtitle: ''),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: flush ? 0 : homeGutter),
            child: DetailInlineError(
              message: _reviewsError!,
              onRetry: _retryReviews,
            ),
          ),
        ],
      );
    }
    if (!hasReviews) {
      return showEmpty ? _emptyReviews(palette) : const SizedBox.shrink();
    }
    return DetailReviews(
      page: _comments,
      detail: _bookDetail,
      bookId: _contentId,
      onLoadMore: _comments.hasMore ? _loadMoreComments : null,
      onOpenAll: _openAllReviews,
      loadingMore: _commentsLoadingMore,
      flush: flush,
    );
  }

  List<Widget> _desktopDirectoryTab(HomePalette palette) => [
    Text(
      _directoryTrailing,
      style: TextStyle(color: palette.muted, fontSize: 13),
    ),
    const SizedBox(height: 16),
    SizedBox(
      height: (MediaQuery.sizeOf(context).height - 280).clamp(260.0, 640.0),
      child: DesktopChapterSidebar(
        width: double.infinity,
        chapterUnit: _chapterUnit,
        chapters: _allChapters,
        currentIndex: _resumeIndex ?? -1,
        onSelected: (index) => unawaited(_openChapter(_allChapters[index])),
      ),
    ),
  ];

  /// Three-column desktop rail: the tags the main column omits.
  List<Widget> _desktopInfoRail(HomePalette palette) {
    final detail = _bookDetail;
    if (detail == null || detail.tags.isEmpty) return const [];
    return [DetailTagChips(tags: detail.tags, desktop: true)];
  }

  Widget _desktopSectionTabs(HomePalette palette) {
    const labels = ['简介', '目录', '评论'];
    return Row(
      children: [
        for (var i = 0; i < labels.length; i++)
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: Material(
              // `InkWell` paints its splash into the nearest Material
              // *ancestor*, so the fill has to be the wrapper, not the child:
              // a Material under the well leaves the ripple on whatever
              // surface encloses the whole row, hidden behind this opaque
              // pill. The shape and colours are unchanged.
              color: _desktopSection == i ? palette.ink : palette.surface,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18),
                side: BorderSide(
                  color: _desktopSection == i ? palette.ink : palette.line,
                ),
              ),
              clipBehavior: Clip.antiAlias,
              child: InkWell(
                key: Key('detail_section_$i'),
                borderRadius: BorderRadius.circular(18),
                onTap: () {
                  setState(() => _desktopSection = i);
                  if (_scroll.hasClients &&
                      MediaQuery.sizeOf(context).width >= 1000) {
                    _scroll.jumpTo(0);
                  }
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 8,
                  ),
                  child: Text(
                    labels[i],
                    style: TextStyle(
                      color: _desktopSection == i
                          ? palette.canvas
                          : palette.ink,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _emptyReviews(HomePalette palette) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 24),
    child: Text(
      '还没有读者评论',
      style: TextStyle(color: palette.muted, fontSize: 13),
    ),
  );

  Widget _loadingView(HomePalette palette) => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      const DetailSkeleton(),
      Padding(
        padding: const EdgeInsets.fromLTRB(homeGutter, 18, homeGutter, 24),
        child: Text(
          '正在加载书籍与目录',
          style: TextStyle(color: palette.muted, fontSize: 13),
        ),
      ),
    ],
  );

  Widget _stateCard({
    required IconData icon,
    required String title,
    required String message,
  }) {
    final palette = HomePalette.of(context);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: palette.surface,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: palette.line),
      ),
      child: Column(
        children: [
          Icon(icon, color: palette.muted, size: 30),
          const SizedBox(height: 14),
          Text(
            title,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: palette.ink,
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            message,
            textAlign: TextAlign.center,
            style: TextStyle(color: palette.muted, fontSize: 13, height: 1.6),
          ),
        ],
      ),
    );
  }

  /// Opens the author's home. The author id is required; the row hides the
  /// affordance when the payload carried none.
  Future<void> _openAuthor(String authorId, String name) async {
    await _push(AuthorPage(authorId: authorId, fallbackName: name));
  }

  Future<void> _openDirectory() async {
    if (_allChapters.isEmpty) return;
    // Browsing the catalog supersedes a pending asynchronous resume action.
    ++_openGeneration;
    if (_opening) setState(() => _opening = false);
    final chapter = await showDetailDirectory(
      context,
      chapters: _allChapters,
      chapterUnit: _chapterUnit,
      currentIndex: _resumeIndex,
    );
    if (mounted && chapter != null) _openChapter(chapter);
  }

  void _openAllReviews() {
    showDetailReviewsSheet(
      context,
      bookId: _contentId,
      title: _bookDetail?.title ?? widget.item.title,
      initialComments: _comments,
      replyLoader: _replyLoader(_contentId),
      loader: _commentsLoader(),
    );
  }

  /// Opens the listening page for the same work, starting where the saved
  /// audio progress left off.
  Future<void> _openListening() async {
    if (_allChapters.isEmpty || _opening) return;
    final generation = ++_openGeneration;
    setState(() => _opening = true);
    try {
      // Listening progress lives in the audio scope, even when the entry
      // being browsed is the text edition of the same book.
      final store = widget.readerStore ?? LibraryStore.instance;
      Map<String, dynamic>? saved;
      try {
        saved = await AudioHistory(store).load(_contentId);
      } catch (_) {
        // History is optional. Its absence must not block opening a book.
        saved = null;
      }
      if (!mounted || generation != _openGeneration || _allChapters.isEmpty) {
        return;
      }
      final index = resumeAudioChapterIndex(saved, _allChapters) ?? 0;
      await _push(
        AudioPage(
          bookId: _contentId,
          title: widget.item.title,
          cover: widget.item.cover,
          historyStore: widget.readerStore,
          chapters: _allChapters,
          startIndex: index,
        ),
      );
    } finally {
      if (mounted && generation == _openGeneration) {
        setState(() => _opening = false);
      }
    }
  }

  /// Starts — or, while a batch runs, stops — the whole-book download.
  ///
  /// The range sheet stays with the reader, where picking a batch size still
  /// makes sense; here one tap means the whole book: every remaining chapter in
  /// one batch, pinned so the cache's LRU budget cannot truncate it.
  ///
  /// Note: 详情页「下载」直接下全本、下载的章节不受缓存预算清理 — 见
  /// .agents/notes/implemented/feature/2026-09-20-offline-whole-book-download.md
  void _toggleDownload() {
    if (_allChapters.isEmpty) return;
    final running = _download;
    if (running != null && running.value.running) {
      running.cancel();
      return;
    }
    final cache = widget.chapterCache ?? ChapterCacheStore.instance;
    unawaited(
      _startWholeBookDownload(cache).catchError((Object _) {
        if (mounted) _snack('缓存未能开始，请重试');
      }),
    );
  }

  /// Starts the whole-book batch from the first chapter that is not cached yet.
  ///
  /// Check the entire directory, including unread or evicted chapters before
  /// the reading position. [ChapterDownload] reuses cached bodies in the rest
  /// of the batch, so resuming a download does not re-fetch them.
  Future<void> _startWholeBookDownload(ChapterCache cache) async {
    final cached = await cache.cachedChapterIds(_contentId);
    if (!mounted) return;
    var startIndex = -1;
    for (var i = 0; i < _allChapters.length; i++) {
      if (!cached.contains(_allChapters[i].itemId)) {
        startIndex = i;
        break;
      }
    }
    if (startIndex < 0) {
      _snack('已全部缓存');
      return;
    }
    final count = _allChapters.length - startIndex;
    _attachDownload(
      WholeBookDownload.start(
        cache: cache,
        book: CachedBook(
          id: _contentId,
          title: widget.item.title,
          cover: widget.item.cover,
          chapters: _allChapters,
        ),
        loader:
            widget.chapterLoader ??
            (chapter) => ApiClient.instance.contentText(chapter.itemId),
        startIndex: startIndex,
        count: count,
      ),
    );
  }

  /// 底栏「下载」：整本下载与离线缓存收进同一个弹层，手机上不再多摆按钮。
  Future<void> _showDownloadSheet() async {
    final palette = HomePalette.of(context);
    final progress = _downloadProgress;
    final cached = _cachedBook != null;
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: homeSheetColor(palette),
      shape: homeSheetShape(palette),
      builder: (sheetContext) => SafeArea(
        top: false,
        child: Padding(
          key: const Key('detail_download_sheet'),
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DetailSheetOption(
                key: const Key('detail_download_all'),
                icon: LucideIcons.download,
                title: '整本下载',
                subtitle: progress != null
                    ? '下载中 ${progress.completed}/${progress.total}'
                    : (_allChapters.isEmpty
                          ? '目录加载中'
                          : '缓存全部 ${_allChapters.length}$_chapterUnit'),
                enabled: _allChapters.isNotEmpty,
                onTap: () {
                  Navigator.pop(sheetContext);
                  _toggleDownload();
                },
              ),
              DetailSheetOption(
                key: const Key('detail_download_cached'),
                icon: LucideIcons.book_open,
                title: '离线缓存',
                subtitle: cached ? '用本地整本缓存直接阅读' : '暂无本地缓存',
                enabled: cached,
                onTap: () {
                  Navigator.pop(sheetContext);
                  unawaited(_readCached());
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// The running batch as the read bar renders it; null while idle.
  ({int completed, int total})? get _downloadProgress {
    final download = _download;
    if (download == null || !download.value.running) return null;
    final state = download.value;
    return (completed: state.completed, total: state.total);
  }

  void _attachDownload(ChapterDownload download) {
    _download?.removeListener(_onDownloadChanged);
    _download = download;
    download.addListener(_onDownloadChanged);
    if (mounted) setState(() {});
  }

  /// Progress, and the final report of the attached batch.
  void _onDownloadChanged() {
    final download = _download;
    if (download == null) return;
    final state = download.value;
    if (!state.running) {
      download.removeListener(_onDownloadChanged);
      _download = null;
      WholeBookDownload.release(download);
      final message = state.message;
      if (message != null) _snack(message);
    }
    if (mounted) setState(() {});
  }

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<Map<String, dynamic>?> _readSavedRecord() async {
    final store = widget.readerStore ?? LibraryStore.instance;
    try {
      final saved = switch (widget.item.kind) {
        'video' || 'manju' => await PlayerHistory(store).load(_contentId),
        'audio' => await AudioHistory(store).load(_contentId),
        'manga' => await ReaderHistory(
          scopedHistoryStore(store, 'manga'),
        ).load(_contentId),
        _ => await ReaderHistory(store).load(_contentId),
      };
      if (saved?['kind'] != null &&
          saved?['kind'] != widget.item.kind &&
          !(_isVideo && isVideoKind(saved!['kind'].toString()))) {
        return null;
      }
      // Legacy text-reading records sometimes encode the chapter ID as a number.
      return !_isVideo && saved != null
          ? {
              ...saved,
              if (saved['chapterId'] != null)
                'chapterId': saved['chapterId'].toString(),
            }
          : saved;
    } catch (_) {
      // History is optional. Its absence must not block opening a book.
      return null;
    }
  }

  int? _savedIndex(Map<String, dynamic>? saved) => _isAudio
      ? resumeAudioChapterIndex(saved, _allChapters)
      : resumeEpisodeIndex(saved, _allChapters);

  Future<void> _refreshResume() async {
    final generation = ++_historyGeneration;
    final saved = await _readSavedRecord();
    if (!mounted || generation != _historyGeneration) return;
    final next = _savedIndex(saved);
    final time = switch (saved?['time']) {
      final num value when value > 0 => value.toInt(),
      _ => null,
    };
    if (next == _resumeIndex && time == _resumeTime) return;
    setState(() {
      _resumeIndex = next;
      _resumeTime = time;
      _expandResumeVolume();
    });
  }

  /// Upstream expands the volume that holds the saved chapter. An unread book
  /// opens its first volume instead, so the catalogue always has visible rows
  /// (the previous fqapp preview did the same with its first three chapters).
  void _expandResumeVolume() {
    final volume = detailArchiveVolumeFor(_volumes, _resumeIndex);
    if (volume != null && volume.title.isNotEmpty) {
      _expandedVolumes.add(volume.key);
      return;
    }
    if (_expandedVolumes.isNotEmpty) return;
    for (final candidate in _volumes) {
      if (candidate.title.isNotEmpty) {
        _expandedVolumes.add(candidate.key);
        return;
      }
    }
  }

  /// Per-chapter cache marks in the inline catalogue (upstream reads the
  /// offline repository the same way). Decorative: failures stay silent.
  Future<void> _loadCachedChapterIds(int generation) async {
    if (!_isBook || _allChapters.isEmpty) return;
    // Same offline rule as [_loadExtras]: an injected loader means the caller
    // drives its own data, so the page must not open the real cache behind it.
    final cache =
        widget.chapterCache ??
        (widget.detailLoader != null || widget.directoryLoader != null
            ? null
            : ChapterCacheStore.instance);
    if (cache == null) return;
    try {
      final ids = await cache.cachedChapterIds(_contentId);
      if (!mounted || generation != _loadGeneration) return;
      setState(() => _cachedChapterIds = ids);
    } catch (_) {
      // A broken cache must not take the detail page down.
    }
  }

  /// `已缓存`, `已缓存 12 / 146`, or `未缓存`; null for non-book media.
  String? _cacheLabel(Iterable<int> indexes) {
    if (!_isBook) return null;
    final list = indexes.toList(growable: false);
    if (list.isEmpty) return null;
    final count = list
        .where(
          (index) => _cachedChapterIds.contains(_allChapters[index].itemId),
        )
        .length;
    if (count == 0) return '未缓存';
    return count == list.length ? '已缓存' : '已缓存 $count / ${list.length}';
  }

  /// Flips the inline catalogue and persists the choice, like upstream's
  /// `setReaderPreferences(catalogueReversed: …)`. A failed write keeps the
  /// in-session order and tells the user.
  Future<void> _toggleCatalogueOrder() async {
    if (_catalogueOrderSaving) return;
    final next = !_catalogueReversed;
    setState(() {
      _catalogueOrderSaving = true;
      _catalogueReversed = next;
    });
    final saved = await CatalogueOrderPreferences.instance.save(next);
    if (!mounted) return;
    setState(() => _catalogueOrderSaving = false);
    if (!saved) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('目录顺序保存失败，请重试'),
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  /// 「点击书籍直接进入阅读」：详情页加载出目录后，直接按上次进度进
  /// 阅读器。目录为空（加载失败/无章节）时不触发，用户留在详情页看错误
  /// 与重试；`_autoOpened` 保证同一详情页实例只自动进一次。
  Future<void> _maybeAutoOpenReader() async {
    if (!widget.autoOpenReader ||
        _autoOpened ||
        !(_isBook || _isManga) ||
        _allChapters.isEmpty) {
      return;
    }
    _autoOpened = true;
    await _openLastPosition(replace: true);
  }

  Future<void> _openLastPosition({bool replace = false}) async {
    if (_opening || _allChapters.isEmpty) return;
    final generation = ++_openGeneration;
    setState(() => _opening = true);
    try {
      final saved = await _readSavedRecord();
      if (!mounted || generation != _openGeneration || _allChapters.isEmpty) {
        return;
      }
      final restored = _savedIndex(saved);
      if (saved?['fanqieImported'] == true &&
          saved?['chapterId'] != null &&
          restored == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('导入的章节暂不在当前目录中，请在目录中选择可阅读章节')),
        );
        return;
      }
      final index = restored ?? 0;
      _openChapter(_allChapters[index], replace: replace);
    } finally {
      if (mounted && generation == _openGeneration) {
        setState(() => _opening = false);
      }
    }
  }

  Future<void> _openChapter(Chapter chapter, {bool replace = false}) async {
    // An explicit chapter selection supersedes any pending resume lookup.
    ++_openGeneration;
    ++_historyGeneration;
    if (_opening) setState(() => _opening = false);
    if (_isVideo && !supportsVideoPlayback) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('当前平台暂不支持视频播放')));
      return;
    }
    final index = _allChapters.indexWhere((c) => c.itemId == chapter.itemId);
    final startIndex = index < 0 ? 0 : index;
    final page = switch (widget.item.kind) {
      'video' || 'manju' => PlayerPage(
        bookId: _contentId,
        kind: widget.item.kind,
        title: widget.item.title,
        cover: widget.item.cover,
        historyStore: widget.readerStore,
        eps: _allChapters,
        startIndex: startIndex,
        // 搜索→详情页→播放与短剧页同源（kind 已是 video/manju），不传
        // shortSeries 会让长按面板/弹幕/剧评/已看标记/清晰度整组失效
        // （它们都挂在 PlayerPage.shortSeries 门上）。
        shortSeries: true,
      ),
      'audio' => AudioPage(
        bookId: _contentId,
        title: widget.item.title,
        cover: widget.item.cover,
        historyStore: widget.readerStore,
        chapters: _allChapters,
        startIndex: startIndex,
        resumeSession: false,
      ),
      'manga' => ComicReaderPage(
        bookId: _contentId,
        title: widget.item.title,
        cover: widget.item.cover,
        readerStore: widget.readerStore,
        chapters: _allChapters,
        startIndex: startIndex,
        // 阅读器内「加入书架」沿用它：书架 key 需要 seriesId/kind 一致（#103）。
        shelfItem: widget.item,
      ),
      _ => ReaderPage(
        bookDetail: _bookDetail,
        bookId: _contentId,
        title: widget.item.title,
        cover: widget.item.cover,
        readerStore: widget.readerStore,
        chapters: _allChapters,
        startIndex: startIndex,
        shelfItem: widget.item,
        // 详情页注入的缓存（离线下载/测试用内存缓存）即阅读器的缓存；
        // 生产调用方不传时为 null，阅读器沿用默认的 ChapterCacheStore。
        chapterCache: widget.chapterCache,
      ),
    };
    await _push(page, replace: replace);
  }

  Future<void> _push(Widget page, {bool replace = false}) async {
    if (replace) {
      // 直接进入阅读：顶掉详情页，阅读器返回时回到点书的页面，而不是详情页。
      await Navigator.pushReplacement(
        context,
        MaterialPageRoute<void>(builder: (_) => page),
      );
    } else {
      await Navigator.push(
        context,
        MaterialPageRoute<void>(builder: (_) => page),
      );
    }
    if (mounted) unawaited(_refreshResume());
  }

  /// 本地整本缓存：目录请求失败时用它兜底，让已下载的书仍能离线阅读。
  Future<CachedBook?> _cachedCatalogue() async {
    try {
      return await (widget.chapterCache ?? ChapterCacheStore.instance)
          .cachedBook(_contentId);
    } catch (_) {
      return null;
    }
  }

  /// 离线时提前查一次本地缓存：详情页这条路离线必然失败，不该等目录请求超时
  /// 才把「从缓存阅读」给出来。联网时立即返回，在线路径一次缓存都不查。
  Future<void> _resolveCachedCatalogue(int generation) async {
    if (!_isBook) return;
    final connectivity = await (widget.connectivity ?? currentConnectivity)();
    if (connectivity.online || !mounted || generation != _loadGeneration) {
      return;
    }
    final cached = await _cachedCatalogue();
    if (cached == null || !mounted || generation != _loadGeneration) return;
    setState(() => _cachedBook = cached);
  }

  Future<void> _readCached() async {
    final book = _cachedBook;
    if (book == null) return;
    final opened = await openCachedBook(
      context,
      book: book,
      cache: widget.chapterCache,
      readerStore: widget.readerStore,
    );
    if (!opened && mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('缓存已失效，请联网后重试')));
    }
  }
}

/// 点书卡片的统一入口：默认进详情页；用户开了设置 → 阅读 →「点书直达阅读器」
/// 时，详情页加载完目录后自动按上次进度进阅读器（小说/漫画），返回时回到点书
/// 的页面。听书/短剧与加载失败时仍停留在详情页。
///
/// [entry] 决定用哪条偏好（issue #103）：书架、阅读历史这类「我的书」入口要显式
/// 传 [BookOpenEntry.shelf]，发现入口用默认值即可。调用方不要再直接
/// `Navigator.push(DetailPage(...))`，否则开关对那个入口不生效。
Future<void> openBookDetail(
  BuildContext context,
  MediaItem item, {
  BookOpenEntry entry = BookOpenEntry.discover,
}) async {
  // 书旗条目走自己的详情页：它的 bookId 是另一套命名空间，番茄的 DetailPage
  // 会拿这个 id 去查番茄接口，必然查不到。
  if (isShuqiItem(item)) {
    await Navigator.push(
      context,
      MaterialPageRoute<void>(
        builder: (_) => ShuqiDetailPage(
          bookId: item.id,
          initialTitle: item.title,
          initialCover: item.cover,
        ),
      ),
    );
    return;
  }
  final preferences = BookOpenPreferences.instance;
  await preferences.load();
  if (!context.mounted) return;
  await Navigator.push(
    context,
    MaterialPageRoute<void>(
      builder: (_) => DetailPage(
        item: item,
        autoOpenReader: preferences.directReaderFor(entry),
      ),
    ),
  );
}
