// NB: package must stay com.example.shortplay — libshortplay_crypto.so exports
// JNI symbols bound to that package name (Java_com_example_shortplay_...).
package com.example.shortplay

import android.content.Context
import android.os.Build
import android.os.Environment
import android.util.Log
import androidx.annotation.Keep
import java.io.EOFException
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.net.Proxy
import java.net.UnknownHostException
import java.nio.file.NoSuchFileException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong

/**
 * Bridge to the shortplay C crypto core (libshortplay_crypto.so).
 *
 * The C core decrypts CENC-encrypted MP4 on the fly; all network I/O funnels
 * back through [HttpBridge.httpSize] / [HttpBridge.streamPrepare]. ExoPlayer
 * reads decrypted plaintext through the nativePlayerStream* ABI.
 */
@Keep
object CryptoNative {
    @Volatile private var initialized = false

    init {
        System.loadLibrary("shortplay_crypto")
    }

    /** Cache the HttpBridge class on the native side. Idempotent. */
    @Synchronized
    fun ensureInit() {
        if (initialized) return
        if (!nativeInit(HttpBridge::class.java)) {
            throw IOException("Failed to initialize the native crypto bridge")
        }
        initialized = true
    }

    fun prewarm(cdnUrl: String, keyHex: String): Int {
        ensureInit()
        return nativePrewarm(cdnUrl, keyHex)
    }

    fun prewarmHeaderOnly(cdnUrl: String, keyHex: String): Int {
        ensureInit()
        return nativePrewarmHeaderOnly(cdnUrl, keyHex)
    }

    private external fun nativeInit(bridge: Class<*>): Boolean
    private external fun nativePrewarm(cdnUrl: String, keyHex: String): Int
    private external fun nativePrewarmHeaderOnly(cdnUrl: String, keyHex: String): Int

    // ExoPlayer DataSource stream methods
    @JvmStatic external fun nativePlayerStreamOpen(url: String, keyHex: String): Long

    @JvmStatic external fun nativePlayerStreamRead(handle: Long, buf: ByteArray, len: Int): Int

    @JvmStatic external fun nativePlayerStreamSeek(handle: Long, offset: Long): Long

    @JvmStatic external fun nativePlayerStreamSize(handle: Long): Long

    @JvmStatic external fun nativePlayerStreamClose(handle: Long)
}

/**
 * OkHttp-backed HTTP range fetcher invoked from native code. Kept as a
 * top-level object with a single static-style entry point so the JNI layer
 * can resolve it via GetStaticMethodID without holding an instance.
 *
 * The size probe requires byte ranges. Stream reads return a bounded positive
 * count, zero at EOF, or -1 on failure; native code turns failures into IOException.
 */
@Keep
object HttpBridge {
    // One id space for both bridges: the native side treats stream ids as
    // opaque jlongs, but they must never collide across the two maps.
    private val streamIds = AtomicLong(1L)
    private val playbackHttpStatus = ConcurrentHashMap<String, Int>()

    private val bridge = HttpRangeClient(
        okhttp3.OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .callTimeout(45, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            // Bypass the system/WiFi HTTP proxy and hit the CDN directly. OkHttp
            // defaults to ProxySelector.getDefault(), which picks up a per-network
            // proxy and breaks playback when that proxy is unreachable.
            .proxy(Proxy.NO_PROXY)
            .build(),
        nextId = streamIds,
        onHttpStatus = { url, status -> playbackHttpStatus[url] = status }
    )

    private val fileBridge = OfflineFileBridge(streamIds)

    /**
     * Point the local-file bridge at the app's own download/cache trees.
     * Must be called from the plugin's onAttachedToEngine before any
     * playback: until then the bridge has no allowed roots and rejects
     * every file:// URL (fail-closed).
     */
    @JvmStatic
    fun configure(context: Context) {
        fileBridge.setAllowedRoots(appPrivateFileRoots(context))
    }

    /** Ephemeral diagnostic metadata only; callers clear it when the player is released. */
    fun lastHttpStatus(url: String): Int? = playbackHttpStatus[url]

    fun clearHttpStatus(url: String) {
        playbackHttpStatus.remove(url)
    }

    @JvmStatic
    fun httpRange(url: String, start: Long, end: Long): ByteArray? = if (url.startsWith("file://")) {
        fileBridge.httpRange(url, start, end)
    } else {
        bridge.httpRange(url, start, end)
    }

    @JvmStatic
    fun httpSize(url: String): Long = if (url.startsWith("file://")) {
        fileBridge.httpSize(url)
    } else {
        bridge.httpSize(url)
    }

    @JvmStatic
    fun streamPrepare(url: String, start: Long, expectedSize: Long): Long = if (url.startsWith("file://")) {
        fileBridge.streamPrepare(url, start, expectedSize)
    } else {
        bridge.streamPrepare(url, start, expectedSize)
    }

    @JvmStatic
    fun streamConnect(id: Long): Boolean = if (fileBridge.owns(id)) fileBridge.streamConnect(id) else bridge.streamConnect(id)

    @JvmStatic
    fun streamOpen(url: String, start: Long): Long = if (url.startsWith("file://")) {
        fileBridge.streamOpen(url, start)
    } else {
        bridge.streamOpen(url, start)
    }

    @JvmStatic
    fun streamRead(id: Long, buf: ByteArray): Int = streamRead(id, buf, buf.size)

    @JvmStatic
    fun streamRead(id: Long, buf: ByteArray, length: Int): Int = if (fileBridge.owns(id)) {
        fileBridge.streamRead(id, buf, length)
    } else {
        bridge.streamRead(id, buf, length)
    }

    @JvmStatic
    fun streamClose(id: Long) {
        if (fileBridge.owns(id)) fileBridge.streamClose(id) else bridge.streamClose(id)
    }
}

/**
 * Local-file twin of the HTTP range bridge, used for offline-cached episodes:
 * the download store keeps the original CENC-encrypted MP4 bytes plus the
 * per-episode key, and playback passes a file:// URL so the native crypto
 * core reads (and decrypts) from disk through the same sp_io contract. The
 * native layer treats URLs as opaque strings, so no JNI/C changes are needed.
 *
 * Mirrors HttpRangeClient's contract exactly: size > 0 or -1, stream ids > 0
 * (0 on prepare failure), read returns >0, 0 at EOF, -1 on error, and a
 * prepared stream must hit exactly [expectedSize] total or connect fails —
 * which is what surfaces a truncated/corrupted download to the player.
 *
 * A file:// URL is only honored when its canonical path falls inside the
 * allowed roots (see [resolveOfflineFile]): without that bound, any file://
 * URL — including `..` traversal or a symlink hop — could make the bridge
 * read arbitrary app-private files.
 */
@Keep
private class OfflineFileBridge(streamIds: AtomicLong) {
    private val nextId = streamIds

    /** Set once by [HttpBridge.configure]; empty until then (fail-closed). */
    @Volatile private var allowedRoots: List<File> = emptyList()

    fun setAllowedRoots(roots: List<File>) {
        allowedRoots = roots
    }

    private class OfflineStream(val file: java.io.File, val start: Long, var remaining: Long) {
        var raf: java.io.RandomAccessFile? = null
        var closed = false
        var connected = false
    }

    private val streams = java.util.concurrent.ConcurrentHashMap<Long, OfflineStream>()

    private fun fileOf(url: String): File? = resolveOfflineFile(url, allowedRoots)

    fun owns(id: Long): Boolean = streams.containsKey(id)

    fun httpSize(url: String): Long {
        val file = fileOf(url) ?: return -1L
        val length = file.length()
        return if (length > 0L) length else -1L
    }

    fun httpRange(url: String, start: Long, end: Long): ByteArray? {
        if (start < 0 || end < start || end - start >= Int.MAX_VALUE) return null
        val file = fileOf(url) ?: return null
        val length = (end - start + 1).toInt()
        return try {
            java.io.RandomAccessFile(file, "r").use { raf ->
                if (file.length() < end + 1) return null
                raf.seek(start)
                val buf = ByteArray(length)
                var read = 0
                while (read < length) {
                    val n = raf.read(buf, read, length - read)
                    if (n < 0) break
                    read += n
                }
                if (read != length) null else buf
            }
        } catch (t: Throwable) {
            android.util.Log.e("sp_crypto", "file httpRange threw: ${t.javaClass.simpleName}")
            null
        }
    }

    fun streamPrepare(url: String, start: Long, expectedSize: Long): Long {
        if (start < 0 || expectedSize < -1 ||
            (expectedSize >= 0 && start >= expectedSize)
        ) {
            return 0L
        }
        val file = fileOf(url) ?: return 0L
        val total = file.length()
        if (total <= 0L || (expectedSize >= 0 && total != expectedSize)) return 0L
        if (start >= total) return 0L
        val id = nextId.getAndIncrement()
        if (id <= 0L) return 0L
        streams[id] = OfflineStream(file, start, total - start)
        return id
    }

    fun streamConnect(id: Long): Boolean {
        val s = streams[id] ?: return false
        synchronized(s) {
            if (s.closed || s.connected) return s.connected && !s.closed
            val raf = try {
                java.io.RandomAccessFile(s.file, "r").apply { seek(s.start) }
            } catch (t: Throwable) {
                android.util.Log.e(
                    "sp_crypto",
                    "file streamConnect threw: ${t.javaClass.simpleName}"
                )
                return false
            }
            s.raf = raf
            s.connected = true
            return true
        }
    }

    fun streamOpen(url: String, start: Long): Long {
        val id = streamPrepare(url, start, -1)
        return if (id != 0L && streamConnect(id)) id else 0L
    }

    fun streamRead(id: Long, buf: ByteArray, length: Int): Int {
        if (length < 0 || length > buf.size) return -1
        val s = streams[id] ?: return -1
        if (length == 0) return 0
        synchronized(s) {
            if (s.closed) return -1
            val raf = s.raf ?: return -1
            return try {
                if (s.remaining == 0L) return 0
                val toRead = minOf(length.toLong(), s.remaining).toInt()
                val read = raf.read(buf, 0, toRead)
                when {
                    read < 0 -> if (s.remaining > 0L) -1 else 0

                    read == 0 -> -1

                    else -> {
                        s.remaining -= read
                        read
                    }
                }
            } catch (t: Throwable) {
                streamClose(id)
                android.util.Log.e(
                    "sp_crypto",
                    "file streamRead threw id=$id: ${t.javaClass.simpleName}"
                )
                -1
            }
        }
    }

    fun streamClose(id: Long) {
        val s = streams.remove(id) ?: return
        synchronized(s) {
            s.closed = true
            try {
                s.raf?.close()
            } catch (_: Throwable) {
            }
            s.raf = null
        }
    }
}

/**
 * Pure containment check: [file] must canonicalize to an allowed root
 * itself or to a descendant of one, and its *real* path must still be inside
 * that root. Canonicalization alone is not enough: it resolves `..` on every
 * platform, but only POSIX resolves symlinks — Windows
 * `File.getCanonicalPath()` maps to `GetFullPathName`, which keeps a reparse
 * point as-is, so a link inside the root pointing outside would pass. The
 * separator suffix keeps `/data/app-x` from matching root `/data/app`.
 */
internal fun isFileWithinRoots(file: File, roots: List<File>): Boolean {
    val canonical = runCatching { file.canonicalFile }.getOrNull() ?: return false
    return roots.any { root ->
        val canonicalRoot = runCatching { root.canonicalFile }.getOrNull() ?: return@any false
        val insideCanonical = canonical == canonicalRoot ||
            canonical.path.startsWith(canonicalRoot.path + File.separator)
        insideCanonical && realPathStaysInside(file, canonicalRoot)
    }
}

/**
 * Second gate behind [isFileWithinRoots]: `Path.toRealPath()` follows symlinks
 * and Windows reparse points on every platform, so a link that hops out of the
 * root is rejected even where canonicalization does not see through it.
 *
 * The gate is only *needed* where canonicalization does not resolve links —
 * Windows, where `File.getCanonicalPath()` is `GetFullPathName`; on
 * Android/Linux `getCanonicalPath` is already `realpath(3)`. That is also what
 * makes skipping it on API 24/25 safe: `java.nio.file` (and `File.toPath()`)
 * only exists from API 26 although `minSdk = 24`, and calling it there throws
 * `NoSuchMethodError` — a `Throwable`, so the fail-closed branch below would
 * reject **every** offline file on Android 7.x. `Build.VERSION.SDK_INT` is 0
 * under the JVM unit tests (AGP's mockable android.jar), i.e. exactly the
 * desktop environment this gate exists for, hence the range `1..25` instead of
 * `>= 26`.
 *
 * Fail-closed by design: only a file that genuinely does not exist yet stands
 * this gate down (there is no link to follow, the canonical comparison still
 * catches the hop, and callers require the file to exist). A symlink loop, an
 * access-denied or an unparsable path is exactly what an attacker wants waved
 * through, so anything else throws -> reject. When the *root* cannot be
 * resolved (external storage not mounted yet) the canonical verdict stands,
 * otherwise a transient mount issue would silently break offline playback.
 */
private fun realPathStaysInside(file: File, canonicalRoot: File): Boolean {
    if (Build.VERSION.SDK_INT in 1..25) return true
    val real = try {
        realPathOf(file) ?: return true
    } catch (_: Throwable) {
        return false
    }
    val realRoot = runCatching { realPathOf(canonicalRoot) }.getOrNull() ?: return true
    return real == realRoot || real.startsWith(realRoot + File.separator)
}

/**
 * Absolute path with every link resolved, or `null` when the file does not
 * exist yet. Deliberately a separate function so the `java.nio.file` references
 * it needs stay out of [realPathStaysInside]'s body: that package is absent on
 * API 24/25, and a verifier resolving those types inside a method that does run
 * on those devices is a risk with nothing to gain. The caller's SDK range check
 * is the guard this suppression relies on.
 */
@Suppress("NewApi")
private fun realPathOf(file: File): String? = try {
    file.toPath().toRealPath().normalize().toString()
} catch (_: NoSuchFileException) {
    null
}

/** Decode valid %XX sequences as raw bytes; leave malformed `%` literal. */
internal fun percentDecodePath(raw: String): String {
    if ('%' !in raw) return raw
    // Collect raw bytes (literal chars as UTF-8, %XX as the decoded byte)
    // and decode once at the end, so a multi-byte %XX sequence stays intact.
    val bytes = mutableListOf<Byte>()
    var i = 0
    while (i < raw.length) {
        val c = raw[i]
        if (c == '%' && i + 2 < raw.length) {
            val hi = raw[i + 1].digitToIntOrNull(16)
            val lo = raw[i + 2].digitToIntOrNull(16)
            if (hi != null && lo != null) {
                bytes.add(((hi shl 4) or lo).toByte())
                i += 3
                continue
            }
        }
        bytes.addAll(c.toString().toByteArray(Charsets.UTF_8).toList())
        i++
    }
    return bytes.toByteArray().toString(Charsets.UTF_8)
}

/**
 * Windows 的 JVM 单测会把 `file:///C:/...` 解析成 `/C:/...`；Java 的 [File]
 * 会把这个前导 `/` 当成「当前驱动器的根」，得到 `E:\C:\...`，于是根内文件也
 * 被判为越界。
 *
 * 注意它在生产路径上也是**无条件执行**的（`fileOf` 里就调）：措辞说"只影响本地
 * 单测"指的是实际效果——Android 只会下发 POSIX 路径，`/字母:斜杠` 这种形态不出现，
 * 于是这里等于原样返回。真要出现该形态，剥完变成相对路径，反而更容易被
 * [isFileWithinRoots] 拒绝，不会放宽边界。
 */
internal fun stripWindowsDriveSlash(path: String): String {
    if (path.length < 4 || path[0] != '/' || path[2] != ':') return path
    if (!path[1].isLetter()) return path
    if (path[3] != '/' && path[3] != '\\') return path
    return path.substring(1)
}

/**
 * Resolve a `file://` URL to a readable file inside [allowedRoots], or null.
 * Rejects non-file schemes, non-empty non-localhost hosts, and any path
 * whose canonical form escapes every root. Deliberately parses the URL by
 * hand instead of android.net.Uri so the rule stays unit-testable on the
 * JVM and a raw filesystem path (which may contain URI-special characters
 * like `#`) is not reinterpreted as a fragment/query.
 */
internal fun resolveOfflineFile(url: String, allowedRoots: List<File>): File? {
    if (!url.startsWith("file://")) return null
    val rest = url.removePrefix("file://")
    val slash = rest.indexOf('/')
    if (slash < 0) return null
    val host = rest.substring(0, slash)
    if (host.isNotEmpty() && host != "localhost") return null
    val rawPath = rest.substring(slash)
    if (rawPath.isEmpty()) return null
    val file = File(stripWindowsDriveSlash(percentDecodePath(rawPath)))
    if (!isFileWithinRoots(file, allowedRoots)) return null
    return if (file.isFile) file else null
}

/**
 * The directories offline playback may legitimately read from: the app's
 * private files/cache trees (where the Dart download store puts
 * `<support>/offline-video/<itemId>.mp4`), the app-specific external
 * trees, and the public Downloads directory.
 */
internal fun appPrivateFileRoots(context: Context): List<File> {
    val roots = mutableListOf<File>()
    roots += listOfNotNull(
        context.filesDir,
        context.cacheDir,
        runCatching { context.codeCacheDir }.getOrNull(),
        runCatching { context.noBackupFilesDir }.getOrNull(),
        context.externalCacheDir,
        context.getExternalFilesDir(null),
        context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
    )
    roots += context.getExternalFilesDirs(null)?.filterNotNull().orEmpty()
    roots += context.externalCacheDirs?.filterNotNull().orEmpty()
    roots += listOfNotNull(
        runCatching {
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        }.getOrNull()
    )
    return roots.distinct()
}

/** Network implementation kept independent of JNI so its HTTP contract can be tested. */
internal class HttpRangeClient(
    private val client: okhttp3.OkHttpClient,
    private val logError: (String) -> Unit = { Log.e("sp_crypto", it) },
    // Shared with OfflineFileBridge so both maps never hand out the same id.
    private val nextId: AtomicLong = AtomicLong(1L),
    private val onHttpStatus: (String, Int) -> Unit = { _, _ -> }
) {
    private data class ResponseRange(val length: Long, val total: Long?)
    private val contentRange = Regex("bytes\\s+(\\d+)-(\\d+)/(\\d+|\\*)", RegexOption.IGNORE_CASE)

    // 探长度记忆的容量与有效期：一集通常只有 1 个地址，一条剧也就十几集，
    // 16 条足够跨集复用；TTL 只覆盖「一次起播里的重复 open」，过期重探一次。
    private companion object {
        const val SIZE_CACHE_ENTRIES = 16
        const val SIZE_CACHE_TTL_MS = 60_000L
        // Android 的 DNS 在 Wi-Fi/蜂窝切换、代理重启或上游抖动时会短暂失败。
        // OkHttp 不会自动重试 UnknownHostException，一次失败就会让当前
        // ExoPlayer open 直接结束；默认加载策略只留约 3 秒窗口。
        const val DNS_RETRY_ATTEMPTS = 3
        const val DNS_RETRY_DELAY_MS = 300L
    }

    // A read timeout runs only while an actual read is blocked. Pausing the
    // native consumer does not need an infinite read timeout, which would also
    // leave response headers and stalled downloads waiting forever. Streaming
    // has no whole-call deadline because playback can legitimately take hours.
    private val streamClient = client.newBuilder().callTimeout(0, TimeUnit.SECONDS).build()

    private fun isDnsFailure(t: Throwable): Boolean {
        var cause: Throwable? = t
        repeat(8) {
            if (cause is UnknownHostException) return true
            cause = cause?.cause
        }
        return false
    }

    private fun responseRange(resp: okhttp3.Response, start: Long, end: Long?): ResponseRange? {
        val body = resp.body ?: return null
        val encoding = resp.header("Content-Encoding")
        if (encoding != null && !encoding.equals("identity", ignoreCase = true)) return null
        if (resp.code == 200) {
            // A server may ignore Range at the beginning of a file. A full
            // response at a nonzero offset would silently decrypt wrong bytes.
            return if (start == 0L) {
                val length = body.contentLength()
                ResponseRange(length, length.takeIf { it >= 0 })
            } else {
                null
            }
        }
        if (resp.code != 206) return null
        val match =
            contentRange.matchEntire(resp.header("Content-Range")?.trim() ?: "") ?: return null
        val first = match.groupValues[1].toLongOrNull() ?: return null
        val last = match.groupValues[2].toLongOrNull() ?: return null
        if (first != start || last < first || last - first == Long.MAX_VALUE) return null
        val totalText = match.groupValues[3]
        val total = if (totalText == "*") null else totalText.toLongOrNull() ?: return null
        if (total != null && total <= last) return null
        val expectedEnd = if (total == null) {
            end
        } else if (end == null) {
            total - 1
        } else {
            minOf(end, total - 1)
        }
        if (expectedEnd != null && last != expectedEnd) return null
        val length = last - first + 1
        if (body.contentLength() >= 0 && body.contentLength() != length) return null
        return ResponseRange(length, total)
    }

    /**
     * 探长度结果的短时记忆：`CryptoDataSource.open` 每次都要先问总长，而每次
     * seek / 重开流都会重新 open。签名 CDN 地址指向的内容不可变，若不记就会
     * 每次多一条 `Range: bytes=0-0` 串行往返（一个 RTT 全花在起播上）。
     *
     * 失败（-1）永远不记：瞬时 403、断网、CDN 回源都可能自行恢复，必须能重试。
     */
    private data class CachedSize(val bytes: Long, val atMs: Long)

    private val sizeCache = object : LinkedHashMap<String, CachedSize>(8, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, CachedSize>): Boolean =
            size > SIZE_CACHE_ENTRIES
    }

    /** Prove byte-range support and get the total size without downloading the movie. */
    fun httpSize(url: String): Long {
        val nowMs = System.nanoTime() / 1_000_000
        synchronized(sizeCache) {
            val cached = sizeCache[url]
            if (cached != null) {
                if (nowMs - cached.atMs < SIZE_CACHE_TTL_MS) return cached.bytes
                sizeCache.remove(url)
            }
        }
        return probeSize(url).also { size ->
            if (size > 0L) synchronized(sizeCache) { sizeCache[url] = CachedSize(size, nowMs) }
        }
    }

    private fun probeSize(url: String): Long {
        var attempt = 0
        while (true) {
            try {
                val req = okhttp3.Request.Builder()
                    .url(url)
                    .header("Range", "bytes=0-0")
                    .header("Accept-Encoding", "identity")
                    .build()
                return client.newCall(req).execute().use { resp ->
                    onHttpStatus(url, resp.code)
                    val range = responseRange(resp, 0, 0)
                    val total = range?.total
                    if (resp.code != 206 || range == null || range.length != 1L || total == null ||
                        total <= 0L
                    ) {
                        logError("httpSize requires a complete byte-range size in HTTP 206")
                        return@use -1L
                    }
                    // A Content-Range header alone is not proof of an actual byte.
                    // readByte throws for truncated responses and use closes every path.
                    resp.body!!.source().readByte()
                    total
                }
            } catch (t: Throwable) {
                if (isDnsFailure(t) && attempt + 1 < DNS_RETRY_ATTEMPTS) {
                    ++attempt
                    try {
                        Thread.sleep(DNS_RETRY_DELAY_MS * attempt)
                    } catch (_: InterruptedException) {
                        Thread.currentThread().interrupt()
                        return -1L
                    }
                    continue
                }
                logError("httpSize threw: ${t.javaClass.simpleName}")
                return -1L
            }
        }
    }

    /**
     * Blocking GET of [url] with an inclusive Range header bytes=[start]-[end].
     */
    fun httpRange(url: String, start: Long, end: Long): ByteArray? {
        if (start < 0 || end < start || end - start >= Int.MAX_VALUE) return null
        val requestedLength = end - start + 1
        val req = try {
            val req = okhttp3.Request.Builder()
                .url(url)
                .header("Range", "bytes=$start-$end")
                .header("Accept-Encoding", "identity")
                .build()
            req
        } catch (t: Throwable) {
            logError("httpRange threw for [$start-$end]: ${t.javaClass.simpleName}")
            return null
        }
        var attempt = 0
        while (true) {
            try {
                return client.newCall(req).execute().use { resp ->
                    onHttpStatus(url, resp.code)
                    val range = responseRange(resp, start, end)
                    if (range == null) {
                        logError("httpRange invalid HTTP ${resp.code} response for [$start-$end]")
                        return null
                    }
                    // Bound the allocation even when a server ignores Range and
                    // returns the complete movie with HTTP 200.
                    val length =
                        if (range.length < 0) requestedLength
                        else minOf(requestedLength, range.length)
                    resp.body!!.source().readByteArray(length)
                }
            } catch (t: Throwable) {
                if (isDnsFailure(t) && attempt + 1 < DNS_RETRY_ATTEMPTS) {
                    ++attempt
                    try {
                        Thread.sleep(DNS_RETRY_DELAY_MS * attempt)
                    } catch (_: InterruptedException) {
                        Thread.currentThread().interrupt()
                        return null
                    }
                    continue
                }
                logError("httpRange threw for [$start-$end]: ${t.javaClass.simpleName}")
                return null
            }
        }
    }

    // ── Streaming GET (used for the mdat region) ────────────────────────────
    // An open-ended `Range: bytes=start-` request whose body is read chunk by
    // chunk, so the native producer can hand each arriving TCP segment to the
    // player immediately.
    private class Stream(
        val request: okhttp3.Request,
        val start: Long,
        val expectedSize: Long,
    ) {
        val url: String = request.url.toString()
        // Close only takes the short state monitor. It never waits for the
        // readLock, so it can interrupt a thread blocked in read/execute.
        val readLock = Any()
        var connecting = false
        var closed = false
        var call: okhttp3.Call? = null
        var resp: okhttp3.Response? = null
        var input: InputStream? = null
        var remaining = -1L
    }

    private val streams = ConcurrentHashMap<Long, Stream>()

    /** Register the request before execute so native close can cancel response headers too. */
    fun streamPrepare(url: String, start: Long, expectedSize: Long): Long {
        if (start < 0 || expectedSize < -1 ||
            (expectedSize >= 0 && start >= expectedSize)
        ) {
            return 0L
        }
        return try {
            val req = okhttp3.Request.Builder()
                .url(url)
                .header("Range", "bytes=$start-")
                .header("Accept-Encoding", "identity")
                .build()
            val id = nextId.getAndIncrement()
            if (id <= 0L) return 0L
            streams[id] = Stream(req, start, expectedSize)
            id
        } catch (t: Throwable) {
            logError("streamPrepare threw @$start: ${t.javaClass.simpleName}")
            0L
        }
    }

    /** Complete a prepared request; a concurrent streamClose interrupts execute. */
    fun streamConnect(id: Long): Boolean {
        val s = streams[id] ?: return false
        synchronized(s) {
            if (s.closed) return false
            if (s.resp != null) return true
            if (s.connecting) return false
            s.connecting = true
        }
        var resp: okhttp3.Response? = null
        var retained = false
        try {
            var attempt = 0
            while (true) {
                val call = streamClient.newCall(s.request)
                synchronized(s) {
                    if (s.closed) {
                        call.cancel()
                        return false
                    }
                    s.call = call
                }
                try {
                    val response = call.execute()
                    resp = response
                    onHttpStatus(s.url, response.code)
                    val range = responseRange(response, s.start, null)
                    if (range == null || (s.expectedSize >= 0 && range.total != s.expectedSize)) {
                        logError("streamConnect invalid HTTP ${response.code} response @${s.start}")
                        return false
                    }
                    synchronized(s) {
                        if (!s.closed) {
                            s.resp = response
                            s.input = response.body!!.byteStream()
                            s.remaining = range.length
                            retained = true
                        }
                    }
                    return retained
                } catch (t: Throwable) {
                    if (isDnsFailure(t) && attempt + 1 < DNS_RETRY_ATTEMPTS && !s.closed) {
                        ++attempt
                        try {
                            Thread.sleep(DNS_RETRY_DELAY_MS * attempt)
                        } catch (_: InterruptedException) {
                            Thread.currentThread().interrupt()
                            return false
                        }
                        if (!s.closed) continue
                    }
                    throw t
                }
            }
        } catch (t: Throwable) {
            logError("streamConnect threw @${s.start}: ${t.javaClass.simpleName}")
            return false
        } finally {
            if (!retained) {
                streamClose(id)
                try {
                    resp?.close()
                } catch (_: Throwable) {
                }
            }
        }
        return false
    }

    /** Open a streamed GET at [start]. Returns a stream id, or 0 on failure. */
    fun streamOpen(url: String, start: Long): Long {
        val id = streamPrepare(url, start, -1)
        return if (id != 0L && streamConnect(id)) id else 0L
    }

    /**
     * Read the next chunk into [buf]. Returns bytes read (>0), 0 on clean EOF,
     * or -1 on error.
     */
    fun streamRead(id: Long, buf: ByteArray): Int = streamRead(id, buf, buf.size)

    fun streamRead(id: Long, buf: ByteArray, length: Int): Int {
        if (length < 0 || length > buf.size) return -1
        val s = streams[id] ?: return -1
        return synchronized(s.readLock) {
            try {
                val input: InputStream
                val available: Long
                synchronized(s) {
                    if (s.closed) return -1
                    input = s.input ?: return -1
                    available = s.remaining
                }
                if (length == 0 || available == 0L) return 0
                val toRead = if (available <
                    0
                ) {
                    length
                } else {
                    minOf(length.toLong(), available).toInt()
                }
                val read = input.read(buf, 0, toRead)
                synchronized(s) {
                    if (s.closed) return -1
                    if (read < 0) {
                        if (s.remaining >
                            0
                        ) {
                            throw EOFException("HTTP stream ended before its declared range")
                        }
                        0
                    } else {
                        if (s.remaining >= 0) s.remaining -= read
                        read
                    }
                }
            } catch (t: Throwable) {
                streamClose(id)
                logError("streamRead threw id=$id: ${t.javaClass.simpleName}")
                -1
            }
        }
    }

    /** Close and release a stream opened by [streamOpen]. */
    fun streamClose(id: Long) {
        val s = streams.remove(id) ?: return
        val (call, response) = synchronized(s) {
            s.closed = true
            s.call to s.resp
        }
        call?.cancel() // Interrupt an in-flight read before closing its body.
        try {
            response?.close() // also closes the body / underlying stream
        } catch (_: Throwable) {
        }
    }
}
